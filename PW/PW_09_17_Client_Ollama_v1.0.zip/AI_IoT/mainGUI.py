import sys
from PySide6.QtWidgets import QApplication, QMainWindow
from PySide6.QtGui import QIcon
from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QFileDialog, QMessageBox
from GUI_qt import Ui_MainWindow
#from AI_Chat import AIChat
import AI_Chat
from voiceShelly2 import AIbaby

#class MainGUI(QMainWindow,Ui_MainWindow):
class MainGUI(QMainWindow):
    path = "C:/Users/admin/Documents/LAVORI/ProgettiOllama/AI_IoT"
    default_filename_KB_IoT = "KB_IoT.txt"
    default_filename_KB_Assistant = "KB_Assistant.txt"

    def __init__(self):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        
        self.setWindowTitle("Interfaccia per AI e IoT")
        AIassistant = AI_Chat.AIChat()
        self.ui.url_ollama.setPlainText(AIassistant.getURL())

        #carica la knowledge base di default per AI con IoT
        prompt = f"""
        Qual è il comando da eseguire? Rispondi solo con una delle seguenti parole:
        'accendi', 'spegni', 'esci', 'niente'. Se l'utente vuole uscire oppure
        terminare il programma, allora esegui il comando 'esci'. Se l'utente dice, accendi la luce? allora esegui 'accendi'.
        Se l'utente dice: spegni la luce, allora esegui 'spegni'.

        """
        self.ui.Knowledge_IoT.append(prompt)

        #carica la knowledge base di default per Assistente AI
        prompt = f"""
        Sei un esperto di droni e ti chiami Roberto. Rispondi sempre all'utente in modo gentile.

        """
        self.ui.Knowledge_Assistant.append(prompt)

        
        #btn per inviare un msg scritto di prompt all'AI
        self.ui.user_query.setPlainText("Come ti chiami?")
        self.ui.btn_executeQuery.clicked.connect(self.inviaMSGtoAI)

        #btn per inviare un comando vocale per attivare un dispositivo IoT
        self.ui.btn_voiceCommand.setIcon(QIcon("mic.png"))
        self.ui.btn_voiceCommand.clicked.connect(self.avvia_comando_vocale)

        #btn per aprire la KB dell'Assistente da un file TXT
        self.ui.btn_OpenKBAssistant.clicked.connect(self.carica_KB_Assistente)
        self.ui.btn_OpenKB_IoT.clicked.connect(self.carica_KB_IoT)

        #btn per salvare la KB dell'Assistente in un file TXT
        self.ui.btn_saveKB_IoT.clicked.connect(self.salva_KB_IoT_su_file)
        self.ui.btn_saveKBAssistant.clicked.connect(self.salva_KB_Assistente_su_file)

        #indicatore per segnalare la fase di registrazione
        self.ui.lbl_listening.setText("")
        self.ui.lbl_listening.setStyleSheet("color: red; font-weight: bold;")
        self.listening_timer = QTimer()
        self.listening_timer.timeout.connect(self.lampeggia_ascolto)
        self.lampeggia_visibile = False

    # CARICARE le KB da file TXT esterno
    def carica_KB_Assistente(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Seleziona un file di testo",
            self.path,  # directory iniziale
            "File di testo (*.txt);;Tutti i file (*)"
        )
        if file_path:
            try:
                with open(file_path, "r", encoding="utf-8") as f:
                    contenuto = f.read()                    
                    self.ui.CollectQuery.append(f"📄 Caricata KB per Assistente AI da file:\n{file_path}")
                    self.ui.Knowledge_Assistant.setText(contenuto)
            except Exception as e:
                QMessageBox.critical(self, "Errore", f"Impossibile leggere il file per Assistente AI:\n{str(e)}")
        else:
            self.ui.CollectQuery.append("Nessun file selezionato per KB Assistente AI.")
    
    def carica_KB_IoT(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Seleziona un file di testo",
            self.path,  # directory iniziale
            "File di testo (*.txt);;Tutti i file (*)"
        )
        if file_path:
            try:
                with open(file_path, "r", encoding="utf-8") as f:
                    contenuto = f.read()                    
                    self.ui.CollectQuery.append(f"📄 Caricata KB per Esperto IoT da file:\n{file_path}")
                    self.ui.Knowledge_IoT.setText(contenuto)
            except Exception as e:
                QMessageBox.critical(self, "Errore", f"Impossibile leggere il file per Esperto IoT:\n{str(e)}")
        else:
            self.ui.CollectQuery.append("Nessun file selezionato per Esperto IoT.")
    
    # SALVARE le KB su file TXT esterno
    def salva_KB_IoT_su_file(self):
    # Apri un dialog per scegliere dove salvare
        file_path, _ = QFileDialog.getSaveFileName(
            self,
            "Salva contenuto",
            self.default_filename_KB_IoT, # default file name
            "File di testo (*.txt);;Tutti i file (*)"
        )

        if file_path:
            try:
                # Estrai il testo dal QTextBrowser
                testo = self.ui.Knowledge_IoT.toPlainText()

                with open(file_path, "w", encoding="utf-8") as file:
                    file.write(testo)

                self.ui.CollectQuery.append(f"💾 KB Esperto IoT salvata in:\n{file_path}")
            except Exception as e:
                QMessageBox.critical(self, "Errore", f"Errore durante il salvataggio di KB Esperto IoT:\n{str(e)}")
        else:
            self.ui.CollectQuery.append("Salvataggio di KB Esperto IoT annullato.")

    def salva_KB_Assistente_su_file(self):
    # Apri un dialog per scegliere dove salvare
        file_path, _ = QFileDialog.getSaveFileName(
            self,
            "Salva contenuto",
            self.default_filename_KB_Assistant, # default file name
            "File di testo (*.txt);;Tutti i file (*)"
        )

        if file_path:
            try:
                # Estrai il testo dal QTextBrowser
                testo = self.ui.Knowledge_Assistant.toPlainText()

                with open(file_path, "w", encoding="utf-8") as file:
                    file.write(testo)

                self.ui.CollectQuery.append(f"💾 KB di Assistente AI salvata in:\n{file_path}")
            except Exception as e:
                QMessageBox.critical(self, "Errore", f"Errore durante il salvataggio di KB di Assistente AI:\n{str(e)}")
        else:
            self.ui.CollectQuery.append("Salvataggio annullato di KB di Assistente AI.")

    # Gestione dell'etichetta che lampeggia quando si usa il comando vocale
    def lampeggia_ascolto(self):
        self.lampeggia_visibile = not self.lampeggia_visibile
        self.ui.lbl_listening.setText("🎤 Sto ascoltando..." if self.lampeggia_visibile else "")
     
    def avvia_comando_vocale(self):
        self.ui.AssistantOutput.append("Ascolto il comando vocale...")

        #Attiva animazione
        self.listening_timer.start(800)
        self.ui.lbl_listening.setText("🎤 Sto ascoltando...")
        QApplication.processEvents() # forza l'aggiornamento della UI

        try:
            AIbaby.registra_audio() # classe del file voiceShelly2.py
            testo = AIbaby.trascrivi_audio()
            self.ui.user_query.setText(testo)
            self.ui.AssistantOutput.append(f"Hai detto: {testo}")
            QApplication.processEvents() # forza l'aggiornamento della UI

            # prima di eseguire l'azione si addestra l'AI con una nuova KB
            kb_definition = self.ui.Knowledge_IoT.toPlainText()
            azione = AIbaby.interpreta_testo(testo,kb_definition)
            azione = azione.replace("'",'')
            azione = azione.replace(".",'')
            self.ui.AssistantOutput.append(f"Azione suggerita: {azione}")
            QApplication.processEvents() # forza l'aggiornamento della UI

            if azione == "esci" or azione == 'esci':
                AIbaby.parla("Uscita richiesta.")
                self.close()
            else:
                AIbaby.esegui_azione(azione)

        except Exception as e:
            self.ui.AssistantOutput.append(f"⚠️ Errore: {str(e)}")
            AIbaby.parla("C'è stato un errore.")

        # Disattiva animazione
        self.listening_timer.stop()
        self.ui.lbl_listening.setText("")  

    # Gestione del messaggio scritto da parte dell'ASSISTENTE AI
    def inviaMSGtoAI(self):
        assistant = AI_Chat.AIChat()
        userQuery = self.ui.user_query.toPlainText()
        #assistant.sendQuery(userQuery)
        kb_assistant = self.ui.Knowledge_Assistant.toPlainText()
        prompt = f"""L'utente ha detto: "{userQuery.strip()}"."{kb_assistant.strip()}"."""
        assistant.AIconPersonalita(prompt)
        self.ui.AssistantOutput.append(assistant.getAI_answer())
        
        self.ui.AssistantOutput.append("***************")
        self.ui.CollectQuery.append(userQuery)
        self.ui.CollectQuery.append("***************")

"""
    def on_execute_query(self):
        testo = self.ui.user_query.toPlainText()
        self.ui.AssistantOutput.append(f"Hai scritto: {testo}")
        # Potresti qui far passare anche il testo a LLaMA
"""

if __name__ == "__main__":
    print("AVVIO GUI...")
    app = QApplication(sys.argv)
    window = MainGUI()
    window.show()
    sys.exit(app.exec())
