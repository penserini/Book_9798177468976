# AI_IoT – Assistente AI con interfaccia Qt e comandi vocali

Il programma principale è `mainGUI.py`. Usa Ollama per le risposte testuali e per interpretare comandi vocali, Whisper locale per trascrivere l'audio e una presa/relè Shelly per accendere e spegnere una luce.

## File principali

- `mainGUI.py`: avvio della GUI e gestione dei pulsanti.
- `GUI_qt.py`: interfaccia PySide6 importata dalla GUI principale.
- `AI_Chat.py`: richieste HTTP a Ollama.
- `voiceShelly2.py`: registrazione, trascrizione, sintesi vocale e controllo Shelly.
- `GUI_qt_ver.2.0.ui`: progetto dell'interfaccia; non viene caricato da mainGUI.py.
- `KB_assistente_espertoDroni.txt` e `KB_assistente_IoT.txt`: esempi di istruzioni caricabili dai pulsanti della GUI.
- `mic.png`: icona del microfono.
- `GUI_qt_old.py`, `GUI_qt_uic6.py` e `GUI_qt_ver.2.0_ui.py`: varianti conservate; non sono l'avvio principale.
- `requirements.txt`, `Installa.bat`: dipendenze e installazione su Windows.

## Prerequisiti

1. Windows con Python a 64 bit. Python 3.11 è la versione consigliata per questo progetto; l'installatore cerca nell'ordine `py -3.11`, `py -3`, `python` e `python3`, verifica versione e architettura e usa il percorso reale dell'interprete trovato. Non usare versioni precedenti a Python 3.10.
2. Internet e spazio su disco per installare le dipendenze (Whisper include PyTorch, che può richiedere download consistenti).
3. Ollama installato da https://ollama.com/download, in esecuzione sullo stesso PC, con il modello `llama3.1` scaricato.
4. FFmpeg installato e disponibile nel PATH per la trascrizione Whisper. Riferimento: https://ffmpeg.org/download.html
5. Microfono predefinito funzionante e autorizzazione Windows all'accesso da app desktop; altoparlanti per la sintesi vocale.
6. Per le azioni IoT: Shelly raggiungibile nella rete locale e compatibile con l'API `/relay/0?turn=on` e `/relay/0?turn=off`. Non tutti i modelli Shelly usano questa API.

## Installazione Windows

Estrarre l'intero ZIP. Aprire la cartella `AI_IoT` ed eseguire `Installa.bat` con doppio clic.

Il BAT:
- lavora nella propria cartella, anche se il percorso contiene spazi;
- riutilizza e controlla `.venv` se esiste, altrimenti cerca Python e crea `.venv`;
- aggiorna pip e installa `requirements.txt`;
- controlla le dipendenze con `pip check` e prova le importazioni del percorso principale;
- segnala se FFmpeg o il comando Ollama mancano.

Il BAT non installa Python, FFmpeg o Ollama e non scarica i modelli. Non richiede di attivare manualmente l'ambiente virtuale. Se un passaggio Python fallisce, mostra un errore e termina con codice diverso da zero.

In un Prompt dei comandi eseguire inoltre:

```bat
ollama pull llama3.1
ollama list
ffmpeg -version
```

Avviare Ollama. Se il server non è già attivo, aprire un altro terminale ed eseguire `ollama serve`, lasciandolo aperto. Non avviare due server sulla stessa porta.

Al primo uso della trascrizione Whisper scarica il modello `base`: occorre Internet. In seguito può riutilizzare il modello memorizzato localmente.

## Configurazione necessaria

### Shelly

In `voiceShelly2.py`, nella funzione `esegui_azione`, sostituire:

```python
shelly_ip = "192.168.1.152"
```

con l'IP reale del dispositivo. Provare i comandi soltanto quando si intende effettivamente commutare il relè collegato.

### Ollama

Il codice usa `http://localhost:11434` e il modello `llama3.1`, impostati nei sorgenti `AI_Chat.py` e `voiceShelly2.py`. Il campo URL della GUI mostra un indirizzo, ma non è collegato alla configurazione delle richieste: modificarlo nella finestra non cambia il server utilizzato. Per un server remoto o un altro modello, aggiornare gli indirizzi e i nomi nei due sorgenti.

### Cartella iniziale delle knowledge base

La proprietà `path` di `MainGUI` contiene un vecchio percorso assoluto del PC dell'autore. Aggiornarla alla cartella locale del progetto oppure navigare manualmente nelle finestre Apri. I due TXT inclusi non sono caricati automaticamente: all'avvio la GUI usa istruzioni definite nel codice.

## Avvio

Aprire il Prompt dei comandi nella cartella `AI_IoT` contenente i sorgenti:

```bat
.venv\Scripts\python.exe mainGUI.py
```

Eseguire dalla cartella del progetto affinché `mic.png` venga trovato e `audio.wav` venga scritto nella posizione attesa. Il file audio incluso viene sovrascritto dalla registrazione successiva.

Per installare senza BAT:

```bat
py -3.11 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe mainGUI.py
```

## Prova funzionale consigliata

1. Aprire la GUI e verificare che appaiano i campi e i pulsanti.
2. Inviare una domanda testuale con Ollama attivo e controllare la risposta.
3. Caricare e salvare una knowledge base con i pulsanti dedicati.
4. Usare il microfono: la registrazione dura cinque secondi; verificare la trascrizione e l'azione suggerita.
5. Dopo aver configurato lo Shelly, provare accensione e spegnimento e controllare fisicamente il risultato.

La GUI esegue le operazioni lente nel thread principale: durante registrazione, trascrizione e richieste può non rispondere e l'indicatore può non lampeggiare regolarmente.

## Esito della revisione e limiti del codice originale

Sono state verificate la sintassi di tutti i file Python e la presenza dei widget usati da mainGUI.py. I sorgenti sono mantenuti invariati in questo pacchetto. Non è stata effettuata una prova completa su Windows con GUI, microfono, modelli e dispositivo Shelly.

Problemi rilevati:
- Avviando direttamente `voiceShelly2.py`, il ciclo finale chiama `interpreta_testo(testo)` senza il parametro obbligatorio `kb_prompt`: quel percorso genera un TypeError dopo la trascrizione. Usare `mainGUI.py`, che passa entrambi i parametri.
- Le richieste Ollama non hanno timeout nel percorso principale; alcune non controllano lo stato HTTP prima di leggere la risposta. Server spento o modello assente possono causare errori, e richieste lente possono bloccare la GUI.
- Il controllo Shelly non verifica lo stato HTTP: la frase “Ho acceso/spento la luce” non garantisce che il dispositivo abbia accettato il comando.
- `AI_Chat.AIconPersonalita` converte tutta la risposta in minuscolo.
- `AI_Chat.sendQuery` accumula le risposte se la stessa istanza viene riutilizzata; non è il metodo richiamato dal pulsante principale.
- Le modifiche al file `.ui` non aggiornano automaticamente `GUI_qt.py`.

Le dipendenze non sono bloccate a versioni esatte: questo pacchetto non riproduce uno specifico ambiente verificato. PyQt6 serve solo per la variante storica; la GUI principale usa PySide6. Il pacchetto da installare per `import whisper` è `openai-whisper`, non `whisper`.

Documentazione:
- Ollama: https://docs.ollama.com/
- Whisper e requisito FFmpeg: https://github.com/openai/whisper
- PySide6: https://doc.qt.io/qtforpython-6/

## Rilevamento automatico e limiti dell’installatore

L’assenza di Python 3.11 non blocca la ricerca delle alternative. Sono richiesti Python 3.10 o successivo e architettura a 64 bit; questo controllo non garantisce che tutte le versioni future abbiano pacchetti compatibili. Pip e il controllo delle importazioni determinano se le dipendenze si installano realmente. Se Python non è esposto tramite launcher o PATH, il BAT spiega come renderlo disponibile. Non esamina arbitrariamente tutte le cartelle del PC e non installa automaticamente Python. Un ambiente esistente non valido viene segnalato senza cancellarlo. I controlli di FFmpeg e Ollama riguardano la disponibilità dei comandi, non la presenza del modello, la connessione al server o il funzionamento dell’hardware. Il BAT non è stato eseguito in un ambiente Windows durante questa revisione.
