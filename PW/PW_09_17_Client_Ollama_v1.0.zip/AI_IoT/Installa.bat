@echo off
setlocal
cd /d "%~dp0"
if errorlevel 1 goto fail
if not exist "requirements.txt" goto fail
set "AIOT_PROBE=%TEMP%\aiot_python_%RANDOM%_%RANDOM%.txt"
set "AIOT_PYTHON="
if exist ".venv\Scripts\python.exe" goto existing
rem CALL restituisce il controllo anche se py/python e' un file BAT o CMD.
call :probe py -3.11
if defined AIOT_PYTHON goto create
call :probe py -3
if defined AIOT_PYTHON goto create
call :probe python
if defined AIOT_PYTHON goto create
call :probe python3
if defined AIOT_PYTHON goto create
goto missing_python
:probe
rem Un launcher puo' restituire un codice inatteso: verifichiamo anche l'output.
if exist "%AIOT_PROBE%" del /q "%AIOT_PROBE%"
call %* -c "import sys; assert sys.version_info >= (3,10) and sys.maxsize > 2**32; print(sys.executable)" >"%AIOT_PROBE%" 2>nul
if errorlevel 1 exit /b 0
set "AIOT_CANDIDATE="
set /p "AIOT_CANDIDATE=" <"%AIOT_PROBE%"
if not defined AIOT_CANDIDATE exit /b 0
if not exist "%AIOT_CANDIDATE%" exit /b 0
set "AIOT_PYTHON=%AIOT_CANDIDATE%"
exit /b 0
:create
if exist "%AIOT_PROBE%" del /q "%AIOT_PROBE%"
echo Python selezionato: "%AIOT_PYTHON%"
"%AIOT_PYTHON%" -m venv ".venv"
if errorlevel 1 goto fail
:existing
if not exist ".venv\Scripts\python.exe" goto fail
".venv\Scripts\python.exe" -c "import sys; assert sys.version_info >= (3,10) and sys.maxsize > 2**32, 'Serve Python 3.10+ a 64 bit'; print('Ambiente:', sys.version)"
if errorlevel 1 goto invalid_venv
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto fail
".venv\Scripts\python.exe" -m pip install -r "requirements.txt"
if errorlevel 1 goto fail
".venv\Scripts\python.exe" -m pip check
if errorlevel 1 goto fail
".venv\Scripts\python.exe" -c "import PySide6, requests, whisper, sounddevice, scipy, pyttsx3; import AI_Chat, GUI_qt, voiceShelly2; print('Importazioni OK')"
if errorlevel 1 goto fail
echo.
echo INSTALLAZIONE PYTHON COMPLETATA.
echo Controllo dei prerequisiti esterni:
ffmpeg -version >nul 2>&1
if errorlevel 1 echo ATTENZIONE: manca FFmpeg. Installarlo e aggiungerlo al PATH per usare Whisper.
where ollama >nul 2>&1
if errorlevel 1 echo ATTENZIONE: Ollama non trovato nel PATH. Consultare README.md.
echo.
echo Avviare Ollama e scaricare il modello con: ollama pull llama3.1
echo Configurare l'IP Shelly in voiceShelly2.py prima dei comandi IoT.
echo Avvio: .venv\Scripts\python.exe mainGUI.py
pause
exit /b 0
:missing_python
if exist "%AIOT_PROBE%" del /q "%AIOT_PROBE%"
echo.
echo Nessun interprete Python 3.10+ a 64 bit individuato tramite launcher o PATH.
echo Se Python e' gia' installato, renderlo disponibile come python o tramite py.
echo Altrimenti installare Python 3.11 a 64 bit da https://www.python.org/downloads/
echo Abilitare il launcher o l'opzione Add Python to PATH, poi rilanciare questo BAT.
echo Nessuna dipendenza del progetto e' stata installata.
pause
exit /b 1
:invalid_venv
echo L'ambiente .venv esistente non e' utilizzabile. Non e' stato cancellato.
echo Rinominare la cartella .venv e rilanciare dopo aver verificato Python.
pause
exit /b 1
:fail
if exist "%AIOT_PROBE%" del /q "%AIOT_PROBE%"
echo.
echo INSTALLAZIONE NON COMPLETATA. Leggere il messaggio precedente.
echo Per errori di compatibilita' delle librerie provare Python 3.11 a 64 bit.
pause
exit /b 1
