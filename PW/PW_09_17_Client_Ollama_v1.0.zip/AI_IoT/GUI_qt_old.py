# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'GUI_qt_ver.2.0.ui'
##
## Created by: Qt User Interface Compiler version 6.9.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QFrame, QLabel, QMainWindow,
    QMenuBar, QPushButton, QSizePolicy, QStatusBar,
    QTabWidget, QTextBrowser, QTextEdit, QWidget)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1161, 789)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.tabWidget = QTabWidget(self.centralwidget)
        self.tabWidget.setObjectName(u"tabWidget")
        self.tabWidget.setGeometry(QRect(0, 0, 1081, 721))
        self.tab = QWidget()
        self.tab.setObjectName(u"tab")
        self.frame = QFrame(self.tab)
        self.frame.setObjectName(u"frame")
        self.frame.setGeometry(QRect(0, 0, 1061, 701))
        self.frame.setFrameShape(QFrame.StyledPanel)
        self.frame.setFrameShadow(QFrame.Raised)
        self.btn_executeQuery = QPushButton(self.frame)
        self.btn_executeQuery.setObjectName(u"btn_executeQuery")
        self.btn_executeQuery.setGeometry(QRect(30, 120, 93, 28))
        font = QFont()
        font.setBold(True)
        self.btn_executeQuery.setFont(font)
        self.btn_executeQuery.setAutoDefault(False)
        self.label = QLabel(self.frame)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(30, 530, 141, 31))
        self.label.setFont(font)
        self.btn_Connect_Ollama = QPushButton(self.frame)
        self.btn_Connect_Ollama.setObjectName(u"btn_Connect_Ollama")
        self.btn_Connect_Ollama.setGeometry(QRect(30, 40, 93, 28))
        self.btn_Connect_Ollama.setFont(font)
        self.label_2 = QLabel(self.frame)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setGeometry(QRect(200, 40, 201, 31))
        self.CollectQuery = QTextBrowser(self.frame)
        self.CollectQuery.setObjectName(u"CollectQuery")
        self.CollectQuery.setGeometry(QRect(200, 190, 691, 211))
        self.AssistantOutput = QTextBrowser(self.frame)
        self.AssistantOutput.setObjectName(u"AssistantOutput")
        self.AssistantOutput.setGeometry(QRect(200, 420, 691, 261))
        self.user_query = QTextEdit(self.frame)
        self.user_query.setObjectName(u"user_query")
        self.user_query.setGeometry(QRect(200, 110, 691, 51))
        self.url_ollama = QTextEdit(self.frame)
        self.url_ollama.setObjectName(u"url_ollama")
        self.url_ollama.setGeometry(QRect(460, 40, 431, 41))
        self.label_3 = QLabel(self.frame)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setGeometry(QRect(30, 280, 141, 31))
        self.label_3.setFont(font)
        self.tabWidget.addTab(self.tab, "")
        self.tab_2 = QWidget()
        self.tab_2.setObjectName(u"tab_2")
        self.tabWidget.addTab(self.tab_2, "")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 1161, 26))
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)

        self.tabWidget.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.btn_executeQuery.setText(QCoreApplication.translate("MainWindow", u"INVIA", None))
        self.label.setText(QCoreApplication.translate("MainWindow", u"ASSISTANT OUTPUT", None))
        self.btn_Connect_Ollama.setText(QCoreApplication.translate("MainWindow", u"LLM Connect", None))
        self.label_2.setText(QCoreApplication.translate("MainWindow", u"Connection results...", None))
        self.label_3.setText(QCoreApplication.translate("MainWindow", u"USER QUERIES", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab), QCoreApplication.translate("MainWindow", u"Tab 1", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_2), QCoreApplication.translate("MainWindow", u"Tab 2", None))
    # retranslateUi

