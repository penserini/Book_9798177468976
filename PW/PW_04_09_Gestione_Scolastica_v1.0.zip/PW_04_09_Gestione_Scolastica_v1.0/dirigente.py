from persona import Persona


class Dirigente(Persona):
    def __init__(self, nome, cognome, eta, settore):
        super().__init__(nome, cognome, eta)
        self.settore = settore

    def presentati(self):
        return (
            f"Buongiorno, sono {self._get_nome()} "
            f"{self._get_cognome()} e dirigo il settore "
            f"{self.settore}."
        )
