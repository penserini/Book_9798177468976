# Sistema di gestione scolastica

Project Work del § 4.9 del libro di Loris Penserini, con estensione Tecnico (§ 4.9.9).

## File

- `persona.py`: classe astratta Persona, attributi interni nome/cognome e metodo astratto presentati().
- `studente.py`: Studente con indirizzo_studi.
- `docente.py`: Docente con materia.
- `dirigente.py`: Dirigente con settore.
- `tecnico.py`: Tecnico con laboratorio.
- `main.py`: crea due studenti, un docente, un dirigente e un tecnico, quindi li presenta con un unico ciclo polimorfico.

## Avvio

Estrarre lo ZIP, aprire un terminale nella cartella del progetto ed eseguire:

```bash
python main.py
```

Occorre Python 3. Non sono necessarie librerie esterne: abc fa parte della libreria standard.

Il codice segue la soluzione del libro: le classi figlio usano super(), ridefiniscono presentati() e accedono a nome/cognome attraverso i metodi della classe padre. Il ciclo finale non verifica il tipo degli oggetti.
