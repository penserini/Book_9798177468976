from persona import Persona


class Studente(Persona):
    def __init__(self, nome, cognome, eta, indirizzo_studi):
        super().__init__(nome, cognome, eta)
        self.indirizzo_studi = indirizzo_studi

    def presentati(self):
        return (
            f"Buongiorno, sono {self._get_nome()} "
            f"{self._get_cognome()} e frequento "
            f"{self.indirizzo_studi}."
        )
