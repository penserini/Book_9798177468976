from abc import ABC, abstractmethod


class Persona(ABC):
    def __init__(self, nome, cognome, eta):
        self.__nome = nome
        self.__cognome = cognome
        self.eta = eta

    def _get_nome(self):
        return self.__nome

    def _get_cognome(self):
        return self.__cognome

    def get_eta(self):
        return self.eta

    @abstractmethod
    def presentati(self):
        pass
