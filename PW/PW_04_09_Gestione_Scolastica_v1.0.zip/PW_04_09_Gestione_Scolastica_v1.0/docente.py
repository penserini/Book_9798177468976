from persona import Persona


class Docente(Persona):
    def __init__(self, nome, cognome, eta, materia):
        super().__init__(nome, cognome, eta)
        self.materia = materia

    def presentati(self):
        return (
            f"Buongiorno, sono {self._get_nome()} "
            f"{self._get_cognome()} e insegno "
            f"{self.materia}."
        )
