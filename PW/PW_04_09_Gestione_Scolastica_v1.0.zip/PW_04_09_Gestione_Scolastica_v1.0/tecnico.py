from persona import Persona


class Tecnico(Persona):
    def __init__(self, nome, cognome, eta, laboratorio):
        super().__init__(nome, cognome, eta)
        self.laboratorio = laboratorio

    def presentati(self):
        return (
            f"Buongiorno, sono {self._get_nome()} "
            f"{self._get_cognome()} e lavoro nel laboratorio "
            f"{self.laboratorio}."
        )
