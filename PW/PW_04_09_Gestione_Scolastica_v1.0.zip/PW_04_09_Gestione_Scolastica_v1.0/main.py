from studente import Studente
from docente import Docente
from dirigente import Dirigente
from tecnico import Tecnico


if __name__ == "__main__":
    persone = [
        Studente("Mario", "Rossi", 20, "Informatica"),
        Studente("Laura", "Neri", 21, "Turismo digitale"),
        Docente("Anna", "Bianchi", 45, "Informatica"),
        Dirigente("Luca", "Verdi", 52, "Tecnologie"),
        Tecnico("Paolo", "Blu", 38, "Informatica"),
    ]

    for persona in persone:
        print(persona.presentati())
