@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo Eseguire prima 00_installa_ambiente.bat.
    pause
    exit /b 1
)
".venv\Scripts\python.exe" "main_somma.py"
if errorlevel 1 (
    echo Avvio non riuscito. Controllare l'errore o rieseguire il BAT di installazione.
    pause
    exit /b 1
)
exit /b 0
