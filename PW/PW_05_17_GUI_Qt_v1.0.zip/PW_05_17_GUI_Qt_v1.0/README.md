# PW 05.17 – GUI con Qt e PySide6

Materiale di accompagnamento al capitolo 5. Il rettangolo completa la traccia del §5.17.4; somma e binomio sono gli esempi forniti dall'autore.

| Esempio | File principale | Avvio Windows | Descrizione |
|---|---|---|---|
| Somma | main_somma.py | 01_avvia_somma.bat | Somma di due numeri con controllo dell'input. |
| Binomio | main_binomio.py | 02_avvia_binomio.bat | Coefficiente N! / (K! (N-K)!) con interi 0 ≤ K ≤ N. |
| Rettangolo | main_rettangolo.py | 03_avvia_rettangolo.bat | Area da base e altezza; errori comunicati mediante una label. |

## Avvio su Windows

1. Estrarre tutto lo ZIP.
2. Avere Python 3.10 o successivo installato, accessibile tramite py oppure python.
3. Eseguire 00_installa_ambiente.bat: crea .venv e installa PySide6. Occorre Internet.
4. Eseguire il BAT dell'esempio desiderato.

L'ambiente è condiviso dai tre esempi. I BAT usano direttamente il suo interprete, senza attivazione manuale. Il BAT di installazione può essere rieseguito. Non spostare i singoli file fuori dalla cartella.

## GUI e logica

Ogni esempio comprende il file .ui modificabile con Qt Designer e il modulo Python della GUI. La logica risiede nei tre main_*.py. Il duplicato somma_ui2.py è omesso: il programma importa somma_ui.py.

Nel binomio il fattoriale usa un ciclo e la divisione intera conserva il risultato esatto. I campi di risultato sono di sola lettura.

Per rigenerare la GUI del rettangolo, dal terminale Windows nella cartella estratta:
    .venv\Scripts\pyside6-uic.exe rettangolo.ui -o rettangolo_ui.py

Non modificare direttamente i moduli generati: una nuova conversione li sovrascrive.

Su macOS/Linux creare un ambiente con python3 -m venv .venv, installare requirements.txt e avviare il main desiderato con l'interprete dell'ambiente. I BAT sono specifici per Windows.
