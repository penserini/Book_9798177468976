import sys
from PySide6.QtWidgets import QApplication, QMainWindow
from binomioGUI import Ui_MainWindow

class MainGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.setWindowTitle("Calcolo del coefficiente binomiale")
        self.ui.lineEdit_risp.setReadOnly(True)
        self.ui.btnCalcola.clicked.connect(self.binomio)

    def fattoriale(self, n):
        risultato = 1
        for i in range(1, n + 1):
            risultato *= i
        return risultato

    def binomio(self):
        try:
            n = int(self.ui.lineEdit_N.text().strip())
            k = int(self.ui.lineEdit_K.text().strip())
            if not 0 <= k <= n:
                raise ValueError
        except ValueError:
            self.ui.lineEdit_N_K.clear()
            self.ui.lineEdit_risp.clear()
            self.statusBar().showMessage("Inserire interi con 0 <= K <= N.")
            return
        try:
            risultato = self.fattoriale(n) // (self.fattoriale(k) * self.fattoriale(n - k))
            testo = str(risultato)
        except (ValueError, OverflowError):
            self.ui.lineEdit_risp.clear()
            self.statusBar().showMessage("Risultato troppo grande: ridurre N.")
            return
        self.ui.lineEdit_N_K.setText(str(n - k))
        self.ui.lineEdit_risp.setText(testo)
        self.statusBar().clearMessage()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainGUI()
    window.show()
    sys.exit(app.exec())
