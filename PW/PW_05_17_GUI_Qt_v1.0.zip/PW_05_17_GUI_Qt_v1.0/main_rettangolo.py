"""PW 5.17.4: area del rettangolo e gestione degli errori."""
import math
import sys
from PySide6.QtWidgets import QApplication, QMainWindow
from rettangolo_ui import Ui_MainWindow

def calcola_area(base, altezza):
    if not math.isfinite(base) or not math.isfinite(altezza) or base <= 0 or altezza <= 0:
        raise ValueError("Base e altezza devono essere positive e finite.")
    area = base * altezza
    if not math.isfinite(area):
        raise ValueError("Valori troppo grandi.")
    return area

class MainGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.ui.btnCalcola.clicked.connect(self.calcola)

    def calcola(self):
        self.ui.outputArea.clear()
        try:
            base = float(self.ui.inputBase.text().strip().replace(",", "."))
            altezza = float(self.ui.inputAltezza.text().strip().replace(",", "."))
        except ValueError:
            self.ui.labelMessaggio.setText("Compilare entrambi i campi con numeri validi.")
            return
        try:
            area = calcola_area(base, altezza)
        except ValueError as errore:
            self.ui.labelMessaggio.setText(str(errore))
            return
        self.ui.outputArea.setText(f"{area:g}")
        self.ui.labelMessaggio.setText("Area calcolata in unita quadrate.")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainGUI()
    window.show()
    sys.exit(app.exec())
