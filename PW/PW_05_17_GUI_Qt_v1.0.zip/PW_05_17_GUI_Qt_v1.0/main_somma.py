import math
import sys
from PySide6.QtWidgets import QApplication, QMainWindow
from somma_ui import Ui_MainWindow

class MainGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.setWindowTitle("Somma di due numeri")
        self.ui.sum.setReadOnly(True)
        self.ui.pushButton.clicked.connect(self.somma)

    def somma(self):
        try:
            a = float(self.ui.num1.toPlainText().strip().replace(",", "."))
            b = float(self.ui.num2.toPlainText().strip().replace(",", "."))
            if not all(map(math.isfinite, (a, b, a + b))):
                raise ValueError
        except ValueError:
            self.ui.sum.clear()
            self.statusBar().showMessage("Inserire due numeri validi e finiti.")
            return
        self.ui.sum.setText(str(a + b))
        self.statusBar().clearMessage()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainGUI()
    window.show()
    sys.exit(app.exec())
