# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'rettangolo.ui'
##
## Created by: Qt User Interface Compiler version 6.11.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QFormLayout, QLabel, QLineEdit,
    QMainWindow, QPushButton, QSizePolicy, QVBoxLayout,
    QWidget)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(420, 240)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.verticalLayout = QVBoxLayout(self.centralwidget)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.titolo = QLabel(self.centralwidget)
        self.titolo.setObjectName(u"titolo")

        self.verticalLayout.addWidget(self.titolo)

        self.formLayout = QFormLayout()
        self.formLayout.setObjectName(u"formLayout")
        self.labelBase = QLabel(self.centralwidget)
        self.labelBase.setObjectName(u"labelBase")

        self.formLayout.setWidget(0, QFormLayout.ItemRole.LabelRole, self.labelBase)

        self.inputBase = QLineEdit(self.centralwidget)
        self.inputBase.setObjectName(u"inputBase")

        self.formLayout.setWidget(0, QFormLayout.ItemRole.FieldRole, self.inputBase)

        self.labelAltezza = QLabel(self.centralwidget)
        self.labelAltezza.setObjectName(u"labelAltezza")

        self.formLayout.setWidget(1, QFormLayout.ItemRole.LabelRole, self.labelAltezza)

        self.inputAltezza = QLineEdit(self.centralwidget)
        self.inputAltezza.setObjectName(u"inputAltezza")

        self.formLayout.setWidget(1, QFormLayout.ItemRole.FieldRole, self.inputAltezza)

        self.labelArea = QLabel(self.centralwidget)
        self.labelArea.setObjectName(u"labelArea")

        self.formLayout.setWidget(2, QFormLayout.ItemRole.LabelRole, self.labelArea)

        self.outputArea = QLineEdit(self.centralwidget)
        self.outputArea.setObjectName(u"outputArea")
        self.outputArea.setReadOnly(True)

        self.formLayout.setWidget(2, QFormLayout.ItemRole.FieldRole, self.outputArea)


        self.verticalLayout.addLayout(self.formLayout)

        self.btnCalcola = QPushButton(self.centralwidget)
        self.btnCalcola.setObjectName(u"btnCalcola")

        self.verticalLayout.addWidget(self.btnCalcola)

        self.labelMessaggio = QLabel(self.centralwidget)
        self.labelMessaggio.setObjectName(u"labelMessaggio")
        self.labelMessaggio.setWordWrap(True)

        self.verticalLayout.addWidget(self.labelMessaggio)

        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"Area del rettangolo", None))
        self.titolo.setText(QCoreApplication.translate("MainWindow", u"Calcolo dell'area del rettangolo", None))
        self.labelBase.setText(QCoreApplication.translate("MainWindow", u"Base", None))
        self.labelAltezza.setText(QCoreApplication.translate("MainWindow", u"Altezza", None))
        self.labelArea.setText(QCoreApplication.translate("MainWindow", u"Area", None))
        self.btnCalcola.setText(QCoreApplication.translate("MainWindow", u"Calcola", None))
        self.labelMessaggio.setText(QCoreApplication.translate("MainWindow", u"Inserire base e altezza positive.", None))
    # retranslateUi

