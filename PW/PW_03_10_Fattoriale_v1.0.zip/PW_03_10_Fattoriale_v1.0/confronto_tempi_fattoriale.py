"""Confronto sperimentale dei tre fattoriali — § 3.10.6.

Mettere questo file accanto ai tre file del PW.
Installazione della sola dipendenza esterna: python -m pip install matplotlib
Avvio: python confronto_tempi_fattoriale.py
"""

import sys
from pathlib import Path
from statistics import median
from timeit import repeat

import matplotlib.pyplot as plt

from fattoriale_ricorsivo import fattoriale_ricorsivo
from fattoriale_tail import fattoriale_tail
from fatt_iter import fattoriale_iter


VALORI_N = [10, 50, 100, 200, 500, 900]
ESECUZIONI = 100
RIPETIZIONI = 5


def misura_tempo(funzione, n):
    # Ogni misura comprende più esecuzioni, per ridurre il rumore del timer.
    tempi = repeat(lambda: funzione(n), number=ESECUZIONI, repeat=RIPETIZIONI)
    # Tempo mediano di una singola chiamata, convertito da secondi a millisecondi.
    return median(tempi) / ESECUZIONI * 1000


def main():
    # Margine per le chiamate ricorsive e per il codice di misurazione.
    # Si limita l'esperimento a n <= 900; non si aumenta il limite senza controllo.
    sys.setrecursionlimit(max(sys.getrecursionlimit(), max(VALORI_N) + 200))

    versioni = [
        ("Iterativa", fattoriale_iter, "orange"),
        ("Ricorsiva", fattoriale_ricorsivo, "#4db6ff"),
        ("Tail-ricorsiva", fattoriale_tail, "#00a67d"),
    ]

    plt.figure(figsize=(9, 5))
    for nome, funzione, colore in versioni:
        tempi = []
        for n in VALORI_N:
            # Verifica del risultato fuori dalla misura temporale.
            assert funzione(n) == fattoriale_iter(n)
            tempo = misura_tempo(funzione, n)
            tempi.append(tempo)
            print(f"{nome:15} n={n:3}: {tempo:.6f} ms")
        plt.plot(VALORI_N, tempi, "o-", label=nome, color=colore)

    plt.title("Confronto tempi: fattoriale ricorsivo vs tail vs iterativo")
    plt.xlabel("n")
    plt.ylabel("Tempo (ms)")
    plt.grid(True, linestyle="--", alpha=0.4)
    plt.legend()
    plt.tight_layout()
    destinazione = Path(__file__).resolve().parent / "confronto_tempi_fattoriale.png"
    plt.savefig(destinazione, dpi=300)
    print(f"\nGrafico salvato in: {destinazione}")
    plt.show()


if __name__ == "__main__":
    main()
