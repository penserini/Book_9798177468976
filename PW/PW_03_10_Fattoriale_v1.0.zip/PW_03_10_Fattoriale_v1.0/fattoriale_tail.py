# Fattoriale con ricorsione in coda — § 3.10.2
# Input previsto: un numero intero non negativo. Non sono necessari import.


def fattoriale_tail(n, acc=1):
    if n == 0:
        return acc
    return fattoriale_tail(n - 1, acc * n)


if __name__ == "__main__":
    print("è:", fattoriale_tail(int(input("Fattoriale di: "))))
