# Fattoriale con ricorsione classica — § 3.10.1
# Input previsto: un numero intero non negativo. Non sono necessari import.


def fattoriale_ricorsivo(n):
    if n == 0:
        return 1
    return n * fattoriale_ricorsivo(n - 1)


if __name__ == "__main__":
    print("è:", fattoriale_ricorsivo(int(input("Fattoriale di: "))))
