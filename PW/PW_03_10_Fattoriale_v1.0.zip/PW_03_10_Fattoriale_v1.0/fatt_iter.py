# Fattoriale con approccio iterativo — § 3.10.3
# Input previsto: un numero intero non negativo. Non sono necessari import.


def fattoriale_iter(n):
    risultato = 1
    for i in range(1, n + 1):
        # risultato *= i è equivalente alla riga seguente.
        risultato = risultato * i
    return risultato


if __name__ == "__main__":
    print("è:", fattoriale_iter(int(input("Fattoriale di: "))))
