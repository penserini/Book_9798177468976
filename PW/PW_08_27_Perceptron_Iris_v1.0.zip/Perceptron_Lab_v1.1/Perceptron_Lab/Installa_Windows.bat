@echo off
cd /d "%~dp0"
py -3 -m venv .venv
if errorlevel 1 goto fail
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto fail
echo Installazione completata. Esegui Avvia_Windows.bat
pause
exit /b 0
:fail
echo Installazione non riuscita. Controlla Python e la connessione Internet.
pause
exit /b 1
