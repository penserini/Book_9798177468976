import unittest
from pathlib import Path
import numpy as np
import pandas as pd
from core import Perceptron,prepare,read_sheet
from plots import make_figure

class Tests(unittest.TestCase):
    def test_iris_compatibility(self):
        df=read_sheet(Path(__file__).parent/'datasets/data_old.xlsx','specie iris')
        self.assertEqual(len(df),150)
        X,y=prepare(df,[df.columns[0],df.columns[2],df.columns[4]],['Iris-setosa','Iris-versicolor'],10)
        m=Perceptron(bipolar=False).fit(X,y)
        self.assertEqual(m.updates,[2,2,3,2,1,0,0,0,0,0])
        self.assertTrue(np.array_equal(m.predict(X),y))
        make_figure(X,y,m,[df.columns[0],df.columns[2]],['Setosa','Versicolor']).savefig('verifica_grafici.png')
    def test_scaling_boundary(self):
        X=np.array([[0,0],[0,1],[1,0],[1,1]],float);y=np.array([0,0,0,1])
        m=Perceptron(epochs=50,standardize=True).fit(X,y)
        self.assertTrue(np.array_equal(m.predict(X),y))
        w,b=m.original_weights()
        self.assertTrue(np.array_equal((X@w+b>=0).astype(int),m.predict(X)))
    def test_nonseparable(self):
        X=np.array([[0,0],[0,1],[1,0],[1,1]],float);y=np.array([0,1,1,0])
        m=Perceptron(epochs=20).fit(X,y)
        self.assertGreater(m.errors[-1],0)
    def test_missing(self):
        df=pd.DataFrame({'a':[1,None],'b':[2,3],'c':['A','B']})
        with self.assertRaises(ValueError):prepare(df,['a','b','c'],['A','B'],1)
    def test_deterministic(self):
        X=np.array([[1,2],[3,4],[7,8],[9,10]],float);y=np.array([0,0,1,1])
        a=Perceptron(shuffle=True).fit(X,y);b=Perceptron(shuffle=True).fit(X,y)
        np.testing.assert_equal(a.w,b.w)
    def test_bipolar_update(self):
        m=Perceptron(eta=1,epochs=1,bipolar=True).fit(np.array([[.5,.5],[-10,-10]]),np.array([0,1]))
        initial=np.random.RandomState(1).normal(0,.01,2)
        np.testing.assert_allclose(m.w,initial-1)
        self.assertEqual(m.b,-2)
if __name__=='__main__':unittest.main()
