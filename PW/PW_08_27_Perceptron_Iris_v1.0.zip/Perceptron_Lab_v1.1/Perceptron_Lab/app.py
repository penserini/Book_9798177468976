"""GUI desktop Tkinter. Nessun server e nessuna chiave API."""
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from concurrent.futures import ThreadPoolExecutor
import pandas as pd
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from core import Perceptron, prepare, read_sheet
from plots import make_figure


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('Perceptron Lab • Loris Penserini'); self.geometry('1420x840')
        self.pool = ThreadPoolExecutor(max_workers=1)
        self.protocol('WM_DELETE_WINDOW', self.close)
        self.busy = False
        self.path = None; self.figure = None; self.df = None
        self.status = tk.StringVar(value='Carica un XLSX per iniziare.')
        shell = ttk.Frame(self); shell.pack(fill='both', expand=True)
        shell.rowconfigure(0, weight=1); shell.columnconfigure(0, weight=1)
        self.viewport = tk.Canvas(shell, highlightthickness=0)
        self.viewport.grid(row=0, column=0, sticky='nsew')
        vertical = ttk.Scrollbar(shell, orient='vertical', command=self.viewport.yview)
        vertical.grid(row=0, column=1, sticky='ns')
        horizontal = ttk.Scrollbar(shell, orient='horizontal', command=self.viewport.xview)
        horizontal.grid(row=1, column=0, sticky='ew')
        self.viewport.configure(yscrollcommand=vertical.set, xscrollcommand=horizontal.set)
        self.body = ttk.Frame(self.viewport)
        self.body_window = self.viewport.create_window(0, 0, window=self.body, anchor='nw')
        self.body.bind('<Configure>', lambda e: self.viewport.configure(scrollregion=self.viewport.bbox('all')))
        self.viewport.bind('<Configure>', lambda e: self.viewport.itemconfigure(self.body_window, width=max(1400, e.width)))
        self.bind_all('<MouseWheel>', self.scroll_page)
        self.bind_all('<Shift-MouseWheel>', self.scroll_page)
        self.bind_all('<Button-4>', self.scroll_page)
        self.bind_all('<Button-5>', self.scroll_page)
        top = ttk.Frame(self.body, padding=10); top.pack(fill='x')
        ttk.Button(top, text='Carica XLSX', command=self.load).pack(side='left')
        self.filename = ttk.Label(top, text='Nessun file'); self.filename.pack(side='left', padx=12)
        self.header = tk.BooleanVar(value=True)
        ttk.Checkbutton(top, text='Prima riga = intestazioni', variable=self.header, command=self.reload).pack(side='left')
        self.sheet = ttk.Combobox(top, state='readonly', width=22); self.sheet.pack(side='left', padx=12)
        self.sheet.bind('<<ComboboxSelected>>', lambda e: self.reload())
        settings = ttk.LabelFrame(self.body, text='Dataset e parametri', padding=10); settings.pack(fill='x', padx=10)
        self.combos = {}
        for i, (key, text) in enumerate([('x','Asse X'),('y','Asse Y'),('target','Colonna classe'),('c0','Classe negativa / 0'),('c1','Classe positiva / 1')]):
            ttk.Label(settings, text=text).grid(row=0,column=i,sticky='w')
            cb = ttk.Combobox(settings,state='readonly',width=24); cb.grid(row=1,column=i,padx=5,sticky='ew')
            self.combos[key] = cb
            settings.columnconfigure(i, weight=1)
        self.combos['target'].bind('<<ComboboxSelected>>',lambda e:self.classes())
        row = ttk.Frame(self.body,padding=10); row.pack(fill='x')
        self.values = {}
        for name, default in [('Eta','0.1'),('Epoche','10'),('Seed','1'),('Divisore scala','1')]:
            ttk.Label(row,text=name).pack(side='left',padx=5)
            v=tk.StringVar(value=default);self.values[name]=v
            ttk.Entry(row,textvariable=v,width=7).pack(side='left')
        self.bipolar=tk.BooleanVar(value=True); self.standard=tk.BooleanVar();self.shuffle=tk.BooleanVar()
        for text,v in [('Codifica −1/+1',self.bipolar),('Standardizza',self.standard),('Mescola campioni',self.shuffle)]:
            ttk.Checkbutton(row,text=text,variable=v).pack(side='left',padx=8)
        self.train=ttk.Button(row,text='Addestra e mostra grafici',command=self.run);self.train.pack(side='left',padx=10)
        self.export=ttk.Button(row,text='Esporta PNG',command=self.save,state='disabled');self.export.pack(side='left')
        ttk.Label(self.body,textvariable=self.status,wraplength=1380,padding=10).pack(fill='x')
        self.graph=ttk.Frame(self.body, height=500);self.graph.pack(fill='both',expand=True,padx=10)
        self.graph.pack_propagate(False)
        table = ttk.LabelFrame(self.body, text='Dataset completo (tutte le classi)', padding=5)
        table.pack(fill='x', padx=10, pady=8)
        table.rowconfigure(0, weight=1); table.columnconfigure(0, weight=1)
        self.preview=ttk.Treeview(table,height=8,show='headings')
        self.preview.grid(row=0, column=0, sticky='nsew')
        table_y=ttk.Scrollbar(table,orient='vertical',command=self.preview.yview)
        table_y.grid(row=0,column=1,sticky='ns')
        table_x=ttk.Scrollbar(table,orient='horizontal',command=self.preview.xview)
        table_x.grid(row=1,column=0,sticky='ew')
        self.preview.configure(yscrollcommand=table_y.set,xscrollcommand=table_x.set)
        ttk.Label(self.body,text='z = w·x + b   |   Δw = η(y − ŷ)x   |   Δb = η(y − ŷ)   |   Accuratezza calcolata sui dati di addestramento.',padding=8).pack(fill='x')

    def scroll_page(self, event):
        # Let table, selectors and Matplotlib retain their own wheel behavior.
        widget = event.widget
        if widget == self.preview or isinstance(widget, (ttk.Combobox, ttk.Entry)):
            return
        parent = widget
        while parent is not None:
            if parent == self.graph:
                return
            parent = getattr(parent, 'master', None)
        if getattr(event, 'num', None) in (4, 5):
            steps = -1 if event.num == 4 else 1
        else:
            delta = event.delta
            if not delta: return
            steps = -int(delta / 120) if abs(delta) >= 120 else (-1 if delta > 0 else 1)
        if event.state & 1:
            self.viewport.xview_scroll(steps, 'units')
        else:
            self.viewport.yview_scroll(steps, 'units')
        return 'break'

    def close(self):
        self.pool.shutdown(wait=False,cancel_futures=True);self.destroy()

    def load(self):
        if self.busy:return
        path=filedialog.askopenfilename(filetypes=[('Excel XLSX','*.xlsx')])
        if not path:return
        try:
            with pd.ExcelFile(path) as book:sheets=book.sheet_names
            self.path=path;self.sheet['values']=sheets;self.sheet.set(sheets[0])
            self.filename.config(text=Path(path).name);self.reload()
        except Exception as e:messagebox.showerror('Caricamento',str(e))

    def invalidate(self):
        self.figure=None;self.export.config(state='disabled')
        for child in self.graph.winfo_children():child.destroy()

    def reload(self):
        if self.busy:return
        if not self.path:return
        self.invalidate();self.df=None
        try:
            df=read_sheet(self.path,self.sheet.get(),self.header.get());self.df=df
            cols=list(df.columns)
            if len(cols)<3:raise ValueError('Servono almeno tre colonne.')
            for key in ('x','y','target'):self.combos[key]['values']=cols
            self.combos['x'].set(cols[0]);self.combos['y'].set(cols[2] if len(cols)>=5 else cols[1]);self.combos['target'].set(cols[-1]);self.classes()
            self.preview.delete(*self.preview.get_children());self.preview['columns']=cols
            for c in cols:self.preview.heading(c,text=c);self.preview.column(c,width=220,minwidth=120,stretch=False)
            for row in df.itertuples(index=False,name=None):self.preview.insert('', 'end',values=row)
            self.status.set(f'{len(df)} righe non vuote. Valori mantenuti come nel file. Per convertire 51 in 5,1 usa divisore 10. Scegli due classi e addestra.')
        except Exception as e:self.df=None;self.status.set(str(e));messagebox.showerror('Dataset',str(e))

    def classes(self):
        if self.busy:return
        self.invalidate()
        if self.df is None:return
        names=list(dict.fromkeys(self.df[self.combos['target'].get()].dropna().astype(str)))
        for k in ('c0','c1'):self.combos[k]['values']=names
        self.combos['c0'].set(names[0] if names else '')
        self.combos['c1'].set(names[1] if len(names)>1 else '')

    def run(self):
        if self.df is None:return
        self.invalidate()
        try:
            columns=[self.combos[k].get() for k in ('x','y','target')]
            classes=[self.combos[k].get() for k in ('c0','c1')]
            X,y=prepare(self.df,columns,classes,float(self.values['Divisore scala'].get().replace(',','.')))
            model=Perceptron(float(self.values['Eta'].get().replace(',','.')),int(self.values['Epoche'].get()),int(self.values['Seed'].get()),self.bipolar.get(),self.shuffle.get(),self.standard.get())
            self.busy=True;self.train.config(state='disabled');self.status.set('Addestramento in corso…')
            job=self.pool.submit(model.fit,X,y)
            self.after(80,lambda:self.poll(job,X,y,columns,classes))
        except Exception as e:messagebox.showerror('Parametri',str(e))

    def poll(self,job,X,y,columns,classes):
        if not job.done():self.after(80,lambda:self.poll(job,X,y,columns,classes));return
        self.busy=False;self.train.config(state='normal')
        try:
            model=job.result();self.invalidate()
            self.figure=make_figure(X,y,model,columns[:2],classes)
            canvas=FigureCanvasTkAgg(self.figure,master=self.graph);canvas.draw()
            NavigationToolbar2Tk(canvas,self.graph).update();canvas.get_tk_widget().pack(fill='both',expand=True)
            self.export.config(state='normal')
            w,b=model.original_weights();acc=100*(model.predict(X)==y).mean()
            convergence='Nessuna epoca senza aggiornamenti: convergenza non raggiunta.' if 0 not in model.updates else f'Prima epoca senza aggiornamenti: {model.updates.index(0)+1}.'
            self.status.set(f'{len(y)} campioni • Accuratezza training: {acc:.1f}% • Errori finali: {model.errors[-1]} • {convergence}\nConfine nelle unità degli assi: {w[0]:.5g}·X + {w[1]:.5g}·Y + {b:.5g} = 0')
        except Exception as e:self.status.set('Addestramento non riuscito.');messagebox.showerror('Addestramento',str(e))

    def save(self):
        if self.figure is None:return
        path=filedialog.asksaveasfilename(defaultextension='.png',initialfile='perceptron_grafici.png',filetypes=[('Immagine PNG','*.png')])
        if path:
            try:self.figure.savefig(path,dpi=300)
            except Exception as e:messagebox.showerror('Esportazione',str(e))

if __name__=='__main__':App().mainloop()
