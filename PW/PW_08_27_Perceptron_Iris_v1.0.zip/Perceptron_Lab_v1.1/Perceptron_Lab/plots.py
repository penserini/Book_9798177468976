import numpy as np
from matplotlib.figure import Figure
from matplotlib.colors import ListedColormap


def make_figure(X, y, model, labels, classes):
    fig = Figure(figsize=(14, 4.7), dpi=100, constrained_layout=True)
    axes = fig.subplots(1, 3)
    colors = ['#8535ad', '#17633e']
    for ax in (axes[0], axes[2]):
        for k, name in enumerate(classes):
            ax.scatter(*X[y == k].T, c=colors[k], marker=['o', 's'][k], label=name,
                       edgecolors='white', linewidths=.5, s=35)
        ax.set_xlabel(labels[0]); ax.set_ylabel(labels[1]); ax.legend(fontsize=8)
        ax.grid(alpha=.18)
    axes[0].set_title('Dataset selezionato')
    ep = np.arange(1, len(model.updates) + 1)
    axes[1].plot(ep, model.updates, 'o-', label='Aggiornamenti durante epoca', markersize=3)
    axes[1].plot(ep, model.errors, 's--', label='Errori a fine epoca', markersize=3)
    axes[1].set(xlabel='Epoca', ylabel='Numero', title='Andamento addestramento')
    axes[1].legend(fontsize=8); axes[1].grid(alpha=.2)
    axes[1].set_ylim(bottom=-.5)
    pad = np.maximum(np.ptp(X, axis=0) * .12, .5)
    low, high = X.min(0)-pad, X.max(0)+pad
    xx, yy = np.meshgrid(np.linspace(low[0], high[0], 220), np.linspace(low[1], high[1], 220))
    pred = model.predict(np.column_stack([xx.ravel(), yy.ravel()])).reshape(xx.shape)
    axes[2].contourf(xx, yy, pred, levels=[-.5,.5,1.5], cmap=ListedColormap(colors), alpha=.2)
    w, b = model.original_weights()
    score = xx*w[0] + yy*w[1] + b
    if score.min() < 0 < score.max():
        axes[2].contour(xx, yy, score, levels=[0], colors=['#283344'], linewidths=1.3)
    wrong = model.predict(X) != y
    if wrong.any():
        axes[2].scatter(*X[wrong].T, facecolors='none', edgecolors='black', s=90, label='Errore finale')
        axes[2].legend(fontsize=8)
    axes[2].set_title('Regioni di decisione')
    return fig
