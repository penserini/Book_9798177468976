"""Percettrone binario: algoritmo esplicito per uso didattico."""
from dataclasses import dataclass
import numpy as np
import pandas as pd


def read_sheet(path, sheet, header=True):
    df = pd.read_excel(path, sheet_name=sheet, header=0 if header else None)
    df = df.replace(r'^\s*$', np.nan, regex=True).dropna(how='all').dropna(axis=1, how='all')
    df.columns = [f'{i+1}: {c}' for i, c in enumerate(df.columns)]
    if df.empty:
        raise ValueError('Il foglio non contiene dati.')
    return df


def prepare(df, columns, classes, divisor):
    if len(set(columns)) != 3:
        raise ValueError('Scegli due caratteristiche diverse e una colonna classe distinta.')
    if classes[0] == classes[1]:
        raise ValueError('Scegli due classi diverse.')
    if not np.isfinite(divisor) or divisor <= 0:
        raise ValueError('Il divisore deve essere positivo e finito.')
    selected = df[df[columns[2]].astype(str).isin(classes)].copy()
    X = selected[list(columns[:2])].apply(pd.to_numeric, errors='coerce').to_numpy(float) / divisor
    if not len(X) or not np.isfinite(X).all():
        raise ValueError('Le righe selezionate contengono caratteristiche vuote o non numeriche.')
    y = (selected[columns[2]].astype(str).to_numpy() == classes[1]).astype(int)
    if len(np.unique(y)) != 2:
        raise ValueError('Entrambe le classi devono avere almeno un campione.')
    return X, y


@dataclass
class Perceptron:
    eta: float = .1
    epochs: int = 10
    seed: int = 1
    bipolar: bool = True
    shuffle: bool = False
    standardize: bool = False

    def fit(self, X, y):
        X, y = np.asarray(X, float), np.asarray(y)
        if X.ndim != 2 or X.shape[1] != 2 or len(X) != len(y) or not np.isfinite(X).all():
            raise ValueError('Dataset non valido.')
        if set(np.unique(y)) != {0, 1}:
            raise ValueError('Sono richieste due classi codificate 0 e 1.')
        if not np.isfinite(self.eta) or not 0 < self.eta <= 1 or not 1 <= self.epochs <= 1000:
            raise ValueError('Usa 0 < eta <= 1 e da 1 a 1000 epoche.')
        rng = np.random.RandomState(self.seed)
        self.mean = X.mean(0) if self.standardize else np.zeros(2)
        self.scale = X.std(0) if self.standardize else np.ones(2)
        self.scale[self.scale == 0] = 1
        Z = (X - self.mean) / self.scale
        self.w = rng.normal(0, .01, 2)
        self.b = 0.
        self.updates, self.errors, self.history = [], [], []
        target = np.where(y == 0, -1, 1) if self.bipolar else y
        for _ in range(self.epochs):
            updates = 0
            order = rng.permutation(len(y)) if self.shuffle else np.arange(len(y))
            for i in order:
                prediction = (1 if Z[i] @ self.w + self.b >= 0 else (-1 if self.bipolar else 0))
                delta = self.eta * (target[i] - prediction)
                self.w += delta * Z[i]
                self.b += delta
                updates += int(delta != 0)
            if not np.isfinite(self.w).all() or not np.isfinite(self.b):
                raise ValueError('Pesi non finiti: attiva la standardizzazione o riduci la scala.')
            self.updates.append(updates)
            self.errors.append(int(np.count_nonzero(self.predict(X) != y)))
            self.history.append((self.w.copy(), self.b))
        return self

    def predict(self, X):
        return (((np.asarray(X) - self.mean) / self.scale) @ self.w + self.b >= 0).astype(int)

    def original_weights(self):
        weights = self.w / self.scale
        return weights, self.b - self.mean @ weights
