# Perceptron Lab
Progetto didattico per Loris Penserini, basato sul percettrone delle slide Lez.14–15. GUI desktop italiana Tkinter, algoritmo scritto esplicitamente con NumPy. Non richiede servizi online durante l'uso.

## Avvio su Windows
1. Installa Python 3.11 o successivo dal sito ufficiale, includendo Tcl/Tk e il launcher `py`.
2. Estrai completamente lo ZIP in una cartella.
3. Esegui `Installa_Windows.bat` una sola volta (richiede Internet per le dipendenze).
4. Esegui `Avvia_Windows.bat`.
5. Premi **Carica XLSX** e scegli `datasets/data_old.xlsx`.
6. Mantieni il foglio `specie iris`, X = Sepal length, Y = Petal length, classe = Class label, classi Setosa e Versicolor. Imposta **Divisore scala = 10** se vuoi gli assi 5,1 anziché 51, coerenti con lo ZIP. Il programma non presume né modifica le unità del file.
7. Premi **Addestra e mostra grafici**. I tre grafici compaiono insieme. Puoi ingrandire la finestra, usare zoom/pan della barra Matplotlib ed esportare il pannello a 300 dpi.

Per Linux/macOS: crea un ambiente virtuale, installa `requirements.txt`, esegui `python app.py`. Su Linux Tkinter può richiedere il pacchetto di sistema python3-tk.

## Impostazioni e interpretazione
- Eta: tasso di apprendimento positivo, massimo 1. Epoche: da 1 a 1000. Una epoca è un passaggio completo sui campioni selezionati.
- Seed: rende riproducibili pesi iniziali e mescolamento.
- Codifica −1/+1: predefinita, conforme alle formule delle slide. Disattivala per 0/1, come nello ZIP. La classe negativa è la prima selezionata. I grafici riportano i nomi originali.
- Standardizza: sottrae media e divide per deviazione standard. I grafici restano nelle unità dopo il divisore e la frontiera viene riportata in quelle unità.
- Mescola campioni: cambia ordine a ogni epoca in modo riproducibile.
- Si addestra esclusivamente sulle due caratteristiche rappresentate e sulle due classi selezionate. Le altre specie restano escluse. Il singolo percettrone è binario.
- Aggiornamenti durante epoca: numero di campioni che hanno richiesto correzione dei pesi. Errori a fine epoca: campioni errati dopo tutti gli aggiornamenti. Sono misure diverse, entrambe conteggiate.
- L'accuratezza mostrata è sul training set, non è una stima delle prestazioni su dati nuovi.
- Il programma esegue tutte le epoche richieste, anche dopo una epoca senza aggiornamenti. Se i dati non sono linearmente separabili, l'errore può persistere: aumentare le epoche non garantisce convergenza.
- Nessuna riga incompleta delle due classi viene scartata silenziosamente. Le righe e colonne completamente vuote vengono eliminate. Le celle con formule devono contenere risultati salvati da Excel.
- La prima riga può essere trattata come intestazione oppure come dati. I fogli vuoti sono segnalati.

## Confronto con lo ZIP
Per riprodurre l'esempio: Setosa/Versicolor, Sepal length/Petal length, divisore 10, eta 0,1, 10 epoche, seed 1, codifica 0/1, standardizzazione e mescolamento disattivati. Aggiornamenti attesi: 2, 2, 3, 2, 1, 0, 0, 0, 0, 0. Accuratezza finale training 100%.
Il XLSX allegato contiene 150 record utilizzabili, tre specie e quattro caratteristiche, con misure numeriche dieci volte quelle del file iris.data dello ZIP. Le prime due specie forniscono 100 campioni.

Nota sulle slide: nell'esempio della slide 17, se y = −1 e predizione = +1, eta = 1 e x = 0,5, la formula produce Δw = −1. Il segno positivo riportato nella slide corrisponde invece al caso inverso. Il codice applica direttamente eta*(y−predizione).

## Struttura e verifiche
`app.py`: interfaccia, importazione, lavoro in background, esportazione.
`core.py`: validazione dati, percettrone, conversione della frontiera.
`plots.py`: tre grafici.
`test_core.py`: verifiche matematiche, riproducibilità, dati mancanti, caso XOR e confronto col risultato originale.
Esegui `.venv\Scripts\python.exe -m unittest -v` per verificarle.
Il file `verifica_grafici.png` mostra il risultato di riferimento generato durante i test.

L'algoritmo è implementato per questo progetto seguendo le formule didattiche. Non è incluso il codice Adaline presente nello ZIP, perché l'obiettivo è il percettrone. Riferimento bibliografico: Raschka e Mirjalili, Machine Learning con Python, citato nelle slide. Dataset Iris fornito dall'autore negli allegati.

## Aggiornamento v1.1
La tabella mostra tutte le righe del foglio, incluse le classi escluse dall’addestramento, con barre di scorrimento verticale e orizzontale. La finestra ha barre di scorrimento globali per accedere a tutte le aree su monitor piccoli. Rotella fuori dalla tabella e dai grafici: scorrimento pagina; Maiusc+rotella: scorrimento orizzontale. Sulla tabella la rotella scorre i record. Sui grafici usa le barre globali per spostare la pagina. Colori delle classi: viola e verde scuro, anche negli sfondi delle regioni decisionali.
