# PW 10.08 — Chatbot con Botpress

## Progetto

Esempio didattico di assistente per l’orientamento ai percorsi ITS Turismo Marche, a supporto del project work del libro di Loris Penserini.

Il pacchetto contiene l’esportazione Botpress Cloud del chatbot «New Assistente ITS Turismo Marche», effettuata il 9 ottobre 2026. Il file originale `.bpz` è conservato senza modifiche.

## Contenuto

- `New Assistente ITS Turismo Marche - 2026 Oct 09.bpz`: archivio da importare in Botpress Studio.
- `README.md`: istruzioni di utilizzo.

## Requisiti

Account Botpress Cloud, workspace con possibilità di creare/modificare bot, browser e connessione Internet. Non servono Python, un requirements.txt o un BAT di installazione: il progetto si utilizza nella piattaforma Botpress. Disponibilità delle funzioni AI e limiti di utilizzo dipendono dal piano e dal credito dell’account.

## Importazione passo per passo

1. Estrarre questo ZIP in una cartella del PC.
2. Accedere a https://app.botpress.cloud/ con il proprio account.
3. Creare un nuovo bot dedicato all’esempio e aprirlo in Studio. Importare in un bot già esistente ne sovrascrive il contenuto: usare un nuovo bot.
4. Cliccare sul logo Botpress in alto a sinistra.
5. Selezionare **Import / Export → Import from file** (oppure **Import**, secondo l’interfaccia).
6. Selezionare il file `.bpz` incluso nel pacchetto e attendere il completamento.
7. Controllare workflow, istruzioni dei nodi AI, basi di conoscenza, variabili e tabelle.
8. Ripristinare le integrazioni necessarie nel Dashboard e configurare sul proprio account eventuali credenziali richieste.
9. Provare il chatbot nell’Emulator prima di pubblicarlo.

Il file `.bpz` deve rimanere integro: non estrarlo, modificarne il contenuto o cambiarne l’estensione. Si estrae soltanto lo ZIP esterno.

## Basi di conoscenza e integrazioni

Secondo la documentazione Botpress, l’esportazione conserva i riferimenti alle fonti delle basi di conoscenza; i file sorgente sono conservati sui server Botpress e collegati nell’esportazione. Questo ZIP non costituisce quindi una copia autonoma di tutti i documenti sorgente. Dopo l’importazione verificare che le fonti siano accessibili; se necessario caricarle nuovamente. Le integrazioni devono essere configurate nuovamente.

## Prove consigliate

- Richiedere aiuto nella scelta di un percorso ITS.
- Provare i diversi interessi proposti e specificare la località di provenienza.
- Verificare le risposte rispetto alle fonti ufficiali aggiornate dell’ITS.
- Provare una domanda fuori ambito e verificare il comportamento dell’assistente.

## Stato della verifica

È stata verificata l’integrità del file `.bpz` inserito nello ZIP rispetto all’allegato originale. Non è stata eseguita una nuova importazione in un account Botpress né una verifica delle risposte o dell’accessibilità delle fonti. Per verificare il rilascio, importare in un nuovo bot e completare le prove indicate sopra.

## Riferimenti

- Botpress Cloud: https://app.botpress.cloud/
- Importazione ed esportazione: https://botpress.com/docs/studio/concepts/import-export-bots/

Materiale didattico: le risposte generate vanno controllate prima di utilizzarle per decisioni di orientamento.
