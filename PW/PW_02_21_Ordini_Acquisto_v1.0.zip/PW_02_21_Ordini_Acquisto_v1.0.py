"""Project Work: ordini di acquisto (§ 2.21.7–2.21.9).

Non sono necessari import: vengono utilizzate soltanto funzioni built-in.
"""


def inserisci_quantita(n):
    quantita = []
    for i in range(n):
        q = int(input(f"Quantità ordine {i + 1}: "))
        quantita.append(q)
    return quantita


def calcola_prezzi(quantita, prezzo_unitario):
    prezzi = []
    for q in quantita:
        totale = q * prezzo_unitario
        if q > 20:
            totale = totale * 0.90
        elif q > 10:
            totale = totale * 0.95
        prezzi.append(totale)
    return prezzi


def stampa_risultati(quantita, prezzi):
    for i in range(len(quantita)):
        print(
            f"Ordine {i + 1}: "
            f"quantità = {quantita[i]}, "
            f"totale = {prezzi[i]:.2f} €"
        )


if __name__ == "__main__":
    n = int(input("Numero di ordini: "))
    prezzo_unitario = float(input("Prezzo unitario: "))
    qVett = inserisci_quantita(n)
    pVett = calcola_prezzi(qVett, prezzo_unitario)
    stampa_risultati(qVett, pVett)
