# PW 10.10 — PlantPhoto: client Python/Tkinter (v1.0)

Client studente realizzato sulla possibile soluzione del project work di Loris Penserini. Consente di proporre una fotografia con una domanda e consultare le analisi pubblicate dal docente.

## Prima installare PW 10.09

**Prima di usare questo client, installare e configurare `PW_10_09_PlantPhoto_Flowise_v1.0.zip` sul PC docente**, seguendo il suo README: dipendenze Python, Flowise, importazione del Chatflow, credenziale OpenAI e configurazione `.env`.

Verificare il funzionamento del backend nel browser. Per l'uso da altri PC, il docente avvia `Avvia_Aula.bat`, seleziona la scheda di rete, apre il pannello `http://127.0.0.1:8001/aula` e abilita l'accesso agli IP degli studenti oppure alla sottorete prevista. Comunica agli studenti l'URL FastAPI mostrato dal pannello, per esempio `http://192.168.1.133:8001`.

Il client si installa sul PC studente. Su quel PC non occorre installare Flowise o configurare chiavi API. Per una prova sullo stesso PC docente si può usare `http://127.0.0.1:8001` con backend in modalità locale. Su un altro PC, localhost indicherebbe quel PC e non il server docente.

## Installazione e avvio

Servono Python 3.10 o successivo a 64 bit con Tkinter (3.11 consigliato), requests e Pillow. Tkinter fa parte dell'installazione Python ufficiale Windows se è incluso il componente Tcl/Tk; non si installa con pip.

1. Estrarre interamente lo ZIP.
2. Aprire la cartella `plantphoto_client`.
3. Eseguire `Installa.bat`: cerca Python, crea o riutilizza `.venv`, installa dipendenze e controlla gli import. Non installa Python e non modifica il firewall.
4. Eseguire `Avvia_Client.bat`.
5. Nel campo **URL del server** inserire l'indirizzo FastAPI comunicato dal docente.
6. Premere **Verifica e aggiorna**. Una lista vuota è un risultato valido se nessuna analisi è ancora pubblicata.

Il valore `192.168.1.133` iniziale è l'esempio del libro: cambiarlo nell'interfaccia. L'URL non viene salvato tra gli avvii.

Alternativa da terminale nella cartella del client:

```bat
py -3 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe plantphoto_client.py
```

Su Linux/macOS utilizzare l'ambiente virtuale e Python della propria piattaforma; può essere necessario installare il supporto Tkinter tramite il gestore di sistema. I BAT sono per Windows.

## Utilizzo completo

1. In **Nuova proposta**, scegliere una foto JPEG, PNG o WebP.
2. Controllare l'anteprima e scrivere una domanda (massimo 2000 caratteri).
3. Premere **Invia proposta al docente**.
4. Il client mostra codice e stato `attesa`. L'invio salva la proposta; non avvia l'AI.
5. Il docente, nel browser sul suo PC, approva l'invio a Flowise/OpenAI, revisiona la risposta e la pubblica.
6. Lo studente preme **Verifica e aggiorna**, apre **Archivio pubblicato** e seleziona la voce per vedere foto, domanda e risposta.

Non esiste nel backend un endpoint pubblico per controllare lo stato delle singole proposte in attesa: il client mostra la conferma iniziale e le analisi successivamente pubblicate. L'archivio vuoto iniziale è previsto nel rilascio PW 10.09.

## Endpoint e architettura

| Richiesta | Scopo |
| --- | --- |
| `GET /api/archivio` | Connessione ed elenco delle analisi pubblicate |
| `GET /api/archivio/{id}/foto` | Fotografia di una voce pubblicata |
| `POST /api/proposte` | Invio multipart con campi `file` e `question` |

Il client comunica con FastAPI sulla porta 8001. FastAPI conserva i dati in SQLite sul PC docente. Approvazione, elaborazione tramite Flowise/OpenAI e pubblicazione restano sotto il controllo del docente. Vedere anche `ARCHITETTURA.md`.

## Limiti ed errori

- Foto: massimo 5 MiB, 20 megapixel; immagini animate non accettate.
- Timeout: 5 secondi per connessione, 25 per lettura. Non è un limite complessivo di durata.
- POST con timeout o connessione interrotta: la proposta potrebbe essere già salvata. Verificare con il docente prima di ripetere; nessun retry automatico.
- HTTP 403: il docente deve verificare accesso aula e IP autorizzato.
- HTTP 409: archivio pieno (il backend limita a 200 record).
- HTTP 413/422: controllare dimensione, formato, integrità della foto e domanda.
- Risposta non JSON o server irraggiungibile: verificare URL, backend e rete.

La rete lavora in un thread secondario; il thread Tkinter preleva dalla coda i risultati e aggiorna i widget. Le foto sono selezionate e validate localmente, poi il backend esegue la propria verifica autorevole. Usare foto didattiche adatte alla condivisione: i metadati originali non sono rimossi. Nessun accesso docente, nessuna chiave API e nessuna chiamata alla porta 3000 nel client.

## Differenze puntuali rispetto al listato del libro

Il sorgente è ricavato dalle 390 righe dell'Appendice A, senza numeri di riga. Restano classi API/GUI, interfaccia e percorso delle proposte.

Correzioni per il rilascio: risultati del thread passati tramite coda (evita l'uso tardivo della variabile di eccezione e chiamate Tk dal thread di rete); riferimenti separati per le immagini di proposta e archivio; controlli aggiuntivi su URL, struttura dell'archivio e domanda nella classe API; gestione delle immagini oltre i limiti Pillow.

## Verifica e dipendenze

`requirements.txt` riprende gli intervalli del libro (`requests>=2.32,<3`, `Pillow>=11,<13`), non è un lock completo. Vedere `VERIFICA_RILASCIO.txt` per test svolti e limiti. Eseguire il collaudo della GUI su Windows e il percorso a due PC con il backend configurato prima dell'uso in aula.

Il client non include il backend: scaricare separatamente PW 10.09. Non serve un `.env` nel client.

Test automatici senza server: `.venv\Scripts\python.exe -m unittest discover -s tests -v`.
