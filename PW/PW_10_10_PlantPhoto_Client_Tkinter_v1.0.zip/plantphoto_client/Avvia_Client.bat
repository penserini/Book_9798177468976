@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" goto missing
".venv\Scripts\python.exe" plantphoto_client.py
set "PP_EXIT=%ERRORLEVEL%"
if not "%PP_EXIT%"=="0" pause
exit /b %PP_EXIT%
:missing
echo Prima eseguire Installa.bat dalla cartella estratta del progetto.
pause
exit /b 1
