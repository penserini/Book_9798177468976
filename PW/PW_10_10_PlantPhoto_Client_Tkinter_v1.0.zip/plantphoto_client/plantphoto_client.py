"""Client didattico Tkinter per PlantPhoto_Flowise.

Il programma usa esclusivamente gli endpoint pubblici previsti per gli studenti:
GET  /api/archivio
GET  /api/archivio/{id}/foto
POST /api/proposte

Non contiene chiavi OpenAI o Flowise e non chiama direttamente Flowise.
"""

from __future__ import annotations

import io
import mimetypes
import threading
import queue
from pathlib import Path
from tkinter import BOTH, END, LEFT, RIGHT, X, Y, filedialog, messagebox
import tkinter as tk
from tkinter import ttk
from urllib.parse import urlparse

import requests
from PIL import Image, ImageTk, UnidentifiedImageError


MAX_IMAGE_BYTES = 5 * 1024 * 1024
MAX_IMAGE_PIXELS = 20_000_000
ALLOWED_FORMATS = {"JPEG", "PNG", "WEBP"}
CONNECT_TIMEOUT = 5
READ_TIMEOUT = 25


class ApiError(Exception):
    """Errore controllato da mostrare nell'interfaccia."""


class PlantPhotoApi:
    """Client HTTP privo di credenziali e di riferimenti diretti a Flowise."""

    def __init__(self, base_url: str) -> None:
        value = base_url.strip().rstrip("/")
        parsed = urlparse(value)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            raise ValueError("Inserire un URL completo, ad esempio http://192.168.1.133:8001")
        try:
            port = parsed.port
        except ValueError as exc:
            raise ValueError("Porta del server non valida.") from exc
        if (not parsed.hostname or parsed.username is not None or parsed.password is not None
                or parsed.path not in ("", "/") or parsed.query or parsed.fragment):
            raise ValueError("Usare solo schema, host e porta, senza credenziali o percorsi.")
        self.base_url = value

    def _decode_json(self, response: requests.Response):
        try:
            return response.json()
        except ValueError as exc:
            raise ApiError("Il server non ha restituito JSON leggibile.") from exc

    def _raise_for_status(self, response: requests.Response) -> None:
        if response.ok:
            return
        data = self._decode_json(response)
        detail = data.get("detail") if isinstance(data, dict) else None
        if not isinstance(detail, str):
            detail = f"Richiesta rifiutata (HTTP {response.status_code})."
        explanations = {
            403: " Il PC potrebbe non essere autorizzato nel pannello /aula.",
            409: " L'archivio potrebbe essere pieno oppure lo stato non consente l'operazione.",
            413: " La fotografia supera il limite di 5 MiB.",
            422: " Controllare domanda, formato e integrita della fotografia.",
        }
        raise ApiError(detail + explanations.get(response.status_code, ""))

    def list_archive(self) -> list[dict]:
        try:
            response = requests.get(
                f"{self.base_url}/api/archivio",
                timeout=(CONNECT_TIMEOUT, READ_TIMEOUT),
                headers={"Accept": "application/json"},
            )
        except requests.Timeout as exc:
            raise ApiError("Tempo di attesa superato durante la lettura dell'archivio.") from exc
        except requests.ConnectionError as exc:
            raise ApiError("Connessione non riuscita: verificare URL, rete e avvio del server.") from exc
        except requests.RequestException as exc:
            raise ApiError("Errore di comunicazione con il server.") from exc
        self._raise_for_status(response)
        data = self._decode_json(response)
        if not isinstance(data, list):
            raise ApiError("Formato dell'archivio non riconosciuto.")
        if any(not isinstance(row, dict) or not isinstance(row.get("id"), str)
               or not row["id"] for row in data):
            raise ApiError("Elementi dell'archivio non validi.")
        if len({row["id"] for row in data}) != len(data):
            raise ApiError("Identificativi duplicati nell'archivio.")
        return data

    def submit_proposal(self, image_path: Path, question: str) -> dict:
        question = question.strip()
        if not question or len(question) > 2000:
            raise ValueError("La domanda deve contenere da 1 a 2000 caratteri.")
        validate_image(image_path)
        mime = mimetypes.guess_type(image_path.name)[0] or "application/octet-stream"
        try:
            with image_path.open("rb") as image_file:
                response = requests.post(
                    f"{self.base_url}/api/proposte",
                    data={"question": question},
                    files={"file": (image_path.name, image_file, mime)},
                    timeout=(CONNECT_TIMEOUT, READ_TIMEOUT),
                    headers={"Accept": "application/json"},
                )
        except requests.Timeout as exc:
            raise ApiError(
                "Tempo di attesa superato. La proposta potrebbe essere stata salvata: "
                "non inviarla automaticamente una seconda volta."
            ) from exc
        except requests.ConnectionError as exc:
            raise ApiError(
                "Connessione interrotta. Verificare con il docente prima di ripetere l'invio."
            ) from exc
        except OSError as exc:
            raise ApiError("Impossibile leggere il file selezionato.") from exc
        except requests.RequestException as exc:
            raise ApiError("Errore di comunicazione durante l'invio.") from exc
        self._raise_for_status(response)
        data = self._decode_json(response)
        if not isinstance(data, dict) or not isinstance(data.get("id"), str):
            raise ApiError("Risposta di conferma non riconosciuta.")
        return data

    def download_photo(self, proposal_id: str) -> bytes:
        try:
            response = requests.get(
                f"{self.base_url}/api/archivio/{proposal_id}/foto",
                timeout=(CONNECT_TIMEOUT, READ_TIMEOUT),
            )
        except requests.RequestException as exc:
            raise ApiError("Impossibile scaricare la fotografia pubblicata.") from exc
        self._raise_for_status(response)
        return response.content


def validate_image(path: Path) -> None:
    if not path.is_file():
        raise ValueError("Il file selezionato non esiste.")
    if path.stat().st_size > MAX_IMAGE_BYTES:
        raise ValueError("La fotografia supera 5 MiB.")
    try:
        with Image.open(path) as image:
            if image.format not in ALLOWED_FORMATS:
                raise ValueError("Usare una fotografia JPEG, PNG o WebP.")
            if image.width * image.height > MAX_IMAGE_PIXELS:
                raise ValueError("La fotografia supera 20 megapixel.")
            if getattr(image, "n_frames", 1) != 1:
                raise ValueError("Le immagini animate non sono accettate.")
            image.verify()
        with Image.open(path) as image:
            image.load()
    except ValueError:
        raise
    except (UnidentifiedImageError, OSError, SyntaxError, Image.DecompressionBombError) as exc:
        raise ValueError("File non riconosciuto o immagine danneggiata.") from exc


class PlantPhotoApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("PlantPhoto - Client studente")
        self.geometry("1080x720")
        self.minsize(900, 620)

        self.image_path: Path | None = None
        self.preview_ref: ImageTk.PhotoImage | None = None
        self.detail_ref: ImageTk.PhotoImage | None = None
        self.results = queue.Queue()
        self.after(100, self.poll_results)
        self.archive_rows: dict[str, dict] = {}
        self.busy = False

        self.server_var = tk.StringVar(value="http://192.168.1.133:8001")
        self.file_var = tk.StringVar(value="Nessuna fotografia selezionata")
        self.status_var = tk.StringVar(value="Pronto.")

        self._build_ui()

    def _build_ui(self) -> None:
        style = ttk.Style(self)
        style.configure("Title.TLabel", font=("Segoe UI", 20, "bold"))
        style.configure("Status.TLabel", padding=8)

        header = ttk.Frame(self, padding=14)
        header.pack(fill=X)
        ttk.Label(header, text="PlantPhoto - client Python/Tkinter", style="Title.TLabel").pack(anchor="w")
        ttk.Label(
            header,
            text="Il programma comunica con FastAPI. Flowise e le chiavi rimangono sul PC docente.",
        ).pack(anchor="w", pady=(4, 0))

        connection = ttk.LabelFrame(self, text="Connessione al PC docente", padding=10)
        connection.pack(fill=X, padx=14, pady=(0, 10))
        ttk.Label(connection, text="URL del server:").pack(side=LEFT)
        ttk.Entry(connection, textvariable=self.server_var, width=44).pack(side=LEFT, padx=8)
        self.test_button = ttk.Button(connection, text="Verifica e aggiorna", command=self.refresh_archive)
        self.test_button.pack(side=LEFT)

        notebook = ttk.Notebook(self)
        notebook.pack(fill=BOTH, expand=True, padx=14, pady=4)

        proposal_tab = ttk.Frame(notebook, padding=12)
        archive_tab = ttk.Frame(notebook, padding=12)
        notebook.add(proposal_tab, text="Nuova proposta")
        notebook.add(archive_tab, text="Archivio pubblicato")

        left = ttk.Frame(proposal_tab)
        left.pack(side=LEFT, fill=Y, padx=(0, 14))
        ttk.Button(left, text="Scegli fotografia", command=self.choose_image).pack(fill=X)
        ttk.Label(left, textvariable=self.file_var, wraplength=300).pack(fill=X, pady=8)
        self.preview_label = ttk.Label(left, text="Anteprima", anchor="center", width=42)
        self.preview_label.pack(fill=BOTH, expand=True)

        right = ttk.Frame(proposal_tab)
        right.pack(side=RIGHT, fill=BOTH, expand=True)
        ttk.Label(right, text="Domanda per il docente e per la successiva analisi AI:").pack(anchor="w")
        self.question_text = tk.Text(right, height=14, wrap="word", font=("Segoe UI", 11))
        self.question_text.pack(fill=BOTH, expand=True, pady=8)
        self.question_text.insert(
            "1.0",
            "Descrivi le caratteristiche visibili della pianta e proponi una possibile "
            "identificazione, indicando gli eventuali dubbi.",
        )
        self.submit_button = ttk.Button(right, text="Invia proposta al docente", command=self.submit)
        self.submit_button.pack(anchor="e")
        ttk.Label(
            right,
            text=(
                "L'invio salva la proposta sul PC docente ma non chiama automaticamente l'AI. "
                "Il docente decide se inviarla a Flowise/OpenAI e se pubblicare la risposta."
            ),
            wraplength=610,
        ).pack(anchor="w", pady=10)

        archive_split = ttk.Panedwindow(archive_tab, orient="horizontal")
        archive_split.pack(fill=BOTH, expand=True)
        list_frame = ttk.Frame(archive_split)
        detail_frame = ttk.Frame(archive_split, padding=(12, 0, 0, 0))
        archive_split.add(list_frame, weight=2)
        archive_split.add(detail_frame, weight=3)

        self.tree = ttk.Treeview(list_frame, columns=("date", "question"), show="headings")
        self.tree.heading("date", text="Data")
        self.tree.heading("question", text="Domanda")
        self.tree.column("date", width=160, anchor="w")
        self.tree.column("question", width=360, anchor="w")
        self.tree.pack(side=LEFT, fill=BOTH, expand=True)
        scrollbar = ttk.Scrollbar(list_frame, command=self.tree.yview)
        scrollbar.pack(side=RIGHT, fill=Y)
        self.tree.configure(yscrollcommand=scrollbar.set)
        self.tree.bind("<<TreeviewSelect>>", self.show_selected)

        self.detail_image = ttk.Label(detail_frame, text="Selezionare una voce", anchor="center")
        self.detail_image.pack(fill=X)
        self.detail_text = tk.Text(detail_frame, wrap="word", state="disabled", font=("Segoe UI", 10))
        self.detail_text.pack(fill=BOTH, expand=True, pady=(8, 0))

        footer = ttk.Frame(self, padding=(14, 8, 14, 14))
        footer.pack(fill=X)
        ttk.Label(footer, textvariable=self.status_var, style="Status.TLabel", wraplength=1000).pack(fill=X)

    def api(self) -> PlantPhotoApi:
        return PlantPhotoApi(self.server_var.get())

    def set_busy(self, value: bool, message: str | None = None) -> None:
        self.busy = value
        state = "disabled" if value else "normal"
        self.test_button.configure(state=state)
        self.submit_button.configure(state=state)
        if message:
            self.status_var.set(message)

    def run_background(self, task, on_success) -> None:
        if self.busy:
            return
        self.set_busy(True, "Operazione in corso...")

        def worker() -> None:
            try:
                result = task()
            except (ApiError, ValueError) as exc:
                self.results.put((False, str(exc), on_success))
            except Exception:
                self.results.put((False, "Errore inatteso nell'applicazione.", on_success))
            else:
                self.results.put((True, result, on_success))

        threading.Thread(target=worker, daemon=True).start()

    def poll_results(self) -> None:
        """Solo il thread Tkinter legge la coda e aggiorna i widget."""
        try:
            ok, result, callback = self.results.get_nowait()
        except queue.Empty:
            pass
        else:
            try:
                if ok:
                    callback(result)
                else:
                    self.finish_error(result)
            except Exception:
                self.finish_error("Risposta non utilizzabile dal client.")
        self.after(100, self.poll_results)

    def finish_error(self, message: str) -> None:
        self.set_busy(False, message)
        messagebox.showerror("PlantPhoto", message)

    def choose_image(self) -> None:
        selected = filedialog.askopenfilename(
            title="Seleziona la fotografia",
            filetypes=[("Immagini", "*.jpg *.jpeg *.png *.webp"), ("Tutti i file", "*.*")],
        )
        if not selected:
            return
        path = Path(selected)
        try:
            validate_image(path)
            with Image.open(path) as image:
                image.thumbnail((330, 280))
                preview = image.convert("RGB")
                self.preview_ref = ImageTk.PhotoImage(preview)
        except ValueError as exc:
            self.finish_error(str(exc))
            return
        self.image_path = path
        self.file_var.set(f"{path.name} - {path.stat().st_size / 1024:.1f} KiB")
        self.preview_label.configure(image=self.preview_ref, text="")
        self.status_var.set("Fotografia valida. Non e ancora stata inviata.")

    def submit(self) -> None:
        question = self.question_text.get("1.0", END).strip()
        if not question:
            self.finish_error("Scrivere una domanda.")
            return
        if len(question) > 2000:
            self.finish_error("La domanda supera 2000 caratteri.")
            return
        if self.image_path is None:
            self.finish_error("Selezionare una fotografia.")
            return
        try:
            validate_image(self.image_path)
            api = self.api()
        except ValueError as exc:
            self.finish_error(str(exc))
            return
        path = self.image_path

        def success(data: dict) -> None:
            self.set_busy(False, f"Proposta salvata. Codice: {data['id']} - stato: {data.get('status', 'attesa')}")
            messagebox.showinfo(
                "Proposta inviata",
                f"{data.get('message', 'Proposta salvata.')}\n\nCodice: {data['id']}",
            )

        self.run_background(lambda: api.submit_proposal(path, question), success)

    def refresh_archive(self) -> None:
        try:
            api = self.api()
        except ValueError as exc:
            self.finish_error(str(exc))
            return

        def success(rows: list[dict]) -> None:
            self.archive_rows = {row["id"]: row for row in rows if isinstance(row.get("id"), str)}
            for item in self.tree.get_children():
                self.tree.delete(item)
            for row in rows:
                ident = row.get("id", "")
                created = str(row.get("created", ""))[:19].replace("T", " ")
                question = str(row.get("question", ""))
                self.tree.insert("", END, iid=ident, values=(created, question))
            self.set_busy(False, f"Connessione riuscita. Analisi pubblicate: {len(rows)}.")

        self.run_background(api.list_archive, success)

    def show_selected(self, _event=None) -> None:
        selected = self.tree.selection()
        if not selected or self.busy:
            return
        ident = selected[0]
        row = self.archive_rows.get(ident)
        if row is None:
            return
        try:
            api = self.api()
        except ValueError as exc:
            self.finish_error(str(exc))
            return

        def success(content: bytes) -> None:
            try:
                image = Image.open(io.BytesIO(content))
                image.thumbnail((430, 260))
                self.detail_ref = ImageTk.PhotoImage(image.convert("RGB"))
                self.detail_image.configure(image=self.detail_ref, text="")
            except (UnidentifiedImageError, OSError):
                self.detail_image.configure(image="", text="Fotografia non visualizzabile")
            self.detail_text.configure(state="normal")
            self.detail_text.delete("1.0", END)
            self.detail_text.insert(
                "1.0",
                f"Domanda\n{row.get('question', '')}\n\nRisposta revisionata dal docente\n{row.get('answer', '')}",
            )
            self.detail_text.configure(state="disabled")
            self.set_busy(False, "Dettaglio caricato.")

        self.run_background(lambda: api.download_photo(ident), success)


if __name__ == "__main__":
    app = PlantPhotoApp()
    app.mainloop()
