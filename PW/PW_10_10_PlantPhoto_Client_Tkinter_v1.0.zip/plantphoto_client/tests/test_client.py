"""Test senza server e senza aprire una finestra Tkinter."""
import io
import json
import queue
import sys
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import requests
from PIL import Image
from plantphoto_client import PlantPhotoApi, ApiError, validate_image, PlantPhotoApp

def response(status=200, data=None):
    r = requests.Response()
    r.status_code = status
    r._content = json.dumps(data).encode()
    return r

class ClientTests(unittest.TestCase):
    def setUp(self):
        self.api = PlantPhotoApi('http://127.0.0.1:8001')
        self.temp = tempfile.TemporaryDirectory()
        self.photo = Path(self.temp.name)/'plant.png'
        Image.new('RGB', (20,20), 'green').save(self.photo)
    def tearDown(self):
        self.temp.cleanup()
    def test_empty_archive(self):
        with patch('requests.get', return_value=response(data=[])) as get:
            self.assertEqual(self.api.list_archive(), [])
            self.assertEqual(get.call_args.args[0], 'http://127.0.0.1:8001/api/archivio')
    def test_forbidden(self):
        with patch('requests.get', return_value=response(403, {'detail':'Accesso chiuso'})):
            with self.assertRaisesRegex(ApiError, 'autorizzato'): self.api.list_archive()
    def test_bad_json(self):
        r=response();r._content=b'<html>error</html>'
        with patch('requests.get', return_value=r):
            with self.assertRaisesRegex(ApiError,'JSON'): self.api.list_archive()
    def test_malformed_archive(self):
        with patch('requests.get', return_value=response(data=[None])):
            with self.assertRaises(ApiError): self.api.list_archive()
    def test_connection(self):
        with patch('requests.get', side_effect=requests.ConnectionError):
            with self.assertRaisesRegex(ApiError,'Connessione'): self.api.list_archive()
    def test_submit(self):
        with patch('requests.post', return_value=response(201,{'id':'example','status':'attesa'})) as post:
            self.assertEqual(self.api.submit_proposal(self.photo,'Domanda')['status'],'attesa')
            self.assertEqual(post.call_args.kwargs['data'],{'question':'Domanda'})
            self.assertIn('file',post.call_args.kwargs['files'])
    def test_timeout_no_retry(self):
        with patch('requests.post', side_effect=requests.Timeout) as post:
            with self.assertRaisesRegex(ApiError,'potrebbe essere stata salvata'):
                self.api.submit_proposal(self.photo,'Domanda')
            self.assertEqual(post.call_count,1)
    def test_blank_question(self):
        with patch('requests.post') as post:
            with self.assertRaises(ValueError):self.api.submit_proposal(self.photo,' ')
            post.assert_not_called()
    def test_images(self):
        validate_image(self.photo)
        self.photo.write_bytes(b'broken')
        with self.assertRaises(ValueError):validate_image(self.photo)
    def test_url(self):
        for value in ['localhost','http://user:password@localhost:8001','http://localhost:bad','http://localhost:8001/api']:
            with self.assertRaises(ValueError):PlantPhotoApi(value)
    def test_worker_error_message_survives(self):
        # No Tk calls from worker: a simple stand-in implements the shared queue.
        class StandIn:
            busy=False
            results=queue.Queue()
            def set_busy(self,*args):self.busy=True
        s=StandIn()
        def failure():raise ApiError('Errore di rete di prova')
        PlantPhotoApp.run_background(s,failure,lambda result:None)
        ok,message,_=s.results.get(timeout=2)
        self.assertFalse(ok)
        self.assertEqual(message,'Errore di rete di prova')

if __name__=='__main__':unittest.main()
