# Architettura PlantPhoto

```mermaid
flowchart TD
    C[Client Tkinter studente] -->|Foto e domanda| F[FastAPI sul PC docente]
    F --> D[(SQLite)]
    D --> T[Docente: approvazione]
    T --> W[Flowise]
    W --> O[OpenAI]
    O --> R[Docente: revisione e pubblicazione]
    R --> D
    D -->|Archivio pubblico tramite FastAPI| C
```

Le tre operazioni pubbliche del client sono elenco archivio, lettura foto pubblicata e creazione proposta. I controlli di rete, dimensione, formato e accesso sono deterministici. La risposta del modello è probabilistica; approvazione e revisione sono decisioni del docente.
