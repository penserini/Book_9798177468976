@echo off
setlocal
rem Avvia TicTacToe usando le classi gia compilate (Java 17 o successivo).
pushd "%~dp0"
if errorlevel 1 (
    echo ERRORE: impossibile aprire la cartella del progetto.
    pause
    exit /b 1
)
if not exist "bin\MainGUI.class" (
    echo ERRORE: manca bin\MainGUI.class.
    echo Estrai tutto lo ZIP prima di eseguire questo BAT.
    goto :errore
)
set "TICTACTOE_JAVA="
if defined JAVA_HOME if exist "%JAVA_HOME%\bin\java.exe" set "TICTACTOE_JAVA=%JAVA_HOME%\bin\java.exe"
if not defined TICTACTOE_JAVA (
    where java.exe >nul 2>&1
    if errorlevel 1 (
        echo ERRORE: Java non trovato.
        echo Serve Java 17 o successivo. Configura JAVA_HOME oppure il PATH.
        goto :errore
    )
    set "TICTACTOE_JAVA=java.exe"
)
echo Avvio di TicTacToe...
"%TICTACTOE_JAVA%" -cp "%CD%\bin" MainGUI
if errorlevel 1 (
    echo.
    echo Avvio non riuscito. Il progetto richiede Java 17 o successivo.
    echo Se compare UnsupportedClassVersionError, aggiorna Java.
    echo Versione Java selezionata:
    "%TICTACTOE_JAVA%" -version
    goto :errore
)
popd
endlocal
exit /b 0
:errore
pause
popd
endlocal
exit /b 1
