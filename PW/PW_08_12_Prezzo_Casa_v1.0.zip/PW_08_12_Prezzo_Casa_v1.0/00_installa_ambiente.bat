@echo off
setlocal
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" goto installa
where py >nul 2>&1
if not errorlevel 1 (
 py -3 -m venv .venv
) else (
 python -m venv .venv
)
if errorlevel 1 goto errore
:installa
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto errore
echo Installazione completata.
pause
exit /b 0
:errore
echo Installazione fallita. Verificare Python e Internet.
pause
exit /b 1
