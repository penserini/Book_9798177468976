# PW 08.12 – Prezzo degli appartamenti con regressione lineare

- regressione_semplice.py: esempio essenziale del libro, con i tre dati originali e previsione per 120 m².
- regressione_gui.py: interfaccia Tkinter, dataset XLSX, addestramento, tabella e grafico.
- dataset_esempio.xlsx: sei appartamenti con dati sintetici, esclusivamente didattici.

## Avvio Windows

Estrarre tutto lo ZIP. Installare Python 3.10 o successivo con supporto Tkinter (incluso normalmente nell'installazione Windows). Eseguire 00_installa_ambiente.bat con Internet disponibile; poi 01_avvia_semplice.bat oppure 02_avvia_gui.bat.

## Dataset e modello

Il primo foglio del file XLSX deve avere nella prima riga le intestazioni metri-quadri, prezzo, nome-appartamento. L'ordine delle colonne è libero. Servono almeno due righe con superfici diverse. Superficie e prezzo devono essere numeri positivi e finiti; il nome deve essere compilato. Le righe completamente vuote sono ignorate. Per le formule Excel occorre salvare prima il file da Excel con i risultati calcolati.

La GUI utilizza tutti i dati per addestrare prezzo = intercetta + coefficiente × mq. Il nome identifica le righe e i punti sul grafico; non è una variabile predittiva.

Inserire mq e premere Prevedi prezzo; oppure inserire prezzo e premere Ricava mq. Il secondo comando inverte algebricamente la stessa retta: non addestra un altro modello e non equivale a una regressione mq sul prezzo. La previsione aggiorna l'altro campo; sul grafico compare una stella verde.

Il grafico include x=0 per visualizzare l'intercetta, anche quando è negativa. L'intercetta è un parametro matematico, non il prezzo reale di una casa di zero metri quadrati. Le previsioni esterne alle superfici del dataset sono segnalate come estrapolazioni.

R² è calcolato sui dati di addestramento e non misura la capacità di previsione su un dataset di test. Questo PW è una dimostrazione didattica, non uno strumento di valutazione immobiliare.

Il modello è conservato in memoria e va ricaricato alla riapertura. Su macOS/Linux installare anche Tkinter se non disponibile e usare l'interprete del proprio ambiente virtuale; i BAT sono specifici per Windows.
