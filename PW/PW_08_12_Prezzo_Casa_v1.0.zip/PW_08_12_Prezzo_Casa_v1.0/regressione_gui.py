"""Regressione superficie/prezzo, con dataset XLSX e grafico integrato."""
import math
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path

import numpy as np
from openpyxl import load_workbook
from sklearn.linear_model import LinearRegression
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk

COLONNE = ("metri-quadri", "prezzo", "nome-appartamento")


def numero(valore):
    """Accetta numeri Excel oppure testo con virgola decimale."""
    if isinstance(valore, bool):
        raise ValueError("valore booleano")
    risultato = float(str(valore).strip().replace(",", "."))
    if not math.isfinite(risultato) or risultato <= 0:
        raise ValueError("occorre un numero positivo e finito")
    return risultato


def leggi_dataset(percorso):
    """Legge il primo foglio; richiede intestazioni e almeno due superfici diverse."""
    wb = load_workbook(percorso, read_only=True, data_only=True)
    try:
        righe = iter(wb.worksheets[0].iter_rows(values_only=True))
        intestazioni = next(righe, ())
        nomi = [str(v).strip().lower() if v is not None else "" for v in intestazioni]
        if any(nomi.count(c) != 1 for c in COLONNE):
            raise ValueError("Intestazioni richieste: " + ", ".join(COLONNE))
        indici = [nomi.index(c) for c in COLONNE]
        dati = []
        for indice, riga in enumerate(righe, 2):
            if all(v is None or str(v).strip() == "" for v in riga):
                continue
            valori = [riga[i] if i < len(riga) else None for i in indici]
            try:
                mq, prezzo = numero(valori[0]), numero(valori[1])
                nome = str(valori[2]).strip() if valori[2] is not None else ""
                if not nome:
                    raise ValueError("nome-appartamento mancante")
            except (ValueError, TypeError) as errore:
                raise ValueError(f"Riga {indice}: {errore}") from errore
            dati.append((mq, prezzo, nome))
        if len(dati) < 2 or len({r[0] for r in dati}) < 2:
            raise ValueError("Servono almeno due righe con superfici diverse.")
        return dati
    finally:
        wb.close()


class Applicazione(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Project Work – Regressione lineare degli appartamenti")
        self.geometry("1100x820")
        self.minsize(800, 650)
        self.modello = None
        self.dati = []
        self.punto = None
        barra = ttk.Frame(self, padding=10)
        barra.pack(fill="x")
        ttk.Button(barra, text="Carica XLSX e addestra", command=self.carica).pack(side="left")
        self.file_var = tk.StringVar(value="Nessun dataset caricato")
        ttk.Label(barra, textvariable=self.file_var).pack(side="left", padx=15)
        self.info = tk.StringVar(value="Il nome identifica i punti; la superficie è l'unica variabile del modello.")
        ttk.Label(self, textvariable=self.info, padding=8, wraplength=1050).pack(fill="x")

        pannello = ttk.LabelFrame(self, text="Previsioni sulla retta addestrata", padding=10)
        pannello.pack(fill="x", padx=10)
        ttk.Label(pannello, text="Superficie (mq):").grid(row=0, column=0)
        self.mq = ttk.Entry(pannello, width=16)
        self.mq.grid(row=0, column=1, padx=8)
        self.btn_prezzo = ttk.Button(pannello, text="Prevedi prezzo →", command=self.prevedi_prezzo, state="disabled")
        self.btn_prezzo.grid(row=0, column=2, padx=8)
        ttk.Label(pannello, text="Prezzo (€):").grid(row=0, column=3)
        self.prezzo = ttk.Entry(pannello, width=18)
        self.prezzo.grid(row=0, column=4, padx=8)
        self.btn_mq = ttk.Button(pannello, text="← Ricava mq", command=self.prevedi_mq, state="disabled")
        self.btn_mq.grid(row=0, column=5, padx=8)
        self.esito = tk.StringVar(value="Inserisci un valore e usa il pulsante corrispondente.")
        ttk.Label(pannello, textvariable=self.esito, wraplength=1000).grid(row=1, column=0, columnspan=6, pady=8, sticky="w")

        self.figura = Figure(figsize=(8, 4), constrained_layout=True)
        self.ax = self.figura.add_subplot(111)
        self.canvas = FigureCanvasTkAgg(self.figura, master=self)
        self.canvas.get_tk_widget().pack(fill="both", expand=True, padx=10)
        NavigationToolbar2Tk(self.canvas, self)
        lista = ttk.Frame(self, padding=10)
        lista.pack(fill="x")
        self.tabella = ttk.Treeview(lista, columns=COLONNE, show="headings", height=5)
        for col in COLONNE:
            self.tabella.heading(col, text=col)
            self.tabella.column(col, width=240, anchor="center")
        scroll = ttk.Scrollbar(lista, orient="vertical", command=self.tabella.yview)
        self.tabella.configure(yscrollcommand=scroll.set)
        self.tabella.pack(side="left", fill="x", expand=True)
        scroll.pack(side="right", fill="y")
        self.disegna()

    def carica(self):
        percorso = filedialog.askopenfilename(title="Dataset appartamenti", filetypes=[("Excel", "*.xlsx")])
        if percorso:
            self.carica_percorso(percorso)

    def carica_percorso(self, percorso):
        try:
            dati = leggi_dataset(percorso)
            X = np.array([[r[0]] for r in dati])
            y = np.array([r[1] for r in dati])
            modello = LinearRegression().fit(X, y)
            if not np.isfinite(modello.intercept_) or not np.all(np.isfinite(modello.coef_)):
                raise ValueError("Coefficienti non finiti: controllare i valori del dataset.")
        except Exception as errore:
            messagebox.showerror("Dataset non caricato", str(errore))
            return
        # Sostituisce lo stato solo dopo una lettura e un addestramento riusciti.
        self.modello, self.dati, self.punto = modello, dati, None
        self.file_var.set(Path(percorso).name)
        self.mq.delete(0, "end")
        self.prezzo.delete(0, "end")
        self.tabella.delete(*self.tabella.get_children())
        for mq, prezzo, nome in dati:
            self.tabella.insert("", "end", values=(f"{mq:g}", f"{prezzo:.2f}", nome))
        self.btn_prezzo.configure(state="normal")
        self.btn_mq.configure(state="normal" if abs(modello.coef_[0]) > 1e-12 else "disabled")
        self.info.set(
            f"{len(dati)} appartamenti — prezzo = {modello.intercept_:.2f} + "
            f"{modello.coef_[0]:.2f} × mq. Intercetta: {modello.intercept_:.2f} €; "
            f"coefficiente: {modello.coef_[0]:.2f} €/mq. "
            f"R² sui dati di addestramento: {modello.score(X, y):.4f} (non è una verifica su nuovi dati)."
        )
        self.esito.set("Modello addestrato. Inserisci mq o prezzo.")
        self.disegna()

    def mostra_previsione(self, mq, prezzo, descrizione):
        if not math.isfinite(mq) or not math.isfinite(prezzo) or mq <= 0 or prezzo <= 0:
            raise ValueError("La retta produce un valore non positivo o non finito.")
        avviso = ""
        if not min(r[0] for r in self.dati) <= mq <= max(r[0] for r in self.dati):
            avviso = " Fuori dall'intervallo delle superfici del dataset: estrapolazione."
        self.punto = (mq, prezzo)
        self.esito.set(descrizione + avviso)
        self.disegna()

    def prevedi_prezzo(self):
        if self.modello is None:
            return
        try:
            mq = numero(self.mq.get())
            prezzo = float(self.modello.predict([[mq]])[0])
            self.mostra_previsione(mq, prezzo, f"Prezzo previsto: {prezzo:,.2f} €.")
            self.prezzo.delete(0, "end")
            self.prezzo.insert(0, f"{prezzo:.2f}")
        except ValueError as errore:
            messagebox.showerror("Input non valido", str(errore))

    def prevedi_mq(self):
        if self.modello is None:
            return
        try:
            prezzo = numero(self.prezzo.get())
            coefficiente = float(self.modello.coef_[0])
            if abs(coefficiente) <= 1e-12:
                raise ValueError("Retta orizzontale: non è possibile ricavare la superficie.")
            mq = (prezzo - self.modello.intercept_) / coefficiente
            self.mostra_previsione(mq, prezzo, f"Superficie ricavata dalla retta: {mq:.2f} mq.")
            self.mq.delete(0, "end")
            self.mq.insert(0, f"{mq:.2f}")
        except ValueError as errore:
            messagebox.showerror("Input non valido", str(errore))

    def disegna(self):
        self.ax.clear()
        self.ax.set_xlabel("Superficie (m²)")
        self.ax.set_ylabel("Prezzo (€)")
        self.ax.set_title("Regressione lineare: superficie e prezzo")
        self.ax.grid(alpha=0.25)
        if self.modello is not None:
            x = np.array([r[0] for r in self.dati])
            y = np.array([r[1] for r in self.dati])
            massimo = max(x.max(), self.punto[0] if self.punto else 0) * 1.1
            linea = np.linspace(0, massimo, 150)
            self.ax.plot(linea, self.modello.predict(linea.reshape(-1, 1)), color="tab:orange", label="Retta stimata")
            self.ax.scatter(x, y, label="Dataset", zorder=3)
            for mq, prezzo, nome in self.dati:
                self.ax.annotate(nome, (mq, prezzo), xytext=(5, 5), textcoords="offset points", fontsize=8)
            intercetta = float(self.modello.intercept_)
            self.ax.scatter([0], [intercetta], color="tab:red", zorder=4, label=f"Intercetta: {intercetta:.2f} €")
            self.ax.annotate(f"b = {intercetta:.2f} €", (0, intercetta), xytext=(10, 12), textcoords="offset points")
            self.ax.axhline(0, color="gray", linewidth=0.8)
            self.ax.axvline(0, color="gray", linewidth=0.8)
            if self.punto:
                self.ax.scatter(*self.punto, color="tab:green", marker="*", s=150, zorder=5, label="Previsione")
            self.ax.legend(loc="best")
        self.canvas.draw_idle()


if __name__ == "__main__":
    Applicazione().mainloop()
