"""Esempio essenziale del libro: dati sintetici a scopo didattico."""
from sklearn.linear_model import LinearRegression
import numpy as np

X = np.array([[50], [80], [100]])  # metrature
y = np.array([100000, 150000, 200000])  # prezzi in euro

modello = LinearRegression()
modello.fit(X, y)

print("Intercetta:", modello.intercept_)
print("Coefficiente:", modello.coef_[0])
print("Prezzo previsto:", modello.predict([[120]])[0])
