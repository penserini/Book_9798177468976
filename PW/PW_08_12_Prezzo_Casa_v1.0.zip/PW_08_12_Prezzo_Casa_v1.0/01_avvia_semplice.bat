@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
 echo Eseguire prima 00_installa_ambiente.bat.
 pause
 exit /b 1
)
".venv\Scripts\python.exe" "regressione_semplice.py"
pause
