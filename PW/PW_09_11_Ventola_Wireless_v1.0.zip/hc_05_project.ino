// Mega + HC-05 su Serial1 (TX1=18, RX1=19)
const byte LED_PIN = 8;

void setup() {
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  Serial.begin(115200);   // Debug su USB
  Serial1.begin(9600);    // Default HC-05
  Serial.println("Pronto. Comandi: ON / OFF / T<0-255>");
}

void loop() {
  if (Serial1.available()) {
    String cmd = Serial1.readStringUntil('\n');
    cmd.trim();
    cmd.toUpperCase();

    if (cmd == "ON") {
      digitalWrite(LED_PIN, HIGH);
      Serial1.println("OK ON");
    } else if (cmd == "OFF") {
      digitalWrite(LED_PIN, LOW);
      Serial1.println("OK OFF");
    } else if (cmd.startsWith("T")) {        // luminosità PWM: es. "T128"
      int v = cmd.substring(1).toInt();      // 0..255
      analogWrite(LED_PIN, constrain(v, 0, 255)); // usa pin PWM per effetto graduale (es. D9)
      Serial1.println(String("OK T") + v);
    } else {
      Serial1.println("ERR");
    }
  }
}
