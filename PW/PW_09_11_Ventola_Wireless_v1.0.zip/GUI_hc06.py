# bt06_gui.py
import threading
import queue
import time
import tkinter as tk
from tkinter import ttk, messagebox
import serial
import serial.tools.list_ports

APP_TITLE = "BT-06 Controller"
DEFAULT_BAUD = 9600
TERMINATOR = "\n"  # se serve prova "\r" o "\r\n"

class BT06GUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("560x420")
        self.resizable(False, False)

        # Serial state
        self.ser = None
        self.reader_thread = None
        self.reader_alive = False
        self.rx_queue = queue.Queue()

        # Top row: port + baud + connect
        top = ttk.Frame(self, padding=8)
        top.pack(fill="x")

        ttk.Label(top, text="Porta COM:").pack(side="left")
        self.port_var = tk.StringVar()
        self.port_box = ttk.Combobox(top, textvariable=self.port_var, width=12, state="readonly")
        self.port_box.pack(side="left", padx=(4, 8))

        self.refresh_btn = ttk.Button(top, text="↻", width=3, command=self.refresh_ports)
        self.refresh_btn.pack(side="left")

        ttk.Label(top, text="Baud:").pack(side="left", padx=(12, 4))
        self.baud_var = tk.StringVar(value=str(DEFAULT_BAUD))
        self.baud_entry = ttk.Entry(top, textvariable=self.baud_var, width=8)
        self.baud_entry.pack(side="left")

        self.connect_btn = ttk.Button(top, text="Connetti", command=self.toggle_connection)
        self.connect_btn.pack(side="right")

        # Controls: ON/OFF + slider
        controls = ttk.LabelFrame(self, text="Controlli", padding=8)
        controls.pack(fill="x", padx=8, pady=6)

        self.on_btn = ttk.Button(controls, text="ON", width=10, command=lambda: self.send_cmd("ON"))
        self.off_btn = ttk.Button(controls, text="OFF", width=10, command=lambda: self.send_cmd("OFF"))
        self.on_btn.grid(row=0, column=0, padx=4, pady=4, sticky="w")
        self.off_btn.grid(row=0, column=1, padx=4, pady=4, sticky="w")

        ttk.Label(controls, text="PWM (T0..T255):").grid(row=1, column=0, padx=4, pady=(10, 4), sticky="w")
        self.pwm_var = tk.IntVar(value=128)
        self.pwm_scale = ttk.Scale(controls, from_=0, to=255, variable=self.pwm_var, orient="horizontal")
        self.pwm_scale.grid(row=1, column=1, padx=4, pady=(10, 4), sticky="ew")
        controls.columnconfigure(1, weight=1)

        self.send_pwm_btn = ttk.Button(controls, text="Invia PWM", command=self.send_pwm)
        self.send_pwm_btn.grid(row=1, column=2, padx=8, pady=(10, 4))

        # Free command
        free = ttk.Frame(self, padding=(8, 0))
        free.pack(fill="x")
        ttk.Label(free, text="Comando libero:").pack(side="left")
        self.cmd_var = tk.StringVar(value="ON")
        self.cmd_entry = ttk.Entry(free, textvariable=self.cmd_var, width=18)
        self.cmd_entry.pack(side="left", padx=6)
        ttk.Button(free, text="Invia", command=lambda: self.send_cmd(self.cmd_var.get())).pack(side="left")

        # Log
        logf = ttk.LabelFrame(self, text="Log", padding=8)
        logf.pack(fill="both", expand=True, padx=8, pady=6)
        self.log = tk.Text(logf, height=12, wrap="word", state="disabled")
        self.log.pack(fill="both", expand=True)
        self.clear_btn = ttk.Button(self, text="Pulisci log", command=self.clear_log)
        self.clear_btn.pack(pady=(0,8))

        # Init
        self.after(150, self.refresh_ports)
        self.after(100, self.poll_rx_queue)
        self.protocol("WM_DELETE_WINDOW", self.on_close)

    # -------- Serial helpers --------
    def refresh_ports(self):
        ports = []
        for p in serial.tools.list_ports.comports():
            desc = (p.description or "").lower()
            if "bluetooth" in desc or "standard serial over bluetooth" in desc or "hc-06" in desc or "bt-06" in desc:
                ports.append(p.device)
        # fallback: se non trova etichette bluetooth, mostra tutto
        if not ports:
            ports = [p.device for p in serial.tools.list_ports.comports()]
        self.port_box["values"] = ports
        if ports and not self.port_var.get():
            self.port_var.set(ports[-1])  # spesso la più alta è l'OUTGOING

    def toggle_connection(self):
        if self.ser and self.ser.is_open:
            self.disconnect()
        else:
            self.connect()

    def connect(self):
        port = self.port_var.get().strip()
        if not port:
            messagebox.showwarning(APP_TITLE, "Nessuna porta selezionata.")
            return
        try:
            baud = int(self.baud_var.get().strip())
        except ValueError:
            messagebox.showerror(APP_TITLE, "Baud non valido.")
            return
        try:
            self.ser = serial.Serial(
                port, baud,
                timeout=0.2,
                write_timeout=None,
                rtscts=False, dsrdtr=False
            )
            time.sleep(0.3)  # stabilizza link SPP
            self.reader_alive = True
            self.reader_thread = threading.Thread(target=self.reader_loop, daemon=True)
            self.reader_thread.start()
            self.connect_btn.config(text="Disconnetti")
            self.log_line(f"✅ Connesso a {port} @ {baud}")
        except serial.SerialException as e:
            self.log_line(f"Errore apertura {port}: {e}")

    def disconnect(self):
        self.reader_alive = False
        if self.reader_thread and self.reader_thread.is_alive():
            self.reader_thread.join(timeout=0.8)
        if self.ser:
            try:
                self.ser.close()
            except Exception:
                pass
        self.connect_btn.config(text="Connetti")
        self.log_line("🔌 Disconnesso.")

    def reader_loop(self):
        buf = b""
        try:
            while self.reader_alive and self.ser and self.ser.is_open:
                try:
                    n = self.ser.in_waiting
                    if n:
                        buf += self.ser.read(n)
                        # spezza sulle newlines
                        while b"\n" in buf:
                            line, buf = buf.split(b"\n", 1)
                            line = line.replace(b"\r", b"")
                            self.rx_queue.put(line.decode(errors="ignore"))
                    else:
                        time.sleep(0.05)
                except serial.SerialException:
                    break
        finally:
            self.reader_alive = False

    def poll_rx_queue(self):
        try:
            while True:
                line = self.rx_queue.get_nowait()
                self.log_line(f"RX: {line}")
        except queue.Empty:
            pass
        self.after(60, self.poll_rx_queue)

    # -------- Commands --------
    def send_cmd(self, cmd: str):
        cmd = (cmd or "").strip()
        if not cmd:
            return
        if not (self.ser and self.ser.is_open):
            self.log_line("Non connesso.")
            return
        try:
            payload = (cmd + TERMINATOR).encode("utf-8")
            self.ser.reset_input_buffer()
            self.ser.write(payload)
            self.log_line(f"TX: {cmd}")
        except serial.SerialTimeoutException:
            self.log_line("Write timeout (porta aperta ma link non attivo).")
        except serial.SerialException as e:
            self.log_line(f"Errore invio: {e}")

    def send_pwm(self):
        val = int(self.pwm_var.get())
        self.send_cmd(f"T{val}")

    # -------- UI helpers --------
    def log_line(self, text: str):
        self.log.configure(state="normal")
        self.log.insert("end", text + "\n")
        self.log.see("end")
        self.log.configure(state="disabled")

    def clear_log(self):
        self.log.configure(state="normal")
        self.log.delete("1.0", "end")
        self.log.configure(state="disabled")

    def on_close(self):
        self.disconnect()
        self.destroy()

if __name__ == "__main__":
    BT06GUI().mainloop()
