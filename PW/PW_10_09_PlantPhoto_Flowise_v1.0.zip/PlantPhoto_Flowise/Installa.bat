@echo off
setlocal
cd /d "%~dp0"
if not exist requirements.txt goto missing
if exist ".venv\Scripts\python.exe" goto existing
set "PP_PROBE=%TEMP%\plantphoto_python_%RANDOM%_%RANDOM%.txt"
set "PP_PYTHON="
call :probe py -3.11
if defined PP_PYTHON goto create
call :probe py -3
if defined PP_PYTHON goto create
call :probe python
if defined PP_PYTHON goto create
call :probe python3
if defined PP_PYTHON goto create
if exist "%PP_PROBE%" del "%PP_PROBE%"
echo Python 3.10 o successivo a 64 bit non trovato.
echo Installare Python da https://www.python.org/downloads/windows/
echo Poi riaprire questo BAT. Non e' stata installata alcuna dipendenza.
pause
exit /b 1
:probe
if exist "%PP_PROBE%" del "%PP_PROBE%"
call %* -c "import sys; assert sys.version_info >= (3,10) and sys.maxsize > 2**32; print(sys.executable)" >"%PP_PROBE%" 2>nul
if errorlevel 1 exit /b 0
set "PP_CANDIDATE="
set /p PP_CANDIDATE=<"%PP_PROBE%"
if not defined PP_CANDIDATE exit /b 0
if exist "%PP_CANDIDATE%" set "PP_PYTHON=%PP_CANDIDATE%"
exit /b 0
:create
if exist "%PP_PROBE%" del "%PP_PROBE%"
"%PP_PYTHON%" -m venv .venv
if errorlevel 1 goto failed
:existing
".venv\Scripts\python.exe" -c "import sys; assert sys.version_info >= (3,10) and sys.maxsize > 2**32; print(sys.version)"
if errorlevel 1 goto invalid
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m pip check
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -c "import fastapi,uvicorn,pydantic,pydantic_settings,httpx,PIL,multipart; import app.aula"
if errorlevel 1 goto failed
echo INSTALLAZIONE BACKEND COMPLETATA.
echo Ora importare il flusso in Flowise e compilare .env: leggere README.md.
echo Il collegamento AI non e' ancora stato verificato.
pause
exit /b 0
:invalid
echo Ambiente .venv non compatibile. Rinominarlo e riprovare.
pause
exit /b 1
:missing
echo Manca requirements.txt. Estrarre tutto lo ZIP prima di avviare.
pause
exit /b 1
:failed
echo Installazione non completata. Leggere il primo errore sopra.
pause
exit /b 1
