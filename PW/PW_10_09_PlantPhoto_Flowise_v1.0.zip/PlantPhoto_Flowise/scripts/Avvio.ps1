param([ValidateSet('Locale','Aula','Chiudi')][string]$Mode='Locale')
$ErrorActionPreference='Stop'
$projectRoot=Split-Path $PSScriptRoot -Parent
$python=Join-Path $projectRoot '.venv\Scripts\python.exe'
$identity=[Security.Principal.WindowsIdentity]::GetCurrent()
$elevated=([Security.Principal.WindowsPrincipal]::new($identity)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
$sha=[Security.Cryptography.SHA256]::Create()
$hash=([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($projectRoot.ToLowerInvariant())))).Replace('-','').ToLowerInvariant()
$ruleName='PlantPhoto-Aula-'+$hash.Substring(0,16)
$firewall=Join-Path $PSScriptRoot 'Firewall.ps1'
function Invoke-ProjectFirewall([string]$operation,[string]$ip='',[int]$index=0,[string]$subnet='') {
 $argsLine='-NoProfile -File "'+$firewall+'" -Action '+$operation+' -RuleName '+$ruleName
 if($operation -eq 'Apri'){$argsLine+=' -Address '+$ip+' -InterfaceIndex '+$index+' -Subnet '+$subnet}
 $process=Start-Process -FilePath "$PSHOME\powershell.exe" -Verb RunAs -ArgumentList $argsLine -Wait -PassThru
 if($process.ExitCode -ne 0){throw 'Operazione firewall non completata. Nessun aggiramento delle restrizioni.'}
}
try {
 if($Mode -eq 'Chiudi') {Invoke-ProjectFirewall 'Chiudi';Write-Host 'Questo comando non arresta FastAPI. Per bloccare anche richieste gia ammesse, chiudi accesso in /aula e arresta il servizio.';exit 0}
 if($elevated){throw 'Avvia il BAT con doppio clic normale, NON come amministratore. Solo il firewall richiedera elevazione.'}
 if(-not(Test-Path -LiteralPath $python)){throw 'Manca .venv\Scripts\python.exe nella cartella del progetto.'}
 if(Get-NetTCPConnection -LocalPort 8001 -State Listen -ErrorAction SilentlyContinue){throw 'Porta 8001 gia occupata. Ferma la precedente istanza FastAPI con Ctrl+C.'}
 Set-Location -LiteralPath $projectRoot
 Remove-Item Env:PLANTPHOTO_CLASSROOM_IP -ErrorAction SilentlyContinue
 Remove-Item Env:PLANTPHOTO_CLASSROOM_NET -ErrorAction SilentlyContinue
 if($Mode -eq 'Locale') {
  Write-Host 'Solo locale: nessuna modifica al firewall. Area docente: http://127.0.0.1:8001/docente'
  & $python -m uvicorn app.aula:app --host 127.0.0.1 --port 8001 --no-proxy-headers
  exit $LASTEXITCODE
 }
 $options=@(Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.AddressState -eq 'Preferred' -and $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' })
 if($options.Count -eq 0){throw 'Nessuna interfaccia IPv4 utilizzabile.'}
 for($i=0;$i -lt $options.Count;$i++){Write-Host "[$i] $($options[$i].InterfaceAlias) - $($options[$i].IPAddress)/$($options[$i].PrefixLength)"}
 $selection=Read-Host 'Numero della scheda collegata alla rete aula (non VPN o scheda virtuale)'
 if($selection -notmatch '^\d+$' -or [int]$selection -ge $options.Count){throw 'Selezione non valida.'}
 $chosen=$options[[int]$selection]
 $netProfile=Get-NetConnectionProfile -InterfaceIndex $chosen.InterfaceIndex
 if($netProfile.NetworkCategory -notin @('Public','Private','DomainAuthenticated')){throw 'Profilo non riconosciuto. Nessuna modifica.'}
 Write-Host "Profilo attuale: $($netProfile.NetworkCategory). NON viene modificato."
 $classroomNet=(& $python -c 'import ipaddress,sys; print(ipaddress.ip_network(sys.argv[1],strict=False))' "$($chosen.IPAddress)/$($chosen.PrefixLength)").Trim()
 if($LASTEXITCODE -ne 0 -or -not $classroomNet){throw 'Impossibile determinare sottorete.'}
 Write-Host "Regola richiesta: sottorete $classroomNet -> $($chosen.IPAddress):8001 TCP, solo scheda $($chosen.InterfaceAlias)."
 Write-Host 'Modalita dimostrativa HTTP: rete fidata, nessun dato personale, nessun login docente dalla rete.'
 if((Read-Host 'Confermi questa condizione e apertura TCP 8001 sulla scheda selezionata? Scrivi SI') -cne 'SI'){throw 'Avvio annullato.'}
 $env:PLANTPHOTO_CLASSROOM_IP=$chosen.IPAddress
 $env:PLANTPHOTO_CLASSROOM_NET=$classroomNet
 # La rimozione degli eventuali residui e la nuova regola avvengono nello stesso helper.
 try {
  Invoke-ProjectFirewall 'Apri' $chosen.IPAddress $chosen.InterfaceIndex $classroomNet
  Write-Host 'Pannello docente: http://127.0.0.1:8001/aula'
  Write-Host "Il firewall ammette la sottorete $classroomNet. Nel pannello scegli se autorizzarla tutta oppure solo gli IP elencati."
  Write-Host "Indirizzo studenti: http://$($chosen.IPAddress):8001/ (bloccato fino ad autorizzazione in /aula)"
  Write-Host 'Termina con Ctrl+C e ACCETTA la richiesta UAC di pulizia. Non chiudere con la X.'
  & $python -m uvicorn app.aula:app --host 0.0.0.0 --port 8001 --no-proxy-headers
 } finally {
  Write-Host 'Rimozione della regola firewall del progetto...'
  try {Invoke-ProjectFirewall 'Chiudi'} catch {Write-Host 'PULIZIA NON CONFERMATA: eseguire Chiudi_Accesso_Aula.bat. La regola potrebbe essere ancora presente.' -ForegroundColor Red}
  Remove-Item Env:PLANTPHOTO_CLASSROOM_IP -ErrorAction SilentlyContinue
  Remove-Item Env:PLANTPHOTO_CLASSROOM_NET -ErrorAction SilentlyContinue
 }
} catch {Write-Host $_.Exception.Message -ForegroundColor Red;exit 1}
