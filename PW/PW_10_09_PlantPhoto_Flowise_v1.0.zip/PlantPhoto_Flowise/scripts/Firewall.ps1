param(
 [ValidateSet('Apri','Chiudi')][string]$Action,
 [string]$RuleName,
 [string]$Address='',
 [int]$InterfaceIndex=0,
 [string]$Subnet=''
)
$ErrorActionPreference='Stop'
try {
 if ($RuleName -notmatch '^PlantPhoto-Aula-[a-f0-9]{16}$') { throw 'Identificatore regola non valido.' }
 $identity=[Security.Principal.WindowsIdentity]::GetCurrent()
 if (-not ([Security.Principal.WindowsPrincipal]::new($identity)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw 'Servono privilegi amministrativi per il firewall.' }
 $rules=@(Get-NetFirewallRule -PolicyStore PersistentStore -ErrorAction Stop | Where-Object Name -eq $RuleName)
 foreach ($rule in $rules) {
  if ($rule.Group -ne 'PlantPhoto-Progetto-Aula') { throw 'Conflitto: regola omonima non appartenente al progetto.' }
  $rule | Remove-NetFirewallRule -ErrorAction Stop
 }
 if ($Action -eq 'Apri') {
  if ($Address -notmatch '^\d{1,3}(\.\d{1,3}){3}$') {throw 'IPv4 non valido.'}
  $adapter=Get-NetIPAddress -InterfaceIndex $InterfaceIndex -AddressFamily IPv4 | Where-Object IPAddress -eq $Address
  if (-not $adapter) {throw 'Indirizzo non presente sulla scheda selezionata.'}
  $profile=Get-NetConnectionProfile -InterfaceIndex $InterfaceIndex
  if ($profile.NetworkCategory -notin @('Public','Private','DomainAuthenticated')) {throw 'Profilo di rete non riconosciuto.'}
  if ($Subnet -notmatch '^(\d{1,3}(\.\d{1,3}){3})/(\d|[12]\d|3[0-2])$') {throw 'Sottorete IPv4 CIDR non valida.'}
  $network=[Net.IPAddress]::Parse($Matches[1])
  $prefix=[int]$Matches[3]
  if($network.AddressFamily -ne [Net.Sockets.AddressFamily]::InterNetwork -or $network.ToString() -ne $Matches[1]){throw 'Sottorete IPv4 non valida.'}
  $localBytes=([Net.IPAddress]::Parse($Address)).GetAddressBytes()
  $networkBytes=$network.GetAddressBytes()
  if($prefix -ne [int]$adapter.PrefixLength){throw 'La sottorete non corrisponde alla maschera della scheda selezionata.'}
  for($bit=0;$bit -lt 32;$bit++) {
   $byte=[int][Math]::Floor($bit/8); $mask=1 -shl (7-($bit%8))
   if($bit -lt $prefix){if(($localBytes[$byte] -band $mask) -ne ($networkBytes[$byte] -band $mask)){throw 'Sottorete diversa da quella della scheda selezionata.'}}
   elseif(($networkBytes[$byte] -band $mask) -ne 0){throw 'Indirizzo di rete CIDR non canonico.'}
  }
  $category=if($profile.NetworkCategory -eq 'DomainAuthenticated'){'Domain'}else{[string]$profile.NetworkCategory}
  if (-not (Get-NetFirewallProfile -Name $category).Enabled) {throw 'Il firewall del profilo selezionato risulta disabilitato. Nessuna apertura.'}
  New-NetFirewallRule -PolicyStore PersistentStore -Name $RuleName -DisplayName 'PlantPhoto - Sottorete aula' -Group 'PlantPhoto-Progetto-Aula' -Direction Inbound -Action Allow -Protocol TCP -LocalPort 8001 -LocalAddress $Address -RemoteAddress $Subnet -InterfaceAlias $adapter.InterfaceAlias -Profile $category -EdgeTraversalPolicy Block | Out-Null
  Write-Host 'Regola del progetto creata. Verra rimossa alla chiusura normale.'
 } else {Write-Host 'Regola del progetto rimossa (o gia assente).'}
 exit 0
} catch {Write-Host $_.Exception.Message -ForegroundColor Red; Read-Host 'Premi INVIO'; exit 1}
