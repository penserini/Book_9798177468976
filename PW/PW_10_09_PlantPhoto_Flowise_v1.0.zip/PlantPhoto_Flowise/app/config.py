"""Configurazione di PlantPhoto_Flowise. Test: python -m app.config."""

from functools import lru_cache
from pathlib import Path
from uuid import UUID

from pydantic import HttpUrl, SecretStr, ValidationError, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


PROJECT_ROOT = Path(__file__).resolve().parent.parent
ENV_FILE = PROJECT_ROOT / ".env"


class Settings(BaseSettings):
    """Legge .env; le variabili di ambiente hanno precedenza sul file."""

    model_config = SettingsConfigDict(
        env_file=ENV_FILE,
        env_file_encoding="utf-8-sig",
        case_sensitive=False,
        extra="forbid",
        hide_input_in_errors=True,
    )

    flowise_base_url: HttpUrl
    flowise_chatflow_id: UUID
    flowise_api_key: SecretStr
    teacher_password: SecretStr

    @field_validator("teacher_password")
    @classmethod
    def validate_teacher_password(cls, value: SecretStr) -> SecretStr:
        if len(value.get_secret_value()) < 16:
            raise ValueError("Usare una password docente di almeno 16 caratteri.")
        return value

    @field_validator("flowise_base_url")
    @classmethod
    def validate_base_url(cls, value: HttpUrl) -> HttpUrl:
        if (
            value.username is not None
            or value.password is not None
            or value.query is not None
            or value.fragment is not None
            or value.path not in (None, "", "/")
        ):
            raise ValueError("Usare solo schema, host e porta di Flowise.")
        return value

    @field_validator("flowise_api_key")
    @classmethod
    def validate_api_key(cls, value: SecretStr) -> SecretStr:
        raw = value.get_secret_value().strip()
        if not raw or raw.upper().startswith("INSERISCI"):
            raise ValueError("Inserire il valore della chiave Flowise.")
        if raw.startswith("sk-"):
            raise ValueError("Qui serve la chiave Flowise, non quella OpenAI.")
        if raw == "PlantPhoto_FastAPI" or any(c.isspace() for c in raw):
            raise ValueError("Inserire il segreto Flowise, senza spazi o prefisso Bearer.")
        return SecretStr(raw)

    @property
    def prediction_url(self) -> str:
        base = str(self.flowise_base_url).rstrip("/")
        return f"{base}/api/v1/prediction/{self.flowise_chatflow_id}"


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Carica una volta per processo; riavviare dopo una modifica a .env."""
    return Settings()


def main() -> int:
    """Controllo locale: nessuna richiesta HTTP, nessuna stampa dei segreti."""
    try:
        settings = get_settings()
    except ValidationError as exc:
        print("CONFIGURAZIONE NON VALIDA.")
        print("Controllare i seguenti campi in .env o nelle variabili di ambiente:")
        known_fields = set(Settings.model_fields)
        for error in exc.errors(include_input=False, include_context=False):
            field = str(error["loc"][0]) if error["loc"] else ""
            label = field.upper() if field in known_fields else "CAMPO NON PREVISTO"
            print(f"- {label}: valore mancante, non valido o non previsto.")
        return 1
    except (OSError, UnicodeError):
        print("Impossibile leggere .env: controllare accesso e codifica UTF-8.")
        return 1

    print("CONFIGURAZIONE OK")
    print(f"File .env nella radice: {'presente' if ENV_FILE.is_file() else 'assente'}")
    print(f"Flowise: {settings.flowise_base_url}")
    print("Chatflow ID: formato valido")
    print("Chiave Flowise: presente (valore non mostrato)")
    print("Nessuna richiesta inviata. Autorizzazione della chiave ancora da verificare.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
