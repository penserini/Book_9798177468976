"""Ingresso controllato locale/aula. Avviare con i BAT, senza proxy o workers."""
import os
from ipaddress import ip_address, ip_network
from pathlib import Path
from fastapi import Depends, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel, Field
from starlette.middleware.trustedhost import TrustedHostMiddleware
from app.main import app
from app.review import teacher, action

LAN_IP = os.environ.get('PLANTPHOTO_CLASSROOM_IP', '')
LAN_NET = os.environ.get('PLANTPHOTO_CLASSROOM_NET', '')
NETWORK = ip_network(LAN_NET, strict=False) if LAN_NET else None
if LAN_IP and (not NETWORK or ip_address(LAN_IP) not in NETWORK):
    raise RuntimeError('Configurazione rete aula incoerente.')

# Stato volutamente non persistente: ogni avvio richiede nuova autorizzazione.
opened = False
whole_network = False
stations = {}
for middleware in app.user_middleware:
    if middleware.cls is TrustedHostMiddleware:
        middleware.kwargs['allowed_hosts'] = ['127.0.0.1', 'localhost'] + ([LAN_IP] if LAN_IP else [])


@app.middleware('http')
async def classroom_gate(request: Request, call_next):
    peer = request.client.host if request.client else ''
    try:
        address = ip_address(peer)
        local = address.is_loopback
    except ValueError:
        local = False
    # Non si usano X-Forwarded-For o altri header controllabili dal browser.
    if not local:
        path = request.url.path
        public = (request.method == 'GET' and (path in ('/', '/api/archivio') or
                  (path.startswith('/api/archivio/') and path.endswith('/foto')))) or (
                  request.method == 'POST' and path == '/api/proposte')
        if not public:
            return JSONResponse({'detail':'Operazione riservata al PC docente.'}, status_code=403)
        in_classroom_network = bool(NETWORK and address.version == 4 and address in NETWORK)
        authorized = whole_network or peer in stations
        if not LAN_IP or not opened or not in_classroom_network or not authorized:
            return JSONResponse({'detail':'Accesso aula chiuso o IP non autorizzato.'}, status_code=403)
    response = await call_next(request)
    response.headers['Cache-Control'] = 'no-store'
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['Referrer-Policy'] = 'no-referrer'
    return response


class ClassroomSettings(BaseModel):
    enabled: bool
    whole_network: bool = False
    entries: str = Field(max_length=12000)


@app.get('/aula', dependencies=[Depends(teacher)], include_in_schema=False)
def classroom_page():
    return FileResponse(Path(__file__).parent/'web'/'aula.html')


@app.get('/api/docente/aula', dependencies=[Depends(teacher)])
def classroom_status():
    return {'enabled':opened, 'whole_network':whole_network,
            'entries':stations, 'network':LAN_NET,
            'url':f'http://{LAN_IP}:8001/' if LAN_IP else '',
            'mode':'aula' if LAN_IP else 'locale'}


@app.post('/api/docente/aula', dependencies=[Depends(action)])
def classroom_update(body: ClassroomSettings):
    global opened, whole_network, stations
    new = {}
    for line in body.entries.splitlines():
        if not line.strip(): continue
        parts = line.split(';', 1)
        try:
            address = ip_address(parts[0].strip())
        except ValueError:
            raise HTTPException(422,'Indirizzo IP non valido.') from None
        if address.version != 4 or address.is_loopback or not NETWORK or address not in NETWORK or str(address)==LAN_IP or address in (NETWORK.network_address, NETWORK.broadcast_address):
            raise HTTPException(422,'Usare IP-studente IPv4 della sottorete selezionata, diversi dal PC docente.')
        new[str(address)] = parts[1].strip()[:80] if len(parts)>1 else ''
    if len(new)>100: raise HTTPException(422,'Massimo 100 postazioni.')
    if body.enabled and not LAN_IP:
        raise HTTPException(422,'Avviare in modalita aula prima di abilitare gli studenti.')
    if body.enabled and not body.whole_network and not new:
        raise HTTPException(422,'Inserire almeno un IP oppure autorizzare tutta la sottorete.')
    stations = new
    whole_network = body.whole_network
    opened = body.enabled
    return classroom_status()
