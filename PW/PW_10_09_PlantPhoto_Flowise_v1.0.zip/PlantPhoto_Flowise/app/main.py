"""Backend locale PlantPhoto_Flowise: primo collaudo testuale.

Avvio dalla radice: python -m uvicorn app.main:app --host 127.0.0.1 --port 8001
Non esporre in LAN: autenticazione utenti e limiti di consumo non implementati.
"""

from contextlib import asynccontextmanager
from pathlib import Path
from typing import Annotated

from fastapi import Depends, FastAPI, HTTPException, Request, File, Form, UploadFile
from starlette.concurrency import run_in_threadpool
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse, FileResponse
from pydantic import BaseModel, ConfigDict, Field, ValidationError

from app.config import get_settings
from app.services.flowise_client import FlowiseClient, FlowiseError
from app.services.image_service import MAX_IMAGE_BYTES, ImageValidationError, prepare_image
from app.services.review_store import ReviewStore
from app.review import router as review_router, teacher, action
from starlette.middleware.trustedhost import TrustedHostMiddleware


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Valida la configurazione all'avvio, senza interrogare Flowise."""
    try:
        settings = get_settings()
    except (ValidationError, OSError, UnicodeError):
        raise RuntimeError(
            "Configurazione non valida. Eseguire: python -m app.config"
        ) from None
    app.state.flowise_client = FlowiseClient(settings)
    app.state.review_store = ReviewStore(Path(__file__).resolve().parent.parent / 'data' / 'archivio.sqlite3')
    yield


app = FastAPI(
    title="PlantPhoto_Flowise",
    description=(
        "Laboratorio locale: testo e foto tramite Flowise. "
        "Interfaccia web locale; autenticazione utenti non ancora implementata."
    ),
    version="0.4.0",
    docs_url=None, redoc_url=None, openapi_url=None,
    lifespan=lifespan,
)
app.add_middleware(TrustedHostMiddleware, allowed_hosts=['127.0.0.1','localhost','testserver'])
app.include_router(review_router)


class QuestionRequest(BaseModel):
    """Dati accettati dal browser: nessuna chiave o URL del provider."""
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    question: str = Field(
        min_length=1,
        max_length=2000,
        description="Domanda testuale, da 1 a 2000 caratteri.",
        examples=["Ciao! Presentati brevemente in italiano."],
    )


class AnswerResponse(BaseModel):
    text: str


def get_flowise_client(request: Request) -> FlowiseClient:
    """Dipendenza sostituibile nei test, senza chiamare servizi reali."""
    return request.app.state.flowise_client


@app.exception_handler(RequestValidationError)
async def invalid_request(request: Request, exc: RequestValidationError):
    # Non riflettere nel browser il corpo ricevuto: potrebbe contenere segreti
    # incollati per errore. Il dettaglio e' volutamente fisso.
    return JSONResponse(
        status_code=422,
        content={
            "detail": (
                "Dati non validi: controllare i campi richiesti in /docs. "
                "La domanda deve contenere da 1 a 2000 caratteri."
            )
        },
    )


@app.get("/", response_class=FileResponse, include_in_schema=False)
async def root():
    page = Path(__file__).resolve().parent / "web" / "review.html"
    if not page.is_file():
        raise HTTPException(503, "Manca app/web/index.html: copiare il file nel progetto.")
    return FileResponse(page, headers={"Cache-Control": "no-store"})


@app.get("/health", tags=["Stato"])
async def health() -> dict[str, str]:
    """Stato del backend; NON verifica rete, chiavi o disponibilita del modello."""
    return {"status": "ok", "service": "PlantPhoto_Flowise"}


@app.post("/api/ask", response_model=AnswerResponse, tags=["Chat"], dependencies=[Depends(action)])
async def ask(
    body: QuestionRequest,
    client: Annotated[FlowiseClient, Depends(get_flowise_client)],
) -> AnswerResponse:
    """Una chiamata reale: puo consumare credito OpenAI tramite Flowise."""
    try:
        result = await client.ask(body.question)
    except FlowiseError as exc:
        # Il client produce messaggi controllati, senza risposta grezza o header.
        # 502 indica un problema nel servizio a valle, non il codice di Flowise.
        raise HTTPException(status_code=502, detail=str(exc)) from None

    secret = get_settings().flowise_api_key.get_secret_value()
    text = result["text"].replace(secret, "[CHIAVE NASCOSTA]")
    return AnswerResponse(text=text)


@app.post("/api/analyze-image", response_model=AnswerResponse, tags=["Foto"], dependencies=[Depends(action)])
async def analyze_image(
    client: Annotated[FlowiseClient, Depends(get_flowise_client)],
    file: Annotated[UploadFile, File(description="Foto JPEG, PNG o WebP: massimo 5 MiB e 20 megapixel.")],
    question: Annotated[str, Form(min_length=1, max_length=2000)] = (
        "Osserva la fotografia. Descrivi le caratteristiche visibili delle foglie "
        "e della pianta. Proponi una possibile identificazione soltanto se ci "
        "sono elementi sufficienti, spiegando gli eventuali dubbi. Non dedurre "
        "l'umidita interna del terreno dalla fotografia."
    ),
) -> AnswerResponse:
    """Invia foto e domanda a Flowise/OpenAI: puo consumare credito."""
    try:
        if not question.strip():
            raise HTTPException(422, "La domanda non puo essere vuota.")
        data = await file.read(MAX_IMAGE_BYTES + 1)
        if len(data) > MAX_IMAGE_BYTES:
            raise HTTPException(413, "La foto supera 5 MiB.")
        try:
            upload = await run_in_threadpool(prepare_image, data)
        except ImageValidationError as exc:
            raise HTTPException(422, str(exc)) from None
    finally:
        await file.close()
    try:
        result = await client.ask(question.strip(), uploads=[upload])
    except FlowiseError as exc:
        raise HTTPException(502, str(exc)) from None
    secret = get_settings().flowise_api_key.get_secret_value()
    return AnswerResponse(text=result["text"].replace(secret, "[CHIAVE NASCOSTA]"))
