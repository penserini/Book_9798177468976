"""Archivio SQLite locale: fotografie BLOB, nessuna cartella pubblica."""
import sqlite3
from uuid import uuid4
from datetime import datetime, timezone


class ReviewStore:
    def __init__(self, path):
        self.path = path
        path.parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as db:
            db.execute('''CREATE TABLE IF NOT EXISTS proposals (
                id TEXT PRIMARY KEY, created TEXT NOT NULL, question TEXT NOT NULL,
                image BLOB NOT NULL, mime TEXT NOT NULL, status TEXT NOT NULL,
                answer TEXT NOT NULL DEFAULT '', error TEXT NOT NULL DEFAULT '')''')
            db.execute("UPDATE proposals SET status='errore', error='Avvio dopo interruzione: esito AI incerto. Nessun reinvio automatico.' WHERE status='elaborazione'")

    def connect(self):
        db = sqlite3.connect(self.path, timeout=10)
        db.row_factory = sqlite3.Row
        return db

    def create(self, question, image, mime):
        ident = str(uuid4())
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            # Limite del laboratorio, compresi gli elementi nel cestino.
            if db.execute('SELECT count(*) FROM proposals').fetchone()[0] >= 200:
                raise ValueError('Archivio pieno (200 proposte). Contattare il docente.')
            db.execute('INSERT INTO proposals(id,created,question,image,mime,status) VALUES(?,?,?,?,?,?)',
                       (ident, datetime.now(timezone.utc).isoformat(), question, image, mime, 'attesa'))
        return ident

    def listing(self, public=False):
        with self.connect() as db:
            where = " WHERE status='pubblicata'" if public else ''
            return [dict(r) for r in db.execute('SELECT id,created,question,status,answer,error FROM proposals'+where+' ORDER BY created DESC')]

    def get(self, ident):
        with self.connect() as db:
            row = db.execute('SELECT * FROM proposals WHERE id=?', (ident,)).fetchone()
            return dict(row) if row else None

    def change(self, ident, allowed, target, **fields):
        assert set(fields) <= {'question','answer','error'}
        assignments = ','.join(['status=?']+[f'{key}=?' for key in fields])
        placeholders = ','.join('?' for _ in allowed)
        with self.connect() as db:
            cursor = db.execute(f'UPDATE proposals SET {assignments} WHERE id=? AND status IN ({placeholders})',
                                [target,*fields.values(),ident,*allowed])
            return cursor.rowcount == 1
