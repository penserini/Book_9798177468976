"""Client testuale Flowise. Avvio: python -m app.services.flowise_client."""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING, Any

import httpx

if TYPE_CHECKING:
    from app.config import Settings


class FlowiseError(Exception):
    """Errore leggibile, senza header o corpo grezzo della risposta."""


class FlowiseClient:
    """Invia domande al Chatflow configurato; non chiama direttamente OpenAI."""

    def __init__(
        self,
        settings: Settings,
        *,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self._settings = settings
        # Il transport opzionale permette test simulati senza rete.
        self._transport = transport

    async def ask(self, question: str, *, uploads: list[dict[str, str]] | None = None) -> dict[str, Any]:
        """Una richiesta, senza retry automatici e senza streaming."""
        if not isinstance(question, str) or not question.strip():
            raise FlowiseError("La domanda non puo essere vuota.")

        headers = {
            "Authorization": (
                "Bearer " + self._settings.flowise_api_key.get_secret_value()
            ),
            "Accept": "application/json",
        }
        payload = {"question": question.strip(), "streaming": False}
        if uploads:
            payload["uploads"] = uploads
        timeout = httpx.Timeout(connect=10, read=120, write=30, pool=10)

        try:
            # trust_env=False evita proxy e credenziali implicite del sistema
            # per questo client locale. Nessun redirect automatico.
            async with httpx.AsyncClient(
                timeout=timeout,
                follow_redirects=False,
                trust_env=False,
                transport=self._transport,
            ) as client:
                response = await client.post(
                    self._settings.prediction_url,
                    headers=headers,
                    json=payload,
                )
        except httpx.TimeoutException:
            raise FlowiseError(
                "Tempo di attesa superato. Flowise potrebbe avere gia elaborato "
                "la richiesta: nessun nuovo tentativo automatico."
            ) from None
        except httpx.ConnectError:
            raise FlowiseError(
                "Connessione non riuscita: verificare Flowise avviato, "
                "indirizzo e porta nel file .env."
            ) from None
        except httpx.RequestError:
            raise FlowiseError("Errore di comunicazione con Flowise.") from None
        finally:
            headers.clear()

        if not response.is_success:
            status = response.status_code
            # Si riconosce anche il 500 Unauthorized osservato nel laboratorio.
            # Il corpo viene esaminato, ma non riportato nell'errore pubblico.
            body = response.text.lower()
            if "invalid chatflow id" in body:
                detail = "Chatflow ID non riconosciuto: verificare .env."
            elif status in (401, 403) or "unauthorized" in body:
                detail = (
                    "Accesso rifiutato. Verificare chiave Flowise e associazione "
                    "al Chatflow; se persiste, consultare i log locali per "
                    "distinguere il rifiuto Flowise da quello del provider."
                )
            elif status == 429:
                detail = "Limite di richieste o quota: controllare i log locali."
            else:
                detail = "Richiesta non riuscita: controllare i log locali di Flowise."
            raise FlowiseError(f"HTTP {status}. {detail}")

        try:
            result = response.json()
        except ValueError:
            raise FlowiseError("Flowise non ha restituito JSON valido.") from None

        if not isinstance(result, dict) or result.get("success") is False:
            raise FlowiseError("Risposta Flowise non valida o con esito negativo.")
        text = result.get("text")
        if not isinstance(text, str) or not text.strip():
            raise FlowiseError("Nella risposta Flowise manca un testo utilizzabile.")
        return result


async def main() -> int:
    from pydantic import ValidationError
    from app.config import get_settings

    try:
        settings = get_settings()
    except (ValidationError, OSError, UnicodeError):
        print("Configurazione non valida. Eseguire prima: python -m app.config")
        return 1

    question = "Ciao! Presentati brevemente in italiano."
    print("TEST REALE: una richiesta a Flowise; puo consumare credito OpenAI.")
    print(f"Domanda: {question}")
    try:
        result = await FlowiseClient(settings).ask(question)
    except FlowiseError as exc:
        print(f"TEST NON RIUSCITO: {exc}")
        return 1

    print("RISPOSTA RICEVUTA DA FLOWISE")
    # Difesa aggiuntiva: non stampare la chiave nemmeno se venisse riflessa.
    secret = settings.flowise_api_key.get_secret_value()
    print(result["text"].replace(secret, "[CHIAVE NASCOSTA]"))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(asyncio.run(main()))
    except KeyboardInterrupt:
        print("Test interrotto; la richiesta potrebbe essere gia arrivata a Flowise.")
        raise SystemExit(130)
