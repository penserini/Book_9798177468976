"""Controllo delle foto e preparazione del payload Flowise, senza modificarle."""

import base64
from io import BytesIO

from PIL import Image, UnidentifiedImageError

MAX_IMAGE_BYTES = 5 * 1024 * 1024
MAX_IMAGE_PIXELS = 20_000_000


class ImageValidationError(ValueError):
    pass


def prepare_image(data: bytes) -> dict[str, str]:
    """Verifica i byte reali; non si fida di estensione o MIME del browser.

    Il nome originale non viene inoltrato. I byte, inclusi eventuali metadati
    EXIF, sono invariati: usare fotografie prive di informazioni sensibili.
    """
    if not data:
        raise ImageValidationError("Il file e vuoto.")
    if len(data) > MAX_IMAGE_BYTES:
        raise ImageValidationError("La foto supera 5 MiB.")
    formats = {"JPEG": ("image/jpeg", "jpg"), "PNG": ("image/png", "png"),
               "WEBP": ("image/webp", "webp")}
    try:
        with Image.open(BytesIO(data)) as im:
            if im.format not in formats:
                raise ImageValidationError("Usare una foto JPEG, PNG o WebP.")
            if im.width * im.height > MAX_IMAGE_PIXELS:
                raise ImageValidationError("La foto supera 20 megapixel: ridurla prima del caricamento.")
            if getattr(im, "n_frames", 1) != 1:
                raise ImageValidationError("Le immagini animate non sono accettate.")
            mime, extension = formats[im.format]
            im.verify()
        # verify non decodifica tutti i formati: load rileva anche troncamenti.
        with Image.open(BytesIO(data)) as im:
            im.load()
    except ImageValidationError:
        raise
    except (UnidentifiedImageError, OSError, ValueError, SyntaxError,
            Image.DecompressionBombError):
        raise ImageValidationError("File non riconosciuto o immagine danneggiata.") from None
    encoded = base64.b64encode(data).decode("ascii")
    return {"data": f"data:{mime};base64,{encoded}", "type": "file",
            "name": f"pianta.{extension}", "mime": mime}
