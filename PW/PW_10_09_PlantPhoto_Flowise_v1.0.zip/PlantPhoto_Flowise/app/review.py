"""Proposte pubbliche locali; approvazione e pubblicazione solo docente."""
import secrets
from typing import Annotated
from pathlib import Path
from fastapi import APIRouter, Depends, HTTPException, Request, UploadFile, File, Form, Response
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field, ConfigDict
from starlette.concurrency import run_in_threadpool
from app.config import get_settings
from app.services.image_service import prepare_image, ImageValidationError, MAX_IMAGE_BYTES
from app.services.flowise_client import FlowiseError

security = HTTPBasic()

def teacher(credentials: Annotated[HTTPBasicCredentials, Depends(security)]):
    valid_user = secrets.compare_digest(credentials.username.encode(), b'docente')
    valid_password = secrets.compare_digest(credentials.password.encode(), get_settings().teacher_password.get_secret_value().encode())
    if not (valid_user and valid_password):
        raise HTTPException(401, 'Credenziali docente non valide', headers={'WWW-Authenticate':'Basic realm="Docente"'})

def action(request: Request, _: Annotated[None, Depends(teacher)]):
    # Nessun CORS: altri siti non possono aggiungere questo header senza preflight.
    if request.headers.get('X-Teacher-Action') != '1':
        raise HTTPException(403, 'Azione consentita solo dall’interfaccia docente.')
    origin = request.headers.get('origin')
    if origin and origin != str(request.base_url).rstrip('/'):
        raise HTTPException(403, 'Origine non autorizzata.')

router = APIRouter()
admin = APIRouter(prefix='/api/docente', dependencies=[Depends(teacher)])

class Edit(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra='forbid')
    question: str = Field(min_length=1, max_length=2000)

class Publication(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra='forbid')
    answer: str = Field(min_length=1, max_length=20000)

def item(request, ident):
    row = request.app.state.review_store.get(ident)
    if row is None: raise HTTPException(404, 'Proposta non trovata')
    return row

def transition(request, ident, allowed, target, **fields):
    if not request.app.state.review_store.change(ident, allowed, target, **fields):
        raise HTTPException(409, 'Stato cambiato o operazione non consentita. Aggiornare la lista.')

@router.get('/docente', dependencies=[Depends(teacher)], include_in_schema=False)
def teacher_page():
    return FileResponse(Path(__file__).parent/'web'/'review.html', headers={'Cache-Control':'no-store'})

@router.get('/api/archivio')
def archive(request: Request):
    return request.app.state.review_store.listing(public=True)

@router.get('/api/archivio/{ident}/foto')
def published_photo(ident: str, request: Request):
    row = item(request, ident)
    if row['status'] != 'pubblicata': raise HTTPException(404, 'Foto non pubblicata')
    return Response(row['image'], media_type=row['mime'], headers={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'})

@router.post('/api/proposte', status_code=201)
async def propose(request: Request, file: Annotated[UploadFile, File()], question: Annotated[str, Form(min_length=1,max_length=2000)]):
    try:
        question = question.strip()
        if not question: raise HTTPException(422, 'Scrivere una domanda')
        data = await file.read(MAX_IMAGE_BYTES+1)
        if len(data)>MAX_IMAGE_BYTES: raise HTTPException(413, 'Foto oltre 5 MiB')
        try: upload = await run_in_threadpool(prepare_image, data)
        except ImageValidationError as exc: raise HTTPException(422,str(exc)) from None
        try: ident = request.app.state.review_store.create(question,data,upload['mime'])
        except ValueError as exc: raise HTTPException(409,str(exc)) from None
        return {'id':ident,'status':'attesa','message':'Salvata sul PC docente. Nessuna richiesta AI inviata.'}
    finally: await file.close()

@admin.get('/proposte')
def queue(request: Request): return request.app.state.review_store.listing()

@admin.get('/proposte/{ident}/foto')
def private_photo(ident: str, request: Request):
    row=item(request,ident)
    return Response(row['image'],media_type=row['mime'],headers={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'})

@admin.post('/proposte/{ident}/invia', dependencies=[Depends(action)])
async def approve(ident: str, body: Edit, request: Request):
    row=item(request,ident)
    transition(request,ident,['attesa','errore'],'elaborazione',question=body.question,error='')
    try:
        upload=await run_in_threadpool(prepare_image,row['image'])
        result=await request.app.state.flowise_client.ask(body.question,uploads=[upload])
        answer=result['text'].replace(get_settings().flowise_api_key.get_secret_value(),'[CHIAVE NASCOSTA]')
        transition(request,ident,['elaborazione'],'revisione',answer=answer)
    except Exception:
        # Esito remoto potenzialmente incerto: nessun retry automatico.
        transition(request,ident,['elaborazione'],'errore',error='Elaborazione non completata. Potrebbe essere stata addebitata. Verificare Flowise prima di un nuovo invio.')
        raise HTTPException(502,'Elaborazione non completata; consultare lo stato della proposta.') from None
    return {'status':'revisione'}

@admin.post('/proposte/{ident}/pubblica', dependencies=[Depends(action)])
def publish(ident: str, body: Publication, request: Request):
    transition(request,ident,['revisione'],'pubblicata',answer=body.answer)
    return {'status':'pubblicata'}

@admin.post('/proposte/{ident}/cestino', dependencies=[Depends(action)])
def trash(ident: str, request: Request):
    transition(request,ident,['attesa','errore','revisione','pubblicata'],'cestino')
    return {'status':'cestino'}

@admin.post('/proposte/{ident}/ripristina', dependencies=[Depends(action)])
def restore(ident: str, request: Request):
    row=item(request,ident)
    target='revisione' if row['answer'] else 'attesa'
    transition(request,ident,['cestino'],target)
    return {'status':target}

router.include_router(admin)
