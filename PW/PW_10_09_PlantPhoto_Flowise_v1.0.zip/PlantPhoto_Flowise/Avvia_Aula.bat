@echo off
setlocal
set "PLANTPHOTO_BOOT_ROOT=%~dp0"
cd /d "%~dp0"
echo Verifica e sblocco mirato dei due script PlantPhoto...
powershell.exe -NoProfile -Command "$ErrorActionPreference='Stop'; try { if ((Get-ExecutionPolicy -Scope MachinePolicy) -ne 'Undefined' -or (Get-ExecutionPolicy -Scope UserPolicy) -ne 'Undefined') { throw 'Policy di gruppo presente: chiedere al responsabile IT.' }; if ((Get-ExecutionPolicy) -ne 'RemoteSigned') { throw 'Policy diversa da RemoteSigned: nessuna modifica automatica.' }; $targets=@(@('Avvio.ps1','dbe32a5abb2650d1530975325cfe0ca7b0fe1cef6b492449c1fba8fa92ec1df1','949f19741ec8040ff6d317e9cfac4051a831ea800aa4dd0692678adceb1a12b5'),@('Firewall.ps1','6fe22afff367216aef5543d3b71ed5012a92e013f683cfb3dc87fa331c28211e','a34caf7b94cd1fbfc0d016e5b378039e22e7494233605da01caf274bcb4c3599')); foreach ($t in $targets) { $p=Join-Path $env:PLANTPHOTO_BOOT_ROOT ('scripts\'+$t[0]); $h=(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash; if ($h -ne $t[1] -and $h -ne $t[2]) { throw ('Contenuto diverso dalla versione verificata: '+$t[0]+'. Nessun file sbloccato.') } }; foreach ($t in $targets) { $p=Join-Path $env:PLANTPHOTO_BOOT_ROOT ('scripts\'+$t[0]); Unblock-File -LiteralPath $p; Write-Host ('File autorizzato: '+$t[0]) }; exit 0 } catch { Write-Host $_.Exception.Message -ForegroundColor Red; exit 1 }"
if errorlevel 1 goto failed
powershell.exe -NoProfile -File "%~dp0scripts\Avvio.ps1" -Mode Aula
set "PLANTPHOTO_EXIT=%ERRORLEVEL%"
pause
exit /b %PLANTPHOTO_EXIT%
:failed
echo Avvio interrotto. Nessuna policy modificata.
pause
exit /b 1
