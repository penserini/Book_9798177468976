# PW 10.09 — PlantPhoto con Flowise (v1.0)

Laboratorio didattico di Loris Penserini: fotografia e domanda → revisione del docente → analisi AI tramite Flowise/OpenAI → risposta controllata e pubblicata nell’archivio.

## Contenuto e requisiti

`app/` contiene il backend FastAPI e le pagine web. `flowise/Analisi_Pianta_OpenAI_Chatflow.json` contiene il flusso esportato, senza credenziali. `scripts/` e i BAT originali gestiscono avvio locale/aula e firewall. `requirements.txt`, `Installa.bat`, `Installa_Flowise.bat`, `Avvia_Flowise.bat`, `.env` e `.env.example` completano la preparazione del progetto. L’archivio parte vuoto e viene creato in `data/archivio.sqlite3` al primo avvio.

Servono Windows 10/11 per i BAT e la modalità aula, Python 3.10 o successivo a 64 bit (3.11 consigliato), Node.js/npm compatibili con la versione Flowise scelta e un account OpenAI con accesso API e credito disponibile. Un abbonamento ChatGPT non sostituisce il credito API. La guida Flowise indica Node 18.15 o 20 e successivi: verificare anche i requisiti della versione effettivamente installata; preferire una versione Node LTS supportata da Flowise. Su altri sistemi il backend è avviabile manualmente, ma gli script aula/firewall sono per Windows.

La versione Flowise dell’esportazione non è stata fornita: non è stato possibile fissare la stessa versione nel rilascio. Il BAT opzionale installa la versione disponibile via npm, quindi una nuova installazione richiede prova di importazione e analisi foto. Le dipendenze Python hanno intervalli di versione, non un lock completo.

## 1. Installare il backend

Estrarre tutto lo ZIP in una cartella scrivibile. Aprire `PlantPhoto_Flowise` e avviare `Installa.bat` con doppio clic normale. Rileva Python tramite i launcher/comandi disponibili, crea o riutilizza `.venv` e installa le dipendenze. Non installa Python né modifica il firewall o le policy PowerShell. Se Python manca, installarlo da https://www.python.org/downloads/windows/ e riavviare il BAT.

Il controllo delle dipendenze non significa che le chiavi o il collegamento a Flowise siano già configurati. Non sovrascrive il proprio `.env` o database. Non distribuire `.venv` su altri PC.

Alternativa manuale dalla cartella del progetto:

```bat
py -3 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
```

## 2. Installare e avviare Flowise

Se Flowise è già installato e funzionante, usare il proprio avvio abituale e saltare l’installazione. Per una nuova installazione, installare Node.js con npm da https://nodejs.org/ quindi eseguire `Installa_Flowise.bat`. Questo BAT esegue `npm install -g flowise`: scarica pacchetti, richiede Internet e installa nel percorso globale npm del proprio ambiente. Non usare come amministratore per aggirare errori di accesso; scegliere un’installazione npm scrivibile dal proprio utente.

Avviare `Avvia_Flowise.bat` e aprire http://127.0.0.1:3000. Tenere aperto il terminale. Se si usa una diversa installazione Flowise, avviarla con il suo launcher.

## 3. Importare il flusso e configurare OpenAI

1. In Flowise creare un nuovo Chatflow vuoto.
2. Nel canvas aprire l’ingranaggio e scegliere **Load Chatflow**.
3. Selezionare `flowise/Analisi_Pianta_OpenAI_Chatflow.json`.
4. Nel nodo OpenAI creare/selezionare la propria credenziale OpenAI. Il JSON non include la credenziale dell’autore.
5. Verificare il modello `gpt-4o-mini`, temperatura `0.2` e **Allow Image Uploads** attivo. Se il modello non è disponibile sul proprio account, scegliere un modello compatibile con immagini e verificare il risultato.
6. Salvare il Chatflow con il dischetto.
7. Provare una fotografia nel pannello chat Flowise.

Il flusso include OpenAI, Buffer Memory e Conversation Chain, con istruzioni didattiche in italiano. Non contiene strumenti di ricerca sul Web. L’export contiene nodi e collegamenti; controllare separatamente le impostazioni del Chatflow e di caricamento immagini nella propria versione.

## 4. Collegare backend e flusso

Creare una chiave API Flowise e associarla al Chatflow nelle impostazioni di accesso (API Key). Copiare il valore segreto della chiave, non il suo nome. Recuperare l’ID del Chatflow dall’URL del canvas o dal pannello API `</>`: è un UUID.

Aprire `.env` con un editor e sostituire tutti i segnaposto:

| Campo | Valore da inserire |
| --- | --- |
| `FLOWISE_BASE_URL` | Indirizzo di Flowise, normalmente `http://127.0.0.1:3000` |
| `FLOWISE_CHATFLOW_ID` | UUID del proprio Chatflow salvato |
| `FLOWISE_API_KEY` | Segreto della chiave Flowise associata al flusso, senza `Bearer` |
| `TEACHER_PASSWORD` | Password personale docente di almeno 16 caratteri |

La chiave **OpenAI** resta nelle credenziali Flowise. La chiave **Flowise** autentica la richiesta del backend al Chatflow. La password **docente** protegge il pannello locale. Nessuna di queste credenziali va inviata agli studenti.

Il `.env` fornito è intenzionalmente incompleto: non avviare il servizio prima di compilarlo. Se la password contiene caratteri speciali, racchiudere il valore tra virgolette secondo la sintassi dotenv. Verificare dalla cartella del progetto:

```bat
.venv\Scripts\python.exe -m app.config
```

Deve comparire `CONFIGURAZIONE OK`. Il controllo è locale: non verifica autorizzazione delle chiavi o disponibilità del provider. Riavviare il backend dopo ogni modifica al `.env`.

## 5. Primo avvio locale e prova completa

Eseguire `Avvia_Locale.bat` con doppio clic normale. I BAT originali richiedono una policy PowerShell effettiva `RemoteSigned` e assenza di policy di gruppo; se si fermano, seguire il messaggio e consultare il responsabile del PC. Non cambiano automaticamente le policy.

Per la sola modalità locale è disponibile anche l’avvio manuale, senza script PowerShell:

```bat
.venv\Scripts\python.exe -m uvicorn app.aula:app --host 127.0.0.1 --port 8001 --no-proxy-headers
```

1. Aprire http://127.0.0.1:8001/ e caricare una foto JPEG, PNG o WebP con una domanda.
2. La proposta viene salvata in attesa: non parte automaticamente una chiamata AI.
3. Aprire http://127.0.0.1:8001/docente. Login: nome utente `docente`, password scelta in `.env`.
4. Selezionare la proposta, controllare la domanda e inviarla all’AI. Questa azione può consumare credito OpenAI.
5. Controllare/modificare la risposta e pubblicarla. Verificare che compaia nell’archivio pubblico.
6. Arrestare il backend con Ctrl+C nel terminale.

Limiti foto: 5 MiB, 20 megapixel, una sola immagine non animata. Archivio: massimo 200 record, compresi quelli nel cestino. I byte fotografici e gli eventuali metadati sono conservati/inoltrati: scegliere foto adatte alla condivisione.

## 6. Modalità aula

Prima completare la prova locale. Leggere `LEGGIMI_AULA.txt`, soprattutto avvio, scelta sottorete e chiusura. Le prime istruzioni di copia/unione di quel file descrivono l’aggiornamento storico: in questo ZIP i file sono già assemblati e `.env` deve essere compilato.

Avviare `Avvia_Aula.bat` normalmente, selezionare la scheda di rete e confermare l’apertura della porta 8001. Solo il firewall richiede elevazione UAC. Aprire http://127.0.0.1:8001/aula sul PC docente e autorizzare gli IP delle postazioni oppure tutta la sottorete. Gli studenti usano l’indirizzo del PC docente mostrato dal pannello; le funzioni docente rimangono locali. Flowise non va aperto agli studenti sulla porta 3000.

Chiudere l’accesso dal pannello, fermare con Ctrl+C e accettare la pulizia firewall. Se il processo viene chiuso forzatamente, eseguire `Chiudi_Accesso_Aula.bat`. Usare solo nella LAN didattica prevista dagli script; non pubblicare il servizio su Internet. I file PowerShell originali e i relativi hash nei BAT sono stati mantenuti invariati.

## Problemi comuni

- Configurazione non valida: compilare `.env`, controllare UUID e password; eseguire `python -m app.config` usando Python della `.venv`.
- HTTP 401/403 o Unauthorized: verificare chiave Flowise e associazione al Chatflow; controllare poi la credenziale OpenAI nei log Flowise.
- Porta 8001 occupata: fermare il precedente backend.
- Modulo IBM Watsonx mancante (`ibm-cloud-sdk-core`) durante l’avvio Flowise: riguarda l’installazione Flowise. Il JSON usa OpenAI; l’apertura del canvas non basta a garantire l’esecuzione. Verificare un’analisi reale, e se Flowise non funziona controllare versione e dipendenze della sua installazione.
- Errori Python dopo aggiornamenti: usare un ambiente dedicato e annotare le versioni effettivamente collaudate.

## Verifica del rilascio

Il JSON è stato controllato: nessuna chiave API, password o credenziale personale inclusa. I sorgenti del backend e gli script aula originali sono mantenuti; rimossi dal rilascio cache Python e archivio con dati preesistenti. Le verifiche locali e i loro limiti sono riportati in `VERIFICA_RILASCIO.txt`. Il collaudo reale su Windows con Flowise/OpenAI, importazione, UAC e seconda postazione resta necessario.

## Riferimenti

- https://docs.flowiseai.com/getting-started
- https://docs.flowiseai.com/configuration/authorization/chatflow-level
- https://docs.flowiseai.com/using-flowise/uploads
- https://github.com/penserini
