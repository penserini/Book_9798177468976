@echo off
setlocal
call node --version
if errorlevel 1 goto missing
call npm --version
if errorlevel 1 goto missing
echo Installazione globale npm di Flowise. Richiede Internet.
call npm install -g flowise
if errorlevel 1 goto failed
echo Installazione npm completata. Avviare Avvia_Flowise.bat.
pause
exit /b 0
:missing
echo Installare Node.js con npm compatibile con Flowise da https://nodejs.org/
pause
exit /b 1
:failed
echo Installazione non completata. Leggere gli errori npm sopra.
pause
exit /b 1
