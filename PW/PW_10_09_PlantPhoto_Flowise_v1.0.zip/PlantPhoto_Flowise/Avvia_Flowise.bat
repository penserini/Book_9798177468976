@echo off
setlocal
where flowise >nul 2>nul
if errorlevel 1 goto missing
echo Avvio Flowise sulla porta 3000. Tenere questa finestra aperta.
echo Aprire http://127.0.0.1:3000 nel browser quando il server e' pronto.
call flowise start --PORT=3000
set "PP_EXIT=%ERRORLEVEL%"
pause
exit /b %PP_EXIT%
:missing
echo Comando flowise non trovato. Installare con Installa_Flowise.bat
echo oppure utilizzare il launcher della propria installazione esistente.
pause
exit /b 1
