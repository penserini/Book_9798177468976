import 'package:flutter_test/flutter_test.dart';
import 'package:h2o_piante_app/main.dart';

void main() {
  test('H2OPianteApp accepts the initial server configuration state', () {
    const app = H2OPianteApp(
      initialServerConfigured: true,
    );

    expect(app.initialServerConfigured, isTrue);
  });
}
