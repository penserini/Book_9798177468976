package com.example.h2o_piante_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
