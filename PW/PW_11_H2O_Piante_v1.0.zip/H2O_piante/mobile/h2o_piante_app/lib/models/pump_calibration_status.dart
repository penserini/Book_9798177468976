class PumpCalibrationStatus {
  final bool success;
  final double? averageFlowMlS;
  final int samples;
  final bool valid;
  final String status;
  final String message;

  const PumpCalibrationStatus({
    required this.success,
    required this.averageFlowMlS,
    required this.samples,
    required this.valid,
    required this.status,
    required this.message,
  });

  factory PumpCalibrationStatus.fromJson(
    Map<String, dynamic> json,
  ) {
    final statistics =
        json['statistics'] as Map<String, dynamic>? ??
            const <String, dynamic>{};

    final validation =
        json['validation'] as Map<String, dynamic>? ??
            const <String, dynamic>{};

    return PumpCalibrationStatus(
      success: json['success'] == true,
      averageFlowMlS:
          (statistics['average_flow_ml_s'] as num?)?.toDouble(),
      samples: (statistics['samples'] as num?)?.toInt() ?? 0,
      valid: validation['valid'] == true,
      status: validation['status']?.toString() ?? 'NON DISPONIBILE',
      message: validation['message']?.toString() ??
          'Stato calibrazione non disponibile.',
    );
  }
}
