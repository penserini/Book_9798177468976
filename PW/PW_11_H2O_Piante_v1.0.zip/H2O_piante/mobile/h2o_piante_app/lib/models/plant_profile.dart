class PlantProfile {
  final String profileId;
  final String name;

  final String? plantName;
  final String? scientificName;
  final String? description;

  final String? location;
  final String? exposure;
  final String? soilType;
  final String? notes;

  final List<String> images;

  final double? minimumHumidityPercent;
  final double? targetHumidityPercent;
  final double? maximumHumidityPercent;

  final double? averageWaterMl;
  final double? waterDoseMl;
  final double? wateringFrequencyDays;

  final double? minimumTemperatureC;
  final double? maximumTemperatureC;

  final double? minimumAirHumidityPercent;
  final double? maximumAirHumidityPercent;

  final String? source;

  const PlantProfile({
    required this.profileId,
    required this.name,
    required this.plantName,
    required this.scientificName,
    required this.description,
    required this.location,
    required this.exposure,
    required this.soilType,
    required this.notes,
    required this.images,
    required this.minimumHumidityPercent,
    required this.targetHumidityPercent,
    required this.maximumHumidityPercent,
    required this.averageWaterMl,
    required this.waterDoseMl,
    required this.wateringFrequencyDays,
    required this.minimumTemperatureC,
    required this.maximumTemperatureC,
    required this.minimumAirHumidityPercent,
    required this.maximumAirHumidityPercent,
    required this.source,
  });

  factory PlantProfile.fromJson(Map<String, dynamic> json) {
    return PlantProfile(
      profileId: json['profile_id']?.toString() ?? '',
      name: json['name']?.toString() ?? '',
      plantName: json['plant_name']?.toString(),
      scientificName: json['scientific_name']?.toString(),
      description: json['description']?.toString(),
      location: json['location']?.toString(),
      exposure: json['exposure']?.toString(),
      soilType: json['soil_type']?.toString(),
      notes: json['notes']?.toString(),

      images: (json['images'] as List<dynamic>? ?? [])
          .map((item) => item.toString())
          .toList(),

      minimumHumidityPercent:
          (json['minimum_humidity_percent'] as num?)?.toDouble(),

      targetHumidityPercent:
          (json['target_humidity_percent'] as num?)?.toDouble(),

      maximumHumidityPercent:
          (json['maximum_humidity_percent'] as num?)?.toDouble(),

      averageWaterMl:
          (json['average_water_ml'] as num?)?.toDouble(),

      waterDoseMl:
          (json['water_dose_ml'] as num?)?.toDouble(),

      wateringFrequencyDays:
          (json['watering_frequency_days'] as num?)?.toDouble(),

      minimumTemperatureC:
          (json['minimum_temperature_c'] as num?)?.toDouble(),

      maximumTemperatureC:
          (json['maximum_temperature_c'] as num?)?.toDouble(),

      minimumAirHumidityPercent:
          (json['minimum_air_humidity_percent'] as num?)?.toDouble(),

      maximumAirHumidityPercent:
          (json['maximum_air_humidity_percent'] as num?)?.toDouble(),

      source: json['source']?.toString(),
    );
  }
}