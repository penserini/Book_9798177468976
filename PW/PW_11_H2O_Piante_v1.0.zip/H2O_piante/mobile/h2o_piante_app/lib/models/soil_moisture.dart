class SoilMoisture {
  final bool success;
  final bool connected;
  final bool sensorDetected;
  final String? sensorStatus;

  final int? channel;
  final int? samples;

  final double? rawAverage;
  final int? minimum;
  final int? maximum;
  final double? standardDeviation;

  final String? state;
  final double? humidityPercent;

  const SoilMoisture({
    required this.success,
    required this.connected,
    required this.sensorDetected,
    required this.sensorStatus,
    required this.channel,
    required this.samples,
    required this.rawAverage,
    required this.minimum,
    required this.maximum,
    required this.standardDeviation,
    required this.state,
    required this.humidityPercent,
  });

  factory SoilMoisture.fromJson(Map<String, dynamic> json) {
    return SoilMoisture(
      success: json['success'] == true,
      connected: json['connected'] == true,
      sensorDetected: json['sensor_detected'] == true,
      sensorStatus: json['sensor_status']?.toString(),
      channel: (json['channel'] as num?)?.toInt(),
      samples: (json['samples'] as num?)?.toInt(),
      rawAverage: (json['raw_average'] as num?)?.toDouble(),
      minimum: (json['minimum'] as num?)?.toInt(),
      maximum: (json['maximum'] as num?)?.toInt(),
      standardDeviation:
          (json['standard_deviation'] as num?)?.toDouble(),
      state: json['state']?.toString(),
      humidityPercent:
          (json['humidity_percent'] as num?)?.toDouble(),
    );
  }
}