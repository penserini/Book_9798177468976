class PumpStatus {
  final bool success;
  final bool connected;
  final bool running;
  final int remainingMs;

  const PumpStatus({
    required this.success,
    required this.connected,
    required this.running,
    required this.remainingMs,
  });

  factory PumpStatus.fromJson(Map<String, dynamic> json) {
    return PumpStatus(
      success: json['success'] == true,
      connected: json['connected'] == true,
      running: json['running'] == true,
      remainingMs: (json['remaining_ms'] as num?)?.toInt() ?? 0,
    );
  }

  double get remainingSeconds => remainingMs / 1000.0;
}
