class SystemStatus {
  final bool connected;
  final String mode;
  final String target;
  final int connectionFailures;
  final int maxConnectionFailures;

  const SystemStatus({
    required this.connected,
    required this.mode,
    required this.target,
    required this.connectionFailures,
    required this.maxConnectionFailures,
  });

  factory SystemStatus.fromJson(Map<String, dynamic> json) {
    return SystemStatus(
      connected: json['connected'] as bool,
      mode: json['mode'] as String,
      target: json['target'] as String,
      connectionFailures: json['connection_failures'] as int,
      maxConnectionFailures: json['max_connection_failures'] as int,
    );
  }
}