class PumpVolumeRunResult {
  final String message;
  final bool running;
  final double volumeMl;
  final double flowMlS;
  final double durationS;
  final int durationMs;
  final int calibrationSamples;
  final String calibrationStatus;

  const PumpVolumeRunResult({
    required this.message,
    required this.running,
    required this.volumeMl,
    required this.flowMlS,
    required this.durationS,
    required this.durationMs,
    required this.calibrationSamples,
    required this.calibrationStatus,
  });

  factory PumpVolumeRunResult.fromJson(
    Map<String, dynamic> json,
  ) {
    return PumpVolumeRunResult(
      message: json['message']?.toString() ?? 'Pompa avviata.',
      running: json['running'] == true,
      volumeMl: (json['volume_ml'] as num).toDouble(),
      flowMlS: (json['flow_ml_s'] as num).toDouble(),
      durationS: (json['duration_s'] as num).toDouble(),
      durationMs: (json['duration_ms'] as num).toInt(),
      calibrationSamples:
          (json['calibration_samples'] as num?)?.toInt() ?? 0,
      calibrationStatus:
          json['calibration_status']?.toString() ?? 'NON DISPONIBILE',
    );
  }
}
