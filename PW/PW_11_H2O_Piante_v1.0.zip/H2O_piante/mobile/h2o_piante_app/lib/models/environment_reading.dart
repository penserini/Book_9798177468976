class EnvironmentReading {
  final bool success;
  final bool connected;

  final String? sensor;
  final double? temperatureC;
  final double? humidityPercent;

  final String? timestamp;
  final String? message;

  const EnvironmentReading({
    required this.success,
    required this.connected,
    required this.sensor,
    required this.temperatureC,
    required this.humidityPercent,
    required this.timestamp,
    required this.message,
  });

  factory EnvironmentReading.fromJson(
    Map<String, dynamic> json,
  ) {
    return EnvironmentReading(
      success: json['success'] == true,
      connected: json['connected'] == true,
      sensor: json['sensor']?.toString(),
      temperatureC:
          (json['temperature_c'] as num?)?.toDouble(),
      humidityPercent:
          (json['humidity_percent'] as num?)?.toDouble(),
      timestamp: json['timestamp']?.toString(),
      message: json['message']?.toString(),
    );
  }
}