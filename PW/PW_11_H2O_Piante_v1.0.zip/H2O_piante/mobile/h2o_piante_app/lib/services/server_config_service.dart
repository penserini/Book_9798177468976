import 'package:shared_preferences/shared_preferences.dart';

import 'api_service.dart';

class ServerConfigService {
  static const String _hostKey = 'fastapi_server_host';
  static const String _portKey = 'fastapi_server_port';

  static const String defaultHost = '10.0.2.2';
  static const int defaultPort = 8000;

  static Future<bool> loadAndApply() async {
    final prefs = await SharedPreferences.getInstance();

    final hasSavedHost = prefs.containsKey(_hostKey);
    final hasSavedPort = prefs.containsKey(_portKey);

    final host = prefs.getString(_hostKey) ?? defaultHost;
    final port = prefs.getInt(_portKey) ?? defaultPort;

    ApiService.configure(
      serverHost: host,
      serverPort: port,
    );

    return hasSavedHost && hasSavedPort;
  }

  static Future<void> save({
    required String host,
    required int port,
  }) async {
    final normalizedHost = host.trim();

    if (normalizedHost.isEmpty) {
      throw ArgumentError('Il server FastAPI non può essere vuoto.');
    }

    if (port < 1 || port > 65535) {
      throw ArgumentError('La porta deve essere compresa tra 1 e 65535.');
    }

    final prefs = await SharedPreferences.getInstance();

    await prefs.setString(_hostKey, normalizedHost);
    await prefs.setInt(_portKey, port);

    ApiService.configure(
      serverHost: normalizedHost,
      serverPort: port,
    );
  }
}
