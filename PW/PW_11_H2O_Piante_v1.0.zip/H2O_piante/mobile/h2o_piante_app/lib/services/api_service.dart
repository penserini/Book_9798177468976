import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/environment_reading.dart';
import '../models/plant_profile.dart';
import '../models/pump_calibration_status.dart';
import '../models/pump_status.dart';
import '../models/pump_volume_run_result.dart';
import '../models/soil_moisture.dart';
import '../models/system_status.dart';

class ApiService {
  static const Duration requestTimeout = Duration(seconds: 10);
  static String _serverHost = '10.0.2.2';
  static int _serverPort = 8000;

  static String get serverHost => _serverHost;
  static int get serverPort => _serverPort;
  static String get baseUrl => 'http://$_serverHost:$_serverPort';

  static void configure({
    required String serverHost,
    required int serverPort,
  }) {
    _serverHost = serverHost.trim();
    _serverPort = serverPort;
  }

  static String buildResourceUrl(String path) {
    if (path.startsWith('http://') ||
        path.startsWith('https://')) {
      return path;
    }

    if (path.startsWith('/')) {
      return '$baseUrl$path';
    }

    return '$baseUrl/$path';
  }

  Future<SystemStatus> getStatus() async {
    final uri = Uri.parse(
      '$baseUrl/api/status',
    );

    final response = await http.get(uri).timeout(requestTimeout);

    if (response.statusCode == 200) {
      final data =
          jsonDecode(response.body) as Map<String, dynamic>;

      return SystemStatus.fromJson(data);
    }

    throw Exception(
      'Errore nella richiesta /api/status: '
      '${response.statusCode}',
    );
  }

  Future<bool> connectEsp32() async {
    final uri = Uri.parse(
      '$baseUrl/api/connect',
    );

    final response = await http.post(uri).timeout(requestTimeout);

    if (response.statusCode != 200) {
      throw Exception(
        'Errore nella richiesta /api/connect: '
        '${response.statusCode}',
      );
    }

    final data =
        jsonDecode(response.body) as Map<String, dynamic>;

    return data['success'] == true &&
        data['connected'] == true;
  }

  Future<bool> disconnectEsp32() async {
    final uri = Uri.parse(
      '$baseUrl/api/disconnect',
    );

    final response = await http.post(uri).timeout(requestTimeout);

    if (response.statusCode != 200) {
      throw Exception(
        'Errore nella richiesta /api/disconnect: '
        '${response.statusCode}',
      );
    }

    final data =
        jsonDecode(response.body) as Map<String, dynamic>;

    return data['success'] == true &&
        data['connected'] == false;
  }

  Future<SoilMoisture> getSoilMoisture() async {
    final uri = Uri.parse(
      '$baseUrl/api/sensor/read?channel=0&samples=10',
    );

    final response = await http.get(uri).timeout(requestTimeout);

    if (response.statusCode == 200) {
      final data =
          jsonDecode(response.body) as Map<String, dynamic>;

      return SoilMoisture.fromJson(data);
    }

    throw Exception(
      'Errore nella richiesta /api/sensor/read: '
      '${response.statusCode}',
    );
  }

  Future<EnvironmentReading> getEnvironmentReading() async {
    final uri = Uri.parse(
      '$baseUrl/api/environment/read',
    );

    final response = await http.get(uri).timeout(requestTimeout);

    if (response.statusCode == 200) {
      final data =
          jsonDecode(response.body) as Map<String, dynamic>;

      return EnvironmentReading.fromJson(data);
    }

    throw Exception(
      'Errore nella richiesta /api/environment/read: '
      '${response.statusCode}',
    );
  }

  Future<PlantProfile> getActivePlantProfile() async {
    final uri = Uri.parse(
      '$baseUrl/api/plant/profile',
    );

    final response = await http.get(uri).timeout(requestTimeout);

    if (response.statusCode == 200) {
      final data =
          jsonDecode(response.body) as Map<String, dynamic>;

      final profileData =
          data['profile'] as Map<String, dynamic>;

      return PlantProfile.fromJson(profileData);
    }

    throw Exception(
      'Errore nella richiesta /api/plant/profile: '
      '${response.statusCode}',
    );
  }

  Future<PumpStatus> getPumpStatus() async {
    final uri = Uri.parse(
      '$baseUrl/api/pump/status',
    );

    final response = await http.get(uri).timeout(requestTimeout);

    if (response.statusCode == 200) {
      final data =
          jsonDecode(response.body) as Map<String, dynamic>;

      return PumpStatus.fromJson(data);
    }

    throw Exception(
      'Errore nella richiesta /api/pump/status: '
      '${response.statusCode}',
    );
  }

  Future<void> runPump({
    required double durationSeconds,
  }) async {
    final uri = Uri.parse(
      '$baseUrl/api/pump/run',
    );

    final response = await http.post(
      uri,
      headers: const {
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        'duration_s': durationSeconds,
      }),
    ).timeout(requestTimeout);

    if (response.statusCode != 200) {
      throw Exception(
        'Errore nella richiesta /api/pump/run: '
        '${response.statusCode}',
      );
    }

    final dynamic decoded = jsonDecode(response.body);

    if (decoded is Map<String, dynamic> &&
        decoded['success'] == false) {
      throw Exception(
        decoded['message']?.toString() ??
            'Avvio pompa non riuscito.',
      );
    }
  }


  Future<PumpCalibrationStatus> getPumpCalibrationStatus() async {
    final uri = Uri.parse(
      '$baseUrl/api/pump-calibration/status',
    );

    final response = await http.get(uri).timeout(requestTimeout);

    if (response.statusCode == 200) {
      final data =
          jsonDecode(response.body) as Map<String, dynamic>;

      if (data['success'] == false) {
        throw Exception(
          data['message']?.toString() ??
              'Stato calibrazione pompa non disponibile.',
        );
      }

      return PumpCalibrationStatus.fromJson(data);
    }

    throw Exception(
      'Errore nella richiesta /api/pump-calibration/status: '
      '${response.statusCode}',
    );
  }

  Future<PumpVolumeRunResult> runPumpByVolume({
    required double volumeMl,
  }) async {
    final uri = Uri.parse(
      '$baseUrl/api/pump/run-ml',
    );

    final response = await http.post(
      uri,
      headers: const {
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        'volume_ml': volumeMl,
      }),
    ).timeout(requestTimeout);

    if (response.statusCode != 200) {
      throw Exception(
        'Errore nella richiesta /api/pump/run-ml: '
        '${response.statusCode}',
      );
    }

    final data =
        jsonDecode(response.body) as Map<String, dynamic>;

    if (data['success'] == false) {
      throw Exception(
        data['message']?.toString() ??
            'Erogazione in millilitri non riuscita.',
      );
    }

    return PumpVolumeRunResult.fromJson(data);
  }

  Future<void> stopPump() async {
    final uri = Uri.parse(
      '$baseUrl/api/pump/stop',
    );

    final response = await http.post(uri).timeout(requestTimeout);

    if (response.statusCode != 200) {
      throw Exception(
        'Errore nella richiesta /api/pump/stop: '
        '${response.statusCode}',
      );
    }

    final dynamic decoded = jsonDecode(response.body);

    if (decoded is Map<String, dynamic> &&
        decoded['success'] == false) {
      throw Exception(
        decoded['message']?.toString() ??
            'Arresto pompa non riuscito.',
      );
    }
  }

}
