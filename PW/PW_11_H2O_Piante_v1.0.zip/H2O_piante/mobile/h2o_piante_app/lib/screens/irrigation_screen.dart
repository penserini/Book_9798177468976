import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models/pump_calibration_status.dart';
import '../models/pump_status.dart';
import '../services/api_service.dart';

class IrrigationScreen extends StatefulWidget {
  const IrrigationScreen({super.key});

  @override
  State<IrrigationScreen> createState() => _IrrigationScreenState();
}

class _IrrigationScreenState extends State<IrrigationScreen> {
  final ApiService _apiService = ApiService();

  PumpStatus? _pumpStatus;
  PumpCalibrationStatus? _calibrationStatus;

  bool _isLoading = true;
  bool _isLoadingCalibration = true;
  bool _isCommandRunning = false;
  bool _isPumpStatusRequestRunning = false;

  String? _statusErrorMessage;
  String? _calibrationErrorMessage;
  String? _commandErrorMessage;
  String? _message;

  double _durationSeconds = 1.0;
  double _volumeMl = 10;

  late final TextEditingController _durationController;

  Timer? _statusTimer;

  @override
  void initState() {
    super.initState();
    _durationController = TextEditingController(text: '1');
    _loadAllData();

    _statusTimer = Timer.periodic(
      const Duration(seconds: 1),
      (_) => _loadPumpStatus(showLoading: false),
    );
  }

  @override
  void dispose() {
    _statusTimer?.cancel();
    _durationController.dispose();
    super.dispose();
  }

  Future<void> _loadAllData() async {
    await Future.wait([
      _loadPumpStatus(),
      _loadCalibrationStatus(),
    ]);
  }

  Future<void> _loadPumpStatus({bool showLoading = true}) async {
    if (_isPumpStatusRequestRunning) {
      return;
    }

    _isPumpStatusRequestRunning = true;

    if (showLoading && mounted) {
      setState(() {
        _isLoading = true;
      });
    }

    try {
      final status = await _apiService.getPumpStatus();
      if (!mounted) return;

      setState(() {
        _pumpStatus = status;
        _statusErrorMessage = null;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _pumpStatus = null;
        _statusErrorMessage = e.toString();
      });
    } finally {
      _isPumpStatusRequestRunning = false;

      if (showLoading && mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _loadCalibrationStatus() async {
    if (mounted) {
      setState(() {
        _isLoadingCalibration = true;
      });
    }

    try {
      final status =
          await _apiService.getPumpCalibrationStatus();

      if (!mounted) return;

      setState(() {
        _calibrationStatus = status;
        _calibrationErrorMessage = null;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _calibrationStatus = null;
        _calibrationErrorMessage = e.toString();
      });
    } finally {
      if (mounted) {
        setState(() {
          _isLoadingCalibration = false;
        });
      }
    }
  }

  Future<void> _runPumpByTime() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Avvia pompa a tempo'),
          content: Text(
            'Vuoi avviare la pompa per ${_formatSeconds(_durationSeconds)} secondi?',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text('ANNULLA'),
            ),
            FilledButton(
              onPressed: () => Navigator.of(context).pop(true),
              child: const Text('AVVIA'),
            ),
          ],
        );
      },
    );

    if (confirmed != true) return;

    setState(() {
      _isCommandRunning = true;
      _commandErrorMessage = null;
      _message = null;
    });

    try {
      await _apiService.runPump(
        durationSeconds: _durationSeconds,
      );

      if (!mounted) return;

      setState(() {
        _message =
            'Pompa avviata per ${_formatSeconds(_durationSeconds)} secondi.';
      });

      await _loadPumpStatus(showLoading: false);
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _commandErrorMessage = e.toString();
      });
    } finally {
      if (mounted) {
        setState(() {
          _isCommandRunning = false;
        });
      }
    }
  }

  Future<void> _runPumpByVolume() async {
    final estimatedSeconds = _estimatedVolumeDurationSeconds;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Eroga acqua'),
          content: Text(
            'Vuoi erogare ${_volumeMl.toStringAsFixed(0)} ml?\n\n'
            'Tempo stimato: '
            '${estimatedSeconds?.toStringAsFixed(1) ?? '-'} s',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text('ANNULLA'),
            ),
            FilledButton(
              onPressed: () => Navigator.of(context).pop(true),
              child: const Text('EROGA'),
            ),
          ],
        );
      },
    );

    if (confirmed != true) return;

    setState(() {
      _isCommandRunning = true;
      _commandErrorMessage = null;
      _message = null;
    });

    try {
      final result = await _apiService.runPumpByVolume(
        volumeMl: _volumeMl,
      );

      if (!mounted) return;

      setState(() {
        _message =
            '${result.volumeMl.toStringAsFixed(0)} ml richiesti. '
            'Portata usata: ${result.flowMlS.toStringAsFixed(3)} ml/s. '
            'Durata calcolata: ${result.durationS.toStringAsFixed(1)} s.';
      });

      await _loadPumpStatus(showLoading: false);
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _commandErrorMessage = e.toString();
      });
    } finally {
      if (mounted) {
        setState(() {
          _isCommandRunning = false;
        });
      }
    }
  }

  Future<void> _stopPump() async {
    setState(() {
      _isCommandRunning = true;
      _commandErrorMessage = null;
      _message = null;
    });

    try {
      await _apiService.stopPump();
      if (!mounted) return;

      setState(() {
        _message = 'Pompa arrestata.';
      });

      await _loadPumpStatus(showLoading: false);
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _commandErrorMessage = e.toString();
      });
    } finally {
      if (mounted) {
        setState(() {
          _isCommandRunning = false;
        });
      }
    }
  }


  String _formatSeconds(double value) {
    if (value == value.roundToDouble()) {
      return value.toInt().toString();
    }

    return value.toStringAsFixed(1);
  }

  bool get _durationValid {
    return _durationSeconds > 0 && _durationSeconds <= 60;
  }

  void _setDuration(double value) {
    setState(() {
      _durationSeconds = value;
      _durationController.text = _formatSeconds(value);
      _durationController.selection = TextSelection.fromPosition(
        TextPosition(offset: _durationController.text.length),
      );
    });
  }

  void _onDurationTextChanged(String value) {
    final normalized = value.replaceAll(',', '.');
    final parsed = double.tryParse(normalized);

    setState(() {
      _durationSeconds = parsed ?? 0;
    });
  }

  bool get _espConnected => _pumpStatus?.connected == true;
  bool get _pumpRunning => _pumpStatus?.running == true;

  bool get _calibrationValid {
    return _calibrationStatus?.valid == true &&
        _calibrationStatus?.averageFlowMlS != null &&
        (_calibrationStatus!.averageFlowMlS! > 0);
  }

  double? get _estimatedVolumeDurationSeconds {
    final flow = _calibrationStatus?.averageFlowMlS;

    if (!_calibrationValid || flow == null || flow <= 0) {
      return null;
    }

    return _volumeMl / flow;
  }

  double? get _estimatedTimeVolumeMl {
    final flow = _calibrationStatus?.averageFlowMlS;

    if (!_calibrationValid || flow == null || flow <= 0) {
      return null;
    }

    return _durationSeconds * flow;
  }

  double? get _secondsPerMl {
    final flow = _calibrationStatus?.averageFlowMlS;

    if (!_calibrationValid || flow == null || flow <= 0) {
      return null;
    }

    return 1 / flow;
  }

  double? get _maximumVolumeMl {
    final flow = _calibrationStatus?.averageFlowMlS;

    if (!_calibrationValid || flow == null || flow <= 0) {
      return null;
    }

    return flow * 60.0;
  }

  bool get _volumeWithinTimeLimit {
    final estimated = _estimatedVolumeDurationSeconds;

    return estimated != null && estimated <= 60.0;
  }

  bool get _canRunByVolume {
    return _espConnected &&
        !_pumpRunning &&
        !_isCommandRunning &&
        _calibrationValid &&
        _volumeWithinTimeLimit;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Irrigazione'),
        centerTitle: true,
        actions: [
          IconButton(
            onPressed: _isCommandRunning ? null : _loadAllData,
            icon: const Icon(Icons.refresh),
            tooltip: 'Aggiorna stato pompa e calibrazione',
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _loadAllData,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _buildStatusCard(),
            const SizedBox(height: 12),
            _buildConversionCard(),
            const SizedBox(height: 12),
            _buildTimeControlCard(),
            const SizedBox(height: 12),
            _buildVolumeControlCard(),
            const SizedBox(height: 12),
            _buildStopCard(),
            if (_message != null) ...[
              const SizedBox(height: 12),
              _buildMessageCard(_message!, error: false),
            ],
            if (_statusErrorMessage != null) ...[
              const SizedBox(height: 12),
              _buildMessageCard(
                'Stato pompa: $_statusErrorMessage',
                error: true,
              ),
            ],
            if (_calibrationErrorMessage != null) ...[
              const SizedBox(height: 12),
              _buildMessageCard(
                'Calibrazione: $_calibrationErrorMessage',
                error: true,
              ),
            ],
            if (_commandErrorMessage != null) ...[
              const SizedBox(height: 12),
              _buildMessageCard(
                _commandErrorMessage!,
                error: true,
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildStatusCard() {
    if (_isLoading) {
      return const Card(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Center(child: CircularProgressIndicator()),
        ),
      );
    }

    final status = _pumpStatus;

    if (status == null) {
      return const Card(
        child: ListTile(
          leading: Icon(Icons.help_outline),
          title: Text('Stato pompa'),
          subtitle: Text('Dato non disponibile'),
        ),
      );
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Stato pompa',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 14),
            _buildStatusRow(
              icon: _espConnected
                  ? Icons.check_circle
                  : Icons.cancel,
              label: 'ESP32',
              value: _espConnected
                  ? 'CONNESSA'
                  : 'NON CONNESSA',
            ),
            const SizedBox(height: 8),
            _buildStatusRow(
              icon: _pumpRunning
                  ? Icons.water
                  : Icons.water_outlined,
              label: 'Pompa',
              value: _pumpRunning
                  ? 'IN FUNZIONE'
                  : 'FERMA',
            ),
            const SizedBox(height: 8),
            _buildStatusRow(
              icon: Icons.timer_outlined,
              label: 'Tempo residuo',
              value: _pumpRunning
                  ? '${status.remainingSeconds.toStringAsFixed(1)} s'
                  : '0 s',
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildConversionCard() {
    if (_isLoadingCalibration) {
      return const Card(
        child: Padding(
          padding: EdgeInsets.all(20),
          child: Center(
            child: Column(
              children: [
                CircularProgressIndicator(),
                SizedBox(height: 10),
                Text('Lettura calibrazione pompa...'),
              ],
            ),
          ),
        ),
      );
    }

    final calibration = _calibrationStatus;
    final flow = calibration?.averageFlowMlS;
    final secondsPerMl = _secondsPerMl;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Calibrazione e conversioni',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            _buildStatusRow(
              icon: _calibrationValid
                  ? Icons.check_circle_outline
                  : Icons.warning_amber_outlined,
              label: 'Calibrazione',
              value: calibration?.status ?? 'NON DISPONIBILE',
            ),
            const SizedBox(height: 8),
            _buildStatusRow(
              icon: Icons.speed,
              label: 'Portata media',
              value: flow == null
                  ? '-'
                  : '${flow.toStringAsFixed(4)} ml/s',
            ),
            const SizedBox(height: 8),
            _buildStatusRow(
              icon: Icons.swap_horiz,
              label: 'Secondi → ml',
              value: flow == null || !_calibrationValid
                  ? '-'
                  : '1 s ≈ ${flow.toStringAsFixed(4)} ml',
            ),
            const SizedBox(height: 8),
            _buildStatusRow(
              icon: Icons.swap_horiz,
              label: 'ml → secondi',
              value: secondsPerMl == null
                  ? '-'
                  : '1 ml ≈ ${secondsPerMl.toStringAsFixed(4)} s',
            ),
            if (!_calibrationValid && calibration != null) ...[
              const SizedBox(height: 10),
              Text(calibration.message),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildTimeControlCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Comando a tempo',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Imposta direttamente il tempo di funzionamento '
              'della pompa.',
            ),
            const SizedBox(height: 16),
            const Text(
              'Tempi rapidi',
              style: TextStyle(
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [1, 2, 3, 5, 10, 15, 20, 30, 45, 60]
                  .map(
                    (seconds) => ChoiceChip(
                      label: Text('$seconds s'),
                      selected: _durationSeconds == seconds.toDouble(),
                      onSelected:
                          _espConnected &&
                                  !_pumpRunning &&
                                  !_isCommandRunning
                              ? (_) => _setDuration(seconds.toDouble())
                              : null,
                    ),
                  )
                  .toList(),
            ),
            const SizedBox(height: 14),
            TextField(
              controller: _durationController,
              enabled:
                  _espConnected &&
                  !_pumpRunning &&
                  !_isCommandRunning,
              keyboardType: const TextInputType.numberWithOptions(
                decimal: true,
              ),
              inputFormatters: [
                FilteringTextInputFormatter.allow(
                  RegExp(r'[0-9.,]'),
                ),
              ],
              decoration: InputDecoration(
                labelText: 'Durata personalizzata',
                suffixText: 's',
                border: const OutlineInputBorder(),
                helperText: 'Valore consentito: maggiore di 0 e massimo 60 s',
                errorText: _durationValid
                    ? null
                    : 'Inserisci una durata compresa tra 0 e 60 secondi',
              ),
              onChanged: _onDurationTextChanged,
            ),
            const SizedBox(height: 12),
            Text(
              _estimatedTimeVolumeMl == null
                  ? 'Volume stimato: disponibile dopo una calibrazione valida'
                  : 'Volume stimato: ${_estimatedTimeVolumeMl!.toStringAsFixed(2)} ml',
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed:
                  _espConnected &&
                          !_pumpRunning &&
                          !_isCommandRunning &&
                          _durationValid
                      ? _runPumpByTime
                      : null,
              icon: const Icon(Icons.play_arrow),
              label: const Text('AVVIA A TEMPO'),
            ),
            if (!_espConnected) ...[
              const SizedBox(height: 12),
              const Text(
                'Connetti prima ESP32 dalla Dashboard.',
                textAlign: TextAlign.center,
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildVolumeControlCard() {
    if (_isLoadingCalibration) {
      return const Card(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Center(
            child: Column(
              children: [
                CircularProgressIndicator(),
                SizedBox(height: 10),
                Text('Lettura calibrazione pompa...'),
              ],
            ),
          ),
        ),
      );
    }

    final calibration = _calibrationStatus;
    final flow = calibration?.averageFlowMlS;
    final estimated = _estimatedVolumeDurationSeconds;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Comando per millilitri',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              _calibrationValid
                  ? 'La quantità richiesta viene convertita in tempo '
                      'dal backend usando la calibrazione reale.'
                  : 'Disponibile solamente dopo una calibrazione '
                      'valida della pompa.',
            ),
            const SizedBox(height: 14),
            _buildStatusRow(
              icon: _calibrationValid
                  ? Icons.check_circle_outline
                  : Icons.warning_amber_outlined,
              label: 'Calibrazione',
              value: calibration?.status ?? 'NON DISPONIBILE',
            ),
            const SizedBox(height: 8),
            _buildStatusRow(
              icon: Icons.speed,
              label: 'Portata media',
              value: flow == null
                  ? '-'
                  : '${flow.toStringAsFixed(4)} ml/s',
            ),
            const SizedBox(height: 8),
            _buildStatusRow(
              icon: Icons.science_outlined,
              label: 'Misure',
              value: '${calibration?.samples ?? 0}',
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<double>(
              initialValue: _volumeMl,
              decoration: const InputDecoration(
                labelText: 'Quantità',
                border: OutlineInputBorder(),
              ),
              items: const [
                DropdownMenuItem(
                  value: 10,
                  child: Text('10 ml'),
                ),
                DropdownMenuItem(
                  value: 20,
                  child: Text('20 ml'),
                ),
                DropdownMenuItem(
                  value: 30,
                  child: Text('30 ml'),
                ),
                DropdownMenuItem(
                  value: 50,
                  child: Text('50 ml'),
                ),
                DropdownMenuItem(
                  value: 75,
                  child: Text('75 ml'),
                ),
                DropdownMenuItem(
                  value: 100,
                  child: Text('100 ml'),
                ),
              ],
              onChanged:
                  _espConnected &&
                          !_pumpRunning &&
                          !_isCommandRunning &&
                          _calibrationValid
                      ? (value) {
                          if (value != null) {
                            setState(() {
                              _volumeMl = value;
                            });
                          }
                        }
                      : null,
            ),
            const SizedBox(height: 12),
            Text(
              estimated == null
                  ? 'Tempo stimato: non disponibile'
                  : 'Tempo stimato: ${estimated.toStringAsFixed(1)} s',
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              _maximumVolumeMl == null
                  ? 'Volume massimo per comando: non disponibile'
                  : 'Volume massimo per comando (60 s): ${_maximumVolumeMl!.toStringAsFixed(1)} ml',
              textAlign: TextAlign.center,
            ),
            if (_calibrationValid && !_volumeWithinTimeLimit) ...[
              const SizedBox(height: 8),
              const Text(
                'La quantità selezionata supera il limite di '
                '60 secondi per un singolo comando.',
                textAlign: TextAlign.center,
              ),
            ],
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: _canRunByVolume
                  ? _runPumpByVolume
                  : null,
              icon: const Icon(Icons.water_drop_outlined),
              label: Text(
                'EROGA ${_volumeMl.toStringAsFixed(0)} ml',
              ),
            ),
            if (!_calibrationValid && calibration != null) ...[
              const SizedBox(height: 10),
              Text(
                calibration.message,
                textAlign: TextAlign.center,
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildStopCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: FilledButton.tonalIcon(
          onPressed:
              _espConnected &&
                      _pumpRunning &&
                      !_isCommandRunning
                  ? _stopPump
                  : null,
          icon: const Icon(Icons.stop),
          label: const Text('STOP POMPA'),
        ),
      ),
    );
  }

  Widget _buildStatusRow({
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Row(
      children: [
        Icon(icon),
        const SizedBox(width: 10),
        Expanded(
          child: Text(
            label,
            style: const TextStyle(
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        Flexible(
          child: Text(
            value,
            textAlign: TextAlign.right,
          ),
        ),
      ],
    );
  }

  Widget _buildMessageCard(
    String message, {
    required bool error,
  }) {
    return Card(
      child: ListTile(
        leading: Icon(
          error
              ? Icons.error_outline
              : Icons.info_outline,
        ),
        title: Text(
          error
              ? 'Errore'
              : 'Informazione',
        ),
        subtitle: Text(message),
      ),
    );
  }
}
