import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import '../services/api_service.dart';
import '../services/server_config_service.dart';

class ServerSettingsScreen extends StatefulWidget {
  final VoidCallback? onConfigurationSaved;

  const ServerSettingsScreen({
    super.key,
    this.onConfigurationSaved,
  });

  @override
  State<ServerSettingsScreen> createState() =>
      _ServerSettingsScreenState();
}

class _ServerSettingsScreenState
    extends State<ServerSettingsScreen> {
  late final TextEditingController _hostController;
  late final TextEditingController _portController;

  bool _testing = false;
  bool _saving = false;
  bool? _serverReachable;
  bool? _espConnected;
  String? _mode;
  String? _target;
  String? _message;

  @override
  void initState() {
    super.initState();
    _hostController = TextEditingController(
      text: ApiService.serverHost,
    );
    _portController = TextEditingController(
      text: ApiService.serverPort.toString(),
    );
  }

  @override
  void dispose() {
    _hostController.dispose();
    _portController.dispose();
    super.dispose();
  }

  String _normalizedHost(String value) {
    var host = value.trim();
    host = host.replaceFirst(RegExp(r'^https?://'), '');
    if (host.contains('/')) {
      host = host.split('/').first;
    }
    if (host.contains(':')) {
      host = host.split(':').first;
    }
    return host;
  }

  ({String host, int port})? _readConfiguration() {
    final host = _normalizedHost(_hostController.text);
    final port = int.tryParse(_portController.text.trim());

    if (host.isEmpty) {
      _showMessage('Inserire l’indirizzo IP o il nome host del server FastAPI.');
      return null;
    }

    if (port == null || port < 1 || port > 65535) {
      _showMessage('La porta deve essere un numero compreso tra 1 e 65535.');
      return null;
    }

    return (host: host, port: port);
  }

  void _showMessage(String message) {
    setState(() {
      _message = message;
    });
  }

  Future<void> _testConnection() async {
    final config = _readConfiguration();
    if (config == null) return;

    setState(() {
      _testing = true;
      _serverReachable = null;
      _espConnected = null;
      _mode = null;
      _target = null;
      _message = null;
    });

    final url =
        'http://${config.host}:${config.port}/api/status';

    try {
      final response = await http
          .get(
            Uri.parse(url),
            headers: const {'Cache-Control': 'no-cache'},
          )
          .timeout(const Duration(seconds: 5));

      if (response.statusCode != 200) {
        throw Exception('HTTP ${response.statusCode}');
      }

      final data =
          jsonDecode(response.body) as Map<String, dynamic>;

      if (!mounted) return;

      setState(() {
        _serverReachable = true;
        _espConnected = data['connected'] == true;
        _mode = data['mode']?.toString();
        _target = data['target']?.toString();
        _message = 'Server FastAPI raggiungibile.';
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _serverReachable = false;
        _message =
            'Server non raggiungibile. Controllare IP, porta, Wi-Fi e BAT FastAPI.';
      });
    } finally {
      if (mounted) {
        setState(() {
          _testing = false;
        });
      }
    }
  }

  Future<void> _save() async {
    final config = _readConfiguration();
    if (config == null) return;

    setState(() {
      _saving = true;
      _message = null;
    });

    try {
      await ServerConfigService.save(
        host: config.host,
        port: config.port,
      );

      if (!mounted) return;

      if (widget.onConfigurationSaved != null) {
        widget.onConfigurationSaved!();
      } else {
        Navigator.of(context).pop(true);
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _message = 'Impossibile salvare la configurazione: $e';
        });
      }
    } finally {
      if (mounted) {
        setState(() {
          _saving = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final busy = _testing || _saving;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Impostazioni server'),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Text(
                    'Backend FastAPI',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Inserire l’indirizzo del PC o del dispositivo che ospita FastAPI. '
                    'Sul Pixel virtuale il valore predefinito è 10.0.2.2; sullo smartphone '
                    'reale usare l’IP del server nella rete Wi-Fi locale.',
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: _hostController,
                    enabled: !busy,
                    keyboardType: TextInputType.url,
                    autocorrect: false,
                    enableSuggestions: false,
                    decoration: const InputDecoration(
                      labelText: 'IP / nome host server',
                      hintText: 'es. 192.168.1.100',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _portController,
                    enabled: !busy,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: 'Porta',
                      hintText: '8000',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 16),
                  OutlinedButton.icon(
                    onPressed: busy ? null : _testConnection,
                    icon: _testing
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                            ),
                          )
                        : const Icon(Icons.wifi_find),
                    label: const Text('TEST CONNESSIONE'),
                  ),
                  const SizedBox(height: 10),
                  FilledButton.icon(
                    onPressed: busy ? null : _save,
                    icon: const Icon(Icons.save_outlined),
                    label: const Text('SALVA'),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Verifica connessione',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 12),
                  _infoRow(
                    'Server FastAPI',
                    _serverReachable == null
                        ? 'Non ancora verificato'
                        : (_serverReachable!
                            ? 'RAGGIUNGIBILE'
                            : 'NON RAGGIUNGIBILE'),
                  ),
                  _infoRow(
                    'Modalità backend',
                    _mode ?? 'Non disponibile',
                  ),
                  _infoRow(
                    'Target ESP32 / mDNS',
                    _target ?? 'Non disponibile',
                  ),
                  _infoRow(
                    'Stato ESP32',
                    _espConnected == null
                        ? 'Non verificato'
                        : (_espConnected!
                            ? 'CONNESSA'
                            : 'NON CONNESSA'),
                  ),
                  if (_message != null) ...[
                    const SizedBox(height: 12),
                    Text(_message!),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            flex: 4,
            child: Text(
              label,
              style: const TextStyle(
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            flex: 6,
            child: Text(value),
          ),
        ],
      ),
    );
  }
}
