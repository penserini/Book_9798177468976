import 'package:flutter/material.dart';

import '../models/plant_profile.dart';
import '../services/api_service.dart';

class PlantProfileScreen extends StatelessWidget {
  final PlantProfile profile;

  const PlantProfileScreen({
    super.key,
    required this.profile,
  });

  String _textOrNotAvailable(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Non disponibile';
    }

    return value;
  }

  String _percentOrNotAvailable(double? value) {
    if (value == null) {
      return 'Non disponibile';
    }

    return '${value.toStringAsFixed(1)} %';
  }

  String _temperatureOrNotAvailable(double? value) {
    if (value == null) {
      return 'Non disponibile';
    }

    return '${value.toStringAsFixed(1)} °C';
  }

  String _waterOrNotAvailable(double? value) {
    if (value == null) {
      return 'Non disponibile';
    }

    return '${value.toStringAsFixed(1)} ml';
  }

  String _daysOrNotAvailable(double? value) {
    if (value == null) {
      return 'Non disponibile';
    }

    if (value == value.roundToDouble()) {
      return '${value.toInt()} giorni';
    }

    return '${value.toStringAsFixed(1)} giorni';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profilo pianta'),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildHeaderCard(),

          const SizedBox(height: 16),

          _buildSectionCard(
            title: 'Informazioni generali',
            icon: Icons.info_outline,
            children: [
              _buildInfoRow(
                'ID profilo',
                profile.profileId,
              ),
              _buildInfoRow(
                'Nome profilo',
                profile.name,
              ),
              _buildInfoRow(
                'Nome comune',
                _textOrNotAvailable(profile.plantName),
              ),
              _buildInfoRow(
                'Nome scientifico',
                _textOrNotAvailable(profile.scientificName),
              ),
              _buildInfoRow(
                'Posizione',
                _textOrNotAvailable(profile.location),
              ),
              _buildInfoRow(
                'Origine dati',
                _textOrNotAvailable(profile.source),
              ),
            ],
          ),

          _buildSectionCard(
            title: 'Ambiente e coltivazione',
            icon: Icons.eco_outlined,
            children: [
              _buildInfoRow(
                'Esposizione',
                _textOrNotAvailable(profile.exposure),
              ),
              _buildInfoRow(
                'Tipo di terreno',
                _textOrNotAvailable(profile.soilType),
              ),
              _buildInfoRow(
                'Temperatura minima',
                _temperatureOrNotAvailable(
                  profile.minimumTemperatureC,
                ),
              ),
              _buildInfoRow(
                'Temperatura massima',
                _temperatureOrNotAvailable(
                  profile.maximumTemperatureC,
                ),
              ),
              _buildInfoRow(
                'Umidità aria minima',
                _percentOrNotAvailable(
                  profile.minimumAirHumidityPercent,
                ),
              ),
              _buildInfoRow(
                'Umidità aria massima',
                _percentOrNotAvailable(
                  profile.maximumAirHumidityPercent,
                ),
              ),
            ],
          ),

          _buildSectionCard(
            title: 'Umidità del terreno',
            icon: Icons.water_drop_outlined,
            children: [
              _buildInfoRow(
                'Umidità minima',
                _percentOrNotAvailable(
                  profile.minimumHumidityPercent,
                ),
              ),
              _buildInfoRow(
                'Umidità obiettivo',
                _percentOrNotAvailable(
                  profile.targetHumidityPercent,
                ),
              ),
              _buildInfoRow(
                'Umidità massima',
                _percentOrNotAvailable(
                  profile.maximumHumidityPercent,
                ),
              ),
            ],
          ),

          _buildSectionCard(
            title: 'Irrigazione',
            icon: Icons.opacity,
            children: [
              _buildInfoRow(
                'Acqua media',
                _waterOrNotAvailable(
                  profile.averageWaterMl,
                ),
              ),
              _buildInfoRow(
                'Dose irrigazione',
                _waterOrNotAvailable(
                  profile.waterDoseMl,
                ),
              ),
              _buildInfoRow(
                'Frequenza',
                _daysOrNotAvailable(
                  profile.wateringFrequencyDays,
                ),
              ),
            ],
          ),

          _buildTextSectionCard(
            title: 'Descrizione',
            icon: Icons.description_outlined,
            text: _textOrNotAvailable(
              profile.description,
            ),
          ),

          _buildTextSectionCard(
            title: 'Note',
            icon: Icons.notes,
            text: _textOrNotAvailable(
              profile.notes,
            ),
          ),

          if (profile.images.isNotEmpty)
            _buildImagesCard(),
        ],
      ),
    );
  }

  Widget _buildHeaderCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            _buildMainPlantImage(),

            const SizedBox(height: 16),

            Text(
              profile.name,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 26,
                fontWeight: FontWeight.bold,
              ),
            ),

            if (profile.plantName != null &&
                profile.plantName!.trim().isNotEmpty) ...[
              const SizedBox(height: 6),
              Text(
                profile.plantName!,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 20,
                ),
              ),
            ],

            if (profile.scientificName != null &&
                profile.scientificName!.trim().isNotEmpty) ...[
              const SizedBox(height: 4),
              Text(
                profile.scientificName!,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 15,
                  fontStyle: FontStyle.italic,
                ),
              ),
            ],

            if (profile.location != null &&
                profile.location!.trim().isNotEmpty) ...[
              const SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(
                    Icons.location_on_outlined,
                    size: 18,
                  ),
                  const SizedBox(width: 4),
                  Flexible(
                    child: Text(
                      profile.location!,
                      textAlign: TextAlign.center,
                    ),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildMainPlantImage() {
    if (profile.images.isEmpty) {
      return const Icon(
        Icons.eco,
        size: 72,
      );
    }

    final imageUrl =
        ApiService.buildResourceUrl(profile.images.first);

    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: Image.network(
        imageUrl,
        width: double.infinity,
        height: 220,
        fit: BoxFit.cover,
        loadingBuilder: (
          context,
          child,
          loadingProgress,
        ) {
          if (loadingProgress == null) {
            return child;
          }

          return const SizedBox(
            height: 220,
            child: Center(
              child: CircularProgressIndicator(),
            ),
          );
        },
        errorBuilder: (
          context,
          error,
          stackTrace,
        ) {
          return const SizedBox(
            height: 220,
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.broken_image_outlined,
                    size: 56,
                  ),
                  SizedBox(height: 8),
                  Text(
                    'Immagine non disponibile',
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildImagesCard() {
    return Card(
      margin: const EdgeInsets.only(
        bottom: 12,
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(
                  Icons.photo_library_outlined,
                ),
                SizedBox(width: 8),
                Text(
                  'Immagini associate',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 12),

            SizedBox(
              height: 110,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: profile.images.length,
                separatorBuilder: (
                  context,
                  index,
                ) {
                  return const SizedBox(width: 10);
                },
                itemBuilder: (
                  context,
                  index,
                ) {
                  final imageUrl =
                      ApiService.buildResourceUrl(
                    profile.images[index],
                  );

                  return ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: Image.network(
                      imageUrl,
                      width: 110,
                      height: 110,
                      fit: BoxFit.cover,
                      errorBuilder: (
                        context,
                        error,
                        stackTrace,
                      ) {
                        return Container(
                          width: 110,
                          height: 110,
                          alignment: Alignment.center,
                          child: const Icon(
                            Icons.broken_image_outlined,
                          ),
                        );
                      },
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionCard({
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    return Card(
      margin: const EdgeInsets.only(
        bottom: 12,
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon),
                const SizedBox(width: 8),
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 12),

            ...children,
          ],
        ),
      ),
    );
  }

  Widget _buildTextSectionCard({
    required String title,
    required IconData icon,
    required String text,
  }) {
    return Card(
      margin: const EdgeInsets.only(
        bottom: 12,
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon),
                const SizedBox(width: 8),
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 12),

            Text(text),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(
    String label,
    String value,
  ) {
    return Padding(
      padding: const EdgeInsets.symmetric(
        vertical: 5,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            flex: 4,
            child: Text(
              label,
              style: const TextStyle(
                fontWeight: FontWeight.w600,
              ),
            ),
          ),

          const SizedBox(width: 12),

          Expanded(
            flex: 6,
            child: Text(
              value,
            ),
          ),
        ],
      ),
    );
  }
}