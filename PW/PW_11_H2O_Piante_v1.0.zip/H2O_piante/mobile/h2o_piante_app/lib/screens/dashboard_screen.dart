import 'package:flutter/material.dart';

import '../models/environment_reading.dart';
import '../models/plant_profile.dart';
import '../models/soil_moisture.dart';
import '../models/system_status.dart';
import '../services/api_service.dart';
import 'irrigation_screen.dart';
import 'plant_profile_screen.dart';
import 'server_settings_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() =>
      _DashboardScreenState();
}

class _DashboardScreenState
    extends State<DashboardScreen> {
  final ApiService _apiService = ApiService();

  SystemStatus? _systemStatus;
  SoilMoisture? _soilMoisture;
  EnvironmentReading? _environmentReading;
  PlantProfile? _plantProfile;

  bool _isLoadingStatus = true;
  bool _isLoadingSoil = false;
  bool _isLoadingEnvironment = false;
  bool _isLoadingPlantProfile = true;
  bool _isChangingConnection = false;

  String? _statusErrorMessage;
  String? _soilErrorMessage;
  String? _environmentErrorMessage;
  String? _plantProfileErrorMessage;
  String? _connectionActionErrorMessage;

  @override
  void initState() {
    super.initState();
    _loadDashboardData();
  }

  Future<void> _loadDashboardData() async {
    await Future.wait([
      _loadPlantProfile(),
      _loadSystemStatusAndSensors(),
    ]);
  }

  Future<void> _loadSystemStatusAndSensors() async {
    setState(() {
      _isLoadingStatus = true;
      _statusErrorMessage = null;
    });

    try {
      final status = await _apiService.getStatus();

      if (!mounted) {
        return;
      }

      setState(() {
        _systemStatus = status;
        _isLoadingStatus = false;
      });

      if (status.connected) {
        await Future.wait([
          _loadSoilMoisture(),
          _loadEnvironmentReading(),
        ]);
      } else {
        if (mounted) {
          setState(() {
            _soilMoisture = null;
            _environmentReading = null;
            _soilErrorMessage = null;
            _environmentErrorMessage = null;
            _isLoadingSoil = false;
            _isLoadingEnvironment = false;
          });
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _statusErrorMessage = e.toString();
          _isLoadingStatus = false;
          _soilMoisture = null;
          _environmentReading = null;
          _isLoadingSoil = false;
          _isLoadingEnvironment = false;
        });
      }
    }
  }

  Future<void> _connectEsp32() async {
    setState(() {
      _isChangingConnection = true;
      _connectionActionErrorMessage = null;
    });

    try {
      final success = await _apiService.connectEsp32();

      if (!success) {
        throw Exception(
          'Connessione ESP32 non riuscita.',
        );
      }

      await _loadSystemStatusAndSensors();
    } catch (e) {
      if (mounted) {
        setState(() {
          _connectionActionErrorMessage = e.toString();
        });
      }
    } finally {
      if (mounted) {
        setState(() {
          _isChangingConnection = false;
        });
      }
    }
  }

  Future<void> _disconnectEsp32() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Disconnetti ESP32'),
          content: const Text(
            'Vuoi disconnettere ESP32 dal backend H2O Piante?',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(false);
              },
              child: const Text('ANNULLA'),
            ),
            FilledButton(
              onPressed: () {
                Navigator.of(context).pop(true);
              },
              child: const Text('DISCONNETTI'),
            ),
          ],
        );
      },
    );

    if (confirmed != true) {
      return;
    }

    setState(() {
      _isChangingConnection = true;
      _connectionActionErrorMessage = null;
    });

    try {
      final success = await _apiService.disconnectEsp32();

      if (!success) {
        throw Exception(
          'Disconnessione ESP32 non riuscita.',
        );
      }

      await _loadSystemStatusAndSensors();
    } catch (e) {
      if (mounted) {
        setState(() {
          _connectionActionErrorMessage = e.toString();
        });
      }
    } finally {
      if (mounted) {
        setState(() {
          _isChangingConnection = false;
        });
      }
    }
  }

  Future<void> _loadSoilMoisture() async {
    setState(() {
      _isLoadingSoil = true;
      _soilErrorMessage = null;
    });

    try {
      final soilMoisture =
          await _apiService.getSoilMoisture();

      if (mounted) {
        setState(() {
          _soilMoisture = soilMoisture;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _soilMoisture = null;
          _soilErrorMessage = e.toString();
        });
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoadingSoil = false;
        });
      }
    }
  }

  Future<void> _loadEnvironmentReading() async {
    setState(() {
      _isLoadingEnvironment = true;
      _environmentErrorMessage = null;
    });

    try {
      final environment =
          await _apiService.getEnvironmentReading();

      if (mounted) {
        setState(() {
          _environmentReading = environment;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _environmentReading = null;
          _environmentErrorMessage = e.toString();
        });
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoadingEnvironment = false;
        });
      }
    }
  }

  Future<void> _loadPlantProfile() async {
    setState(() {
      _isLoadingPlantProfile = true;
      _plantProfileErrorMessage = null;
    });

    try {
      final profile =
          await _apiService.getActivePlantProfile();

      if (mounted) {
        setState(() {
          _plantProfile = profile;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _plantProfileErrorMessage = e.toString();
        });
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoadingPlantProfile = false;
        });
      }
    }
  }

  void _openPlantProfile() {
    final profile = _plantProfile;

    if (profile == null) {
      return;
    }

    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) {
          return PlantProfileScreen(
            profile: profile,
          );
        },
      ),
    );
  }

  void _openIrrigation() {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) {
          return const IrrigationScreen();
        },
      ),
    );
  }


  Future<void> _openServerSettings() async {
    final changed = await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (context) {
          return const ServerSettingsScreen();
        },
      ),
    );

    if (changed == true && mounted) {
      await _loadDashboardData();
    }
  }

  bool get _espConnected {
    return _systemStatus?.connected == true;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('H2O Piante'),
        centerTitle: true,
        actions: [
          IconButton(
            onPressed: _openServerSettings,
            icon: const Icon(Icons.settings_outlined),
            tooltip: 'Impostazioni server',
          ),
          IconButton(
            onPressed:
                _isChangingConnection
                    ? null
                    : _loadDashboardData,
            icon: const Icon(Icons.refresh),
            tooltip: 'Aggiorna dati',
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _loadDashboardData,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _buildPlantProfileCard(),
            const SizedBox(height: 12),
            _buildIrrigationCard(),
            const SizedBox(height: 12),
            _buildSoilMoistureCard(),
            _buildTemperatureCard(),
            _buildHumidityCard(),
            _buildSystemStatusCard(),
          ],
        ),
      ),
    );
  }

  Widget _buildIrrigationCard() {
    return Card(
      child: ListTile(
        leading: const Icon(
          Icons.opacity,
        ),
        title: const Text(
          'Irrigazione',
        ),
        subtitle: Text(
          _espConnected
              ? 'Stato e comando della pompa'
              : 'ESP32 non connessa',
        ),
        trailing: const Icon(
          Icons.chevron_right,
        ),
        onTap: _openIrrigation,
      ),
    );
  }

  Widget _buildPlantProfileCard() {
    if (_isLoadingPlantProfile) {
      return const Card(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Column(
            children: [
              CircularProgressIndicator(),
              SizedBox(height: 12),
              Text('Caricamento profilo pianta...'),
            ],
          ),
        ),
      );
    }

    if (_plantProfileErrorMessage != null) {
      return Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              const Icon(
                Icons.error_outline,
                size: 48,
              ),
              const SizedBox(height: 12),
              const Text(
                'Errore caricamento profilo',
              ),
              const SizedBox(height: 8),
              Text(
                _plantProfileErrorMessage!,
              ),
            ],
          ),
        ),
      );
    }

    final profile = _plantProfile;

    if (profile == null) {
      return const Card(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Column(
            children: [
              Icon(
                Icons.help_outline,
                size: 48,
              ),
              SizedBox(height: 12),
              Text(
                'Profilo pianta non disponibile',
              ),
            ],
          ),
        ),
      );
    }

    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: _openPlantProfile,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              _buildDashboardPlantImage(profile),
              const SizedBox(height: 12),
              const Text(
                'Pianta attiva',
                style: TextStyle(
                  fontSize: 16,
                ),
              ),
              Text(
                profile.name,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              if (profile.plantName != null &&
                  profile.plantName!.isNotEmpty) ...[
                const SizedBox(height: 4),
                Text(
                  profile.plantName!,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 18,
                  ),
                ),
              ],
              if (profile.scientificName != null &&
                  profile.scientificName!.isNotEmpty) ...[
                const SizedBox(height: 2),
                Text(
                  profile.scientificName!,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 14,
                    fontStyle: FontStyle.italic,
                  ),
                ),
              ],
              if (profile.location != null &&
                  profile.location!.isNotEmpty) ...[
                const SizedBox(height: 8),
                Text(
                  'Posizione: ${profile.location}',
                ),
              ],
              const SizedBox(height: 12),
              const Row(
                mainAxisAlignment:
                    MainAxisAlignment.center,
                children: [
                  Text(
                    'Tocca per visualizzare il profilo',
                    style: TextStyle(
                      fontSize: 12,
                    ),
                  ),
                  SizedBox(width: 4),
                  Icon(
                    Icons.chevron_right,
                    size: 18,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDashboardPlantImage(
    PlantProfile profile,
  ) {
    if (profile.images.isEmpty) {
      return const Icon(
        Icons.eco,
        size: 64,
      );
    }

    final imageUrl =
        ApiService.buildResourceUrl(
      profile.images.first,
    );

    return ClipRRect(
      borderRadius: BorderRadius.circular(14),
      child: Image.network(
        imageUrl,
        width: 130,
        height: 130,
        fit: BoxFit.cover,
        loadingBuilder: (
          context,
          child,
          loadingProgress,
        ) {
          if (loadingProgress == null) {
            return child;
          }

          return const SizedBox(
            width: 130,
            height: 130,
            child: Center(
              child: CircularProgressIndicator(),
            ),
          );
        },
        errorBuilder: (
          context,
          error,
          stackTrace,
        ) {
          return const SizedBox(
            width: 130,
            height: 130,
            child: Center(
              child: Icon(
                Icons.eco,
                size: 64,
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildSoilMoistureCard() {
    if (!_espConnected) {
      return const Card(
        child: ListTile(
          leading: Icon(
            Icons.water_drop_outlined,
          ),
          title: Text('Umidità terreno'),
          subtitle: Text(
            'ESP32 non connessa',
          ),
        ),
      );
    }

    if (_isLoadingSoil) {
      return const Card(
        child: ListTile(
          leading: CircularProgressIndicator(),
          title: Text('Umidità terreno'),
          subtitle: Text('Lettura in corso...'),
        ),
      );
    }

    if (_soilErrorMessage != null) {
      return Card(
        child: ListTile(
          leading: const Icon(Icons.error_outline),
          title: const Text('Umidità terreno'),
          subtitle: Text(
            'Errore durante la lettura del sensore\n'
            '$_soilErrorMessage',
          ),
        ),
      );
    }

    final soil = _soilMoisture;

    if (soil == null ||
        soil.humidityPercent == null) {
      return const Card(
        child: ListTile(
          leading: Icon(Icons.help_outline),
          title: Text('Umidità terreno'),
          subtitle: Text(
            'Dato non disponibile',
          ),
        ),
      );
    }

    return Card(
      child: ListTile(
        leading: const Icon(Icons.water_drop),
        title: const Text('Umidità terreno'),
        subtitle: Text(
          '${soil.humidityPercent!.toStringAsFixed(1)} %\n'
          'Stato: ${soil.state ?? 'Non disponibile'}\n'
          'Valore medio sensore: '
          '${soil.rawAverage?.toStringAsFixed(1) ?? 'Non disponibile'}',
        ),
      ),
    );
  }

  Widget _buildTemperatureCard() {
    if (!_espConnected) {
      return const Card(
        child: ListTile(
          leading: Icon(
            Icons.thermostat_outlined,
          ),
          title: Text('Temperatura ambiente'),
          subtitle: Text(
            'ESP32 non connessa',
          ),
        ),
      );
    }

    if (_isLoadingEnvironment) {
      return const Card(
        child: ListTile(
          leading: CircularProgressIndicator(),
          title: Text('Temperatura ambiente'),
          subtitle: Text('Lettura in corso...'),
        ),
      );
    }

    if (_environmentErrorMessage != null) {
      return Card(
        child: ListTile(
          leading: const Icon(Icons.error_outline),
          title: const Text('Temperatura ambiente'),
          subtitle: Text(
            'Errore durante la lettura ambientale\n'
            '$_environmentErrorMessage',
          ),
        ),
      );
    }

    final environment = _environmentReading;

    if (environment == null ||
        environment.temperatureC == null) {
      return const Card(
        child: ListTile(
          leading: Icon(Icons.help_outline),
          title: Text('Temperatura ambiente'),
          subtitle: Text(
            'Dato non disponibile',
          ),
        ),
      );
    }

    return Card(
      child: ListTile(
        leading: const Icon(Icons.thermostat),
        title: const Text('Temperatura ambiente'),
        subtitle: Text(
          '${environment.temperatureC!.toStringAsFixed(1)} °C\n'
          'Sensore: '
          '${environment.sensor ?? 'Non disponibile'}',
        ),
      ),
    );
  }

  Widget _buildHumidityCard() {
    if (!_espConnected) {
      return const Card(
        child: ListTile(
          leading: Icon(
            Icons.cloud_outlined,
          ),
          title: Text('Umidità ambiente'),
          subtitle: Text(
            'ESP32 non connessa',
          ),
        ),
      );
    }

    if (_isLoadingEnvironment) {
      return const Card(
        child: ListTile(
          leading: CircularProgressIndicator(),
          title: Text('Umidità ambiente'),
          subtitle: Text('Lettura in corso...'),
        ),
      );
    }

    if (_environmentErrorMessage != null) {
      return Card(
        child: ListTile(
          leading: const Icon(Icons.error_outline),
          title: const Text('Umidità ambiente'),
          subtitle: Text(
            'Errore durante la lettura ambientale\n'
            '$_environmentErrorMessage',
          ),
        ),
      );
    }

    final environment = _environmentReading;

    if (environment == null ||
        environment.humidityPercent == null) {
      return const Card(
        child: ListTile(
          leading: Icon(Icons.help_outline),
          title: Text('Umidità ambiente'),
          subtitle: Text(
            'Dato non disponibile',
          ),
        ),
      );
    }

    return Card(
      child: ListTile(
        leading: const Icon(Icons.cloud),
        title: const Text('Umidità ambiente'),
        subtitle: Text(
          '${environment.humidityPercent!.toStringAsFixed(1)} %\n'
          'Sensore: '
          '${environment.sensor ?? 'Non disponibile'}',
        ),
      ),
    );
  }

  Widget _buildSystemStatusCard() {
    if (_isLoadingStatus) {
      return const Card(
        child: ListTile(
          leading: CircularProgressIndicator(),
          title: Text('Stato ESP32'),
          subtitle: Text('Lettura in corso...'),
        ),
      );
    }

    if (_statusErrorMessage != null) {
      return Card(
        child: ListTile(
          leading: const Icon(Icons.error_outline),
          title: const Text('Stato ESP32'),
          subtitle: Text(
            'Errore di comunicazione con il backend\n'
            '$_statusErrorMessage',
          ),
        ),
      );
    }

    final status = _systemStatus;

    if (status == null) {
      return const Card(
        child: ListTile(
          leading: Icon(Icons.help_outline),
          title: Text('Stato ESP32'),
          subtitle: Text('Stato non disponibile'),
        ),
      );
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment:
              CrossAxisAlignment.stretch,
          children: [
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: Icon(
                status.connected
                    ? Icons.check_circle
                    : Icons.cancel,
              ),
              title: const Text('Stato ESP32'),
              subtitle: Text(
                '${status.connected ? 'CONNESSO' : 'NON CONNESSO'}\n'
                'Modalità: ${status.mode}\n'
                'Target: ${status.target}\n'
                'Tentativi falliti: '
                '${status.connectionFailures}/'
                '${status.maxConnectionFailures}',
              ),
            ),
            const SizedBox(height: 8),
            if (status.connected)
              FilledButton.icon(
                onPressed:
                    _isChangingConnection
                        ? null
                        : _disconnectEsp32,
                icon: _isChangingConnection
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                        ),
                      )
                    : const Icon(Icons.link_off),
                label: Text(
                  _isChangingConnection
                      ? 'Operazione in corso...'
                      : 'DISCONNETTI ESP32',
                ),
              )
            else
              FilledButton.icon(
                onPressed:
                    _isChangingConnection
                        ? null
                        : _connectEsp32,
                icon: _isChangingConnection
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                        ),
                      )
                    : const Icon(Icons.link),
                label: Text(
                  _isChangingConnection
                      ? 'Operazione in corso...'
                      : 'CONNETTI ESP32',
                ),
              ),
            if (_connectionActionErrorMessage != null) ...[
              const SizedBox(height: 8),
              Text(
                _connectionActionErrorMessage!,
                style: const TextStyle(
                  color: Colors.red,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
