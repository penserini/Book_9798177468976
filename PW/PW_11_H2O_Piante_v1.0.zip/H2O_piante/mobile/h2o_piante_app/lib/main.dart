import 'package:flutter/material.dart';

import 'screens/dashboard_screen.dart';
import 'screens/server_settings_screen.dart';
import 'services/server_config_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final hasSavedServerConfiguration =
      await ServerConfigService.loadAndApply();

  runApp(
    H2OPianteApp(
      initialServerConfigured: hasSavedServerConfiguration,
    ),
  );
}

class H2OPianteApp extends StatefulWidget {
  final bool initialServerConfigured;

  const H2OPianteApp({
    super.key,
    required this.initialServerConfigured,
  });

  @override
  State<H2OPianteApp> createState() => _H2OPianteAppState();
}

class _H2OPianteAppState extends State<H2OPianteApp> {
  late bool _serverConfigured;

  @override
  void initState() {
    super.initState();
    _serverConfigured = widget.initialServerConfigured;
  }

  void _onInitialServerConfigurationSaved() {
    setState(() {
      _serverConfigured = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'H2O Piante',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.green,
        ),
        useMaterial3: true,
      ),
      home: _serverConfigured
          ? const DashboardScreen()
          : ServerSettingsScreen(
              onConfigurationSaved:
                  _onInitialServerConfigurationSaved,
            ),
    );
  }
}
