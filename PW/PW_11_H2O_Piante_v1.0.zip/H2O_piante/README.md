# PW_11 — H2O Piante v1.0

**L’applicazione funziona come sistema di monitoraggio e irrigazione solamente con l’hardware presentato nel libro, correttamente assemblato, programmato e calibrato. Il solo ZIP non sostituisce ESP32, sensori e pompa.** Senza hardware è possibile aprire la dashboard e gestire profili, ma non acquisire misure reali o irrigare. Non è incluso un simulatore.

## Hardware e firmware di questo rilascio

Questo archivio contiene backend Python/FastAPI, dashboard web, firmware ESP32 e sorgenti del client Flutter. Non contiene APK o eseguibili mobile pronti.

| Componente | Collegamento previsto dal codice |
| --- | --- |
| ESP32 (scheda NodeMCU/CP2102 del libro) | USB seriale 115200 baud oppure Wi-Fi/HTTP |
| ADS1115 e sensore capacitivo di umidità del terreno | AOUT sensore su A0 ADS1115; bus I²C SDA GPIO21, SCL GPIO22 |
| SHT31 temperatura/umidità | Stesso bus I²C, indirizzo 0x44 |
| MOSFET e micropompa 3–5 V | Comando GPIO25, HIGH acceso; alimentazione e cablaggio come nel libro |
| Serbatoio, tubo, gocciolatoio e alimentatore 5 V | Catena idraulica da calibrare realmente |

**Il firmware principale incluso usa SHT31. Il modulo Python DHT11 presente non viene selezionato da AppContext: collegare un DHT11 al posto dello SHT31 non rende questa versione compatibile.** Seguire lo schema elettrico del libro per alimentazioni, massa comune e circuito di potenza. La pompa non va alimentata direttamente dal GPIO. Il firmware limita ogni comando di erogazione a 60 secondi.

## 1. Programmare ESP32

Aprire `firmware/H2O_piante_esp32/H2O_piante_esp32.ino` nell’ambiente Arduino configurato per ESP32. Servono le librerie `Adafruit ADS1X15`, `Adafruit SHT31` e le relative dipendenze, oltre alle librerie WiFi/WebServer/ESPmDNS/Wire del core ESP32.

Il file `wifi_secrets.h` incluso contiene solo segnaposto: inserire localmente SSID e password della propria rete, mantenendo `DEVICE_NAME` oppure aggiornando l’URL del backend. Non pubblicare il file compilato con credenziali vere. Il file example consente di ricrearlo. Caricare il firmware selezionando scheda e porta corrette. In modalità USB il firmware resta disponibile anche se il Wi-Fi non si collega; l’avvio può attendere circa 12 secondi.

## 2. Installare il backend Windows

1. Estrarre completamente lo ZIP in una cartella scrivibile.
2. Installare Python 3.10 o successivo a 64 bit, con pip e venv. Il BAT cerca `py` e `python`; non presume una versione già installata.
3. Eseguire `Installa.bat`: crea `.venv`, installa `requirements.txt` e verifica le dipendenze. Serve Internet. Il BAT non installa Arduino, firmware, driver USB o Flutter.
4. Se necessario installare il driver CP2102 della scheda. Chiudere il monitor seriale Arduino prima di usare il backend.

Installazione manuale equivalente dalla cartella H2O_piante:

```bat
python -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe -m pip check
```

## 3. Avviare e connettere

USB: eseguire `Avvia_H2O_Piante_Seriale.bat`. Il valore predefinito è COM3: verificare la porta in Gestione dispositivi. Per cambiarla, nello stesso prompt:

```bat
set "H2O_SERIAL_PORT=COM5"
call Avvia_H2O_Piante_Seriale.bat
```

Wi-Fi: eseguire `Avvia_H2O_Piante_WiFi_OpenAI_v3.bat`. Usa `http://h2o-pianta-01.local`; se mDNS non risolve, impostare l’IP visualizzato dal firmware:

```bat
set "H2O_ESP32_URL=http://IP_DELLA_ESP32"
call Avvia_H2O_Piante_WiFi_OpenAI_v3.bat
```

Aprire `http://127.0.0.1:8000/`, premere **CONNETTI ESP32** e controllare la connessione. API disponibili su `/docs`. Una dashboard aperta non dimostra che i sensori siano connessi. Arrestare con Ctrl+C. Avviare una sola istanza del backend.

## 4. Calibrare prima dell’uso

Il rilascio parte senza calibrazioni, fotografie o storico dell’autore. Il primo avvio crea un profilo generico PIANTA_1. Eseguire la calibrazione del sensore nei cinque stati ARIA, ASCIUTTO, UMIDO, BAGNATO e SATURO seguendo il libro e la dashboard. Calibrare anche la portata della pompa: servono almeno tre misure valide di durata e volume realmente erogato con alimentazione, tubo e gocciolatoio effettivamente utilizzati. Non riutilizzare valori di un altro impianto. Verificare il comando di arresto prima delle prove di erogazione.

## OpenAI: funzione opzionale

Non è inclusa alcuna chiave API. Il monitoraggio e il comando hardware non richiedono OpenAI; le analisi AI richiedono Internet, una chiave personale in `OPENAI_API_KEY` e un modello disponibile per il proprio account, compatibile con immagini e con il formato richiesto dal provider. Configurare la variabile nell’ambiente locale, senza inserirla nel repository.

Il codice originale usa come default `gpt-5.6-terra`: il suo accesso non è stato verificato. Si può scegliere il modello tramite `OPENAI_PLANT_MODEL`. Le tariffe presenti nel codice sono stime storiche e non un listino aggiornato. Le analisi inviano foto e contesto della pianta al servizio; possono comportare costi. Il backend legge variabili d’ambiente, **non carica automaticamente un file .env**.

## Client Flutter e smartphone

I sorgenti sono in `mobile/h2o_piante_app`. Il pubspec richiede Dart `^3.12.2`: usare una versione Flutter che soddisfi tale vincolo e una toolchain adatta alla piattaforma. Dalla cartella client:

```text
flutter doctor
flutter pub get
flutter analyze
flutter test
flutter run
```

Il server configurato nell’app è il backend Python, non l’ESP32. Per Android emulato è predefinito `10.0.2.2:8000`; per un telefono reale usare l’IP LAN del PC e la porta 8000, nella stessa rete.

I BAT avviano il backend su 127.0.0.1. Per accesso da telefono impostare nel prompt `set "H2O_SERVER_HOST=0.0.0.0"` prima di richiamare il BAT e autorizzare nel firewall solamente la rete privata necessaria. Backend e firmware non implementano autenticazione: usare esclusivamente una rete locale fidata, senza inoltro porte dal router. Il BAT non modifica il firewall.

## Contenuti esclusi e verifiche

Rimossi credenziali Wi-Fi, percorsi locali dell’autore, foto, profili, storico AI, calibrazioni e cache/generated files contenenti riferimenti alla macchina originaria. Il sorgente applicativo e il firmware funzionale sono mantenuti; i BAT sono resi portabili e le dipendenze mancanti sono aggiunte.

Vedere `VERIFICA_RILASCIO.txt` per i controlli realmente eseguiti. Installazione e avvio software non equivalgono a collaudo fisico: hardware, calibrazione, firmware su scheda, Windows e compilazione Flutter richiedono verifica sul sistema reale.
