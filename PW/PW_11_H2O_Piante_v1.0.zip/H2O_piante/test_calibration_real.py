from app.hardware.serial_connection import SerialConnection
from app.services.calibration_service import CalibrationService


connection = SerialConnection(
    port="COM3",
    baudrate=115200
)

service = CalibrationService()

try:
    print("Connessione alla ESP32...")

    connection.connect()

    print(
        "Connessione attiva:",
        connection.is_connected()
    )

    print(
        "PING:",
        connection.ping()
    )

    print("\nAcquisizione calibrazione reale...")

    point = service.acquire_calibration(
        connection=connection,
        name="TEST_REALE",
        channel=0,
        samples=10
    )

    print("\nPunto creato:")
    print(point)

finally:
    connection.disconnect()

    print("\nConnessione chiusa.")