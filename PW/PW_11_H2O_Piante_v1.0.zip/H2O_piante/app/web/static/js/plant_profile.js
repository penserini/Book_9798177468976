function nullableNumberFromInput(
    elementId
) {

    const rawValue =
        document.getElementById(
            elementId
        ).value.trim();


    if (
        rawValue === ""
    ) {

        return null;

    }


    return Number(
        rawValue
    );

}



function setNullableNumberInput(
    elementId,
    value
) {

    document.getElementById(
        elementId
    ).value =
        (
            value === null
            ||
            value === undefined
        )
        ? ""
        : value;

}



function validatePlantProfileClient(
    profile
) {

    const percentages = [
        profile.minimum_humidity_percent,
        profile.target_humidity_percent,
        profile.maximum_humidity_percent
    ];


    for (
        const value
        of percentages
    ) {

        if (
            value !== null
            &&
            (
                value < 0
                ||
                value > 100
            )
        ) {

            return (
                "Le percentuali di umidità devono essere "
                + "comprese tra 0 e 100."
            );

        }

    }


    if (
        profile.minimum_humidity_percent !== null
        &&
        profile.target_humidity_percent !== null
        &&
        profile.minimum_humidity_percent
        >
        profile.target_humidity_percent
    ) {

        return (
            "L'umidità minima non può essere maggiore "
            + "dell'umidità obiettivo."
        );

    }


    if (
        profile.target_humidity_percent !== null
        &&
        profile.maximum_humidity_percent !== null
        &&
        profile.target_humidity_percent
        >
        profile.maximum_humidity_percent
    ) {

        return (
            "L'umidità obiettivo non può essere maggiore "
            + "dell'umidità massima."
        );

    }


    if (
        profile.water_dose_ml !== null
        &&
        profile.water_dose_ml < 0
    ) {

        return (
            "La dose d'acqua non può essere negativa."
        );

    }


    return null;

}



async function loadPlantProfile() {

    const message =
        document.getElementById(
            "plantProfileMessage"
        );


    try {

        const response =
            await fetch(
                "/api/plant/profile"
            );


        const data =
            await response.json();


        if (
            !data.success
        ) {

            message.textContent =
                data.message;


            return;

        }


        const profile =
            data.profile;


        document.getElementById(
            "plantProfileName"
        ).value =
            profile.name;


        document.getElementById(
            "plantName"
        ).value =
            profile.plant_name;


        document.getElementById(
            "plantProfileSource"
        ).value =
            profile.source;


        setNullableNumberInput(
            "minimumHumidityPercent",
            profile.minimum_humidity_percent
        );


        setNullableNumberInput(
            "targetHumidityPercent",
            profile.target_humidity_percent
        );


        setNullableNumberInput(
            "maximumHumidityPercent",
            profile.maximum_humidity_percent
        );


        setNullableNumberInput(
            "waterDoseMl",
            profile.water_dose_ml
        );


        message.textContent =
            "Profilo caricato correttamente.";

    }

    catch (error) {

        message.textContent =
            "Errore durante il caricamento del profilo.";

    }

}



async function savePlantProfile() {

    const button =
        document.getElementById(
            "btnSavePlantProfile"
        );


    const message =
        document.getElementById(
            "plantProfileMessage"
        );


    const profile = {

        name:
            document.getElementById(
                "plantProfileName"
            ).value.trim(),

        plant_name:
            document.getElementById(
                "plantName"
            ).value.trim(),

        minimum_humidity_percent:
            nullableNumberFromInput(
                "minimumHumidityPercent"
            ),

        target_humidity_percent:
            nullableNumberFromInput(
                "targetHumidityPercent"
            ),

        maximum_humidity_percent:
            nullableNumberFromInput(
                "maximumHumidityPercent"
            ),

        water_dose_ml:
            nullableNumberFromInput(
                "waterDoseMl"
            ),

        source:
            document.getElementById(
                "plantProfileSource"
            ).value

    };


    if (
        profile.name === ""
        ||
        profile.plant_name === ""
    ) {

        message.textContent =
            "Nome profilo e nome pianta sono obbligatori.";


        return;

    }


    const validationError =
        validatePlantProfileClient(
            profile
        );


    if (
        validationError !== null
    ) {

        message.textContent =
            validationError;


        return;

    }


    button.disabled =
        true;


    message.textContent =
        "Salvataggio profilo in corso...";


    try {

        const response =
            await fetch(
                "/api/plant/profile",
                {

                    method:
                        "PUT",

                    headers: {

                        "Content-Type":
                            "application/json"

                    },

                    body:
                        JSON.stringify(
                            profile
                        )

                }
            );


        const data =
            await response.json();


        if (
            !response.ok
        ) {

            if (
                data.detail
            ) {

                message.textContent =
                    "Profilo non valido. Controllare i dati inseriti.";

            }

            else {

                message.textContent =
                    data.message
                    || "Errore durante il salvataggio del profilo.";

            }


            return;

        }


        if (
            !data.success
        ) {

            message.textContent =
                data.message;


            return;

        }


        message.textContent =
            "Profilo pianta salvato correttamente.";


        /*
         * Rileggiamo il profilo dal backend.
         *
         * In questo modo la GUI visualizza
         * esattamente il contenuto realmente
         * scritto in plant_profile.json.
         */

        await loadPlantProfile();


        /*
         * IMPORTANTE:
         *
         * se era già visualizzato un consiglio
         * di irrigazione, quel consiglio è stato
         * calcolato usando il profilo precedente.
         *
         * Lo nascondiamo per impedire di mostrare
         * una decisione ormai non più valida.
         */

        const irrigationResults =
            document.getElementById(
                "irrigationResults"
            );


        const irrigationMessage =
            document.getElementById(
                "irrigationMessage"
            );


        if (
            irrigationResults
        ) {

            irrigationResults.style.display =
                "none";

        }


        if (
            irrigationMessage
        ) {

            irrigationMessage.textContent =
                "Profilo aggiornato. Rivalutare l'irrigazione.";

        }

    }

    catch (error) {

        message.textContent =
            "Errore durante il salvataggio del profilo.";

    }

    finally {

        button.disabled =
            false;

    }

}