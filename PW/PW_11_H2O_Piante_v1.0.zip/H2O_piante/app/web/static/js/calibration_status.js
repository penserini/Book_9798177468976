async function loadCalibrationStatus() {

    const badge =
        document.getElementById(
            "calibrationStatusBadge"
        );


    const message =
        document.getElementById(
            "calibrationStatusMessage"
        );


    const missing =
        document.getElementById(
            "calibrationMissing"
        );


    const valuesContainer =
        document.getElementById(
            "calibrationValuesContainer"
        );


    const valuesElement =
        document.getElementById(
            "calibrationValues"
        );


    const errorsContainer =
        document.getElementById(
            "calibrationErrorsContainer"
        );


    const errorsElement =
        document.getElementById(
            "calibrationErrors"
        );


    try {

        const response =
            await fetch(
                "/api/calibration/status"
            );


        const data =
            await response.json();


        if (
            !data.success
        ) {

            badge.textContent =
                "ERRORE";


            badge.className =
                "calibration-status calibration-status-error";


            message.textContent =
                data.message;


            return;

        }


        /*
         * STATO GRAFICO
         */

        if (
            data.complete === true
            &&
            data.valid === true
        ) {

            badge.textContent =
                "COMPLETA E VALIDA";


            badge.className =
                "calibration-status calibration-status-ok";

        }

        else if (
            data.complete === false
        ) {

            badge.textContent =
                "INCOMPLETA";


            badge.className =
                "calibration-status calibration-status-warning";

        }

        else {

            badge.textContent =
                "NON COERENTE";


            badge.className =
                "calibration-status calibration-status-error";

        }


        message.textContent =
            data.message || "";


        /*
         * PUNTI MANCANTI
         */

        if (
            data.missing
            &&
            data.missing.length > 0
        ) {

            missing.textContent =
                "Punti mancanti: "
                + data.missing.join(", ");


            missing.style.display =
                "block";

        }

        else {

            missing.textContent =
                "";


            missing.style.display =
                "none";

        }


        /*
         * VALORI DI CALIBRAZIONE
         */

        valuesElement.innerHTML =
            "";


        if (
            data.values
        ) {

            const order = [
                "ARIA",
                "ASCIUTTO",
                "UMIDO",
                "BAGNATO",
                "SATURO"
            ];


            order.forEach(
                function(name) {

                    if (
                        data.values[name]
                        === undefined
                    ) {

                        return;

                    }


                    const card =
                        document.createElement(
                            "div"
                        );


                    card.className =
                        "calibration-value-card";


                    const label =
                        document.createElement(
                            "span"
                        );


                    label.className =
                        "calibration-value-label";


                    label.textContent =
                        name;


                    const value =
                        document.createElement(
                            "span"
                        );


                    value.className =
                        "calibration-value-number";


                    value.textContent =
                        data.values[name];


                    card.appendChild(
                        label
                    );


                    card.appendChild(
                        value
                    );


                    valuesElement.appendChild(
                        card
                    );

                }
            );


            valuesContainer.style.display =
                "block";

        }

        else {

            valuesContainer.style.display =
                "none";

        }


        /*
         * ERRORI DI COERENZA
         */

        errorsElement.innerHTML =
            "";


        if (
            data.errors
            &&
            data.errors.length > 0
        ) {

            data.errors.forEach(
                function(error) {

                    const item =
                        document.createElement(
                            "li"
                        );


                    item.textContent =
                        error;


                    errorsElement.appendChild(
                        item
                    );

                }
            );


            errorsContainer.style.display =
                "block";

        }

        else {

            errorsContainer.style.display =
                "none";

        }

    }

    catch (error) {

        badge.textContent =
            "ERRORE";


        badge.className =
            "calibration-status calibration-status-error";


        message.textContent =
            "Impossibile verificare lo stato della calibrazione.";

    }

}