// ==================================================
// INIZIALIZZAZIONE DELLA PAGINA
// ==================================================

async function initializePage() {

    /*
     * All'avvio non esiste una nuova
     * acquisizione di calibrazione salvabile.
     */

    disableCalibrationSave();


    /*
     * Dati persistenti.
     */

    await loadCalibrationPoints();

    await loadCalibrationStatus();

    await loadPlantProfile();


    /*
     * Verifica della ESP32.
     */

    const connected =
        await checkConnectionStatus();


    /*
     * Stato iniziale del sottosistema ambientale.
     */

    await loadEnvironmentStatus();


    /*
     * Se ESP32 risponde:
     *
     * 1. controlliamo il sensore terreno;
     * 2. leggiamo temperatura e umidità ambiente.
     */

    if (
        connected
    ) {

        await checkSensorStatus();

        await readEnvironment();

    }

}



// ==================================================
// AVVIO APPLICAZIONE
// ==================================================

initializePage();



// ==================================================
// HEARTBEAT ESP32
// ==================================================
//
// Manteniamo ESATTAMENTE il comportamento
// già verificato.
//
// Ogni 5 secondi controlliamo la connessione.
// ==================================================

setInterval(
    checkConnectionStatus,
    5000
);



// ==================================================
// CONTROLLO AUTOMATICO SENSORE TERRENO
// ==================================================
//
// Manteniamo il comportamento precedente.
//
// Non modifica last_measurements e non abilita
// il salvataggio della calibrazione.
// ==================================================

setInterval(

    async function() {

        const connected =
            await checkConnectionStatus();


        if (
            connected
        ) {

            await checkSensorStatus();

        }

    },

    15000

);



// ==================================================
// NUOVO:
// AGGIORNAMENTO AUTOMATICO AMBIENTE
// ==================================================
//
// Il DHT11 non deve essere interrogato con
// la frequenza dell'heartbeat.
//
// Una lettura ogni 30 secondi è più che
// sufficiente per il microclima della pianta.
//
// Quando arriverà SHT31 potremo mantenere
// tranquillamente questo intervallo.
// ==================================================

setInterval(

    async function() {

        const connected =
            await checkConnectionStatus();


        if (
            connected
        ) {

            await automaticEnvironmentUpdate();

        }

    },

    30000

);