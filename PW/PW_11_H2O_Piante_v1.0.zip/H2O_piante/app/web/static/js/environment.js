// ==================================================
// UTILITÀ GRAFICHE AMBIENTE
// ==================================================

function clearEnvironmentValues() {

    document.getElementById(
        "environmentTemperature"
    ).textContent =
        "Non disponibile";


    document.getElementById(
        "environmentHumidity"
    ).textContent =
        "Non disponibile";


    document.getElementById(
        "environmentTimestamp"
    ).textContent =
        "Non disponibile";

}



// ==================================================
// FORMATTAZIONE TIMESTAMP
// ==================================================

function formatEnvironmentTimestamp(
    timestamp
) {

    if (
        !timestamp
    ) {

        return "Non disponibile";

    }


    try {

        const date =
            new Date(
                timestamp
            );


        return (
            date.toLocaleString(
                "it-IT"
            )
        );

    }

    catch (error) {

        return timestamp;

    }

}



// ==================================================
// STATO SENSORE AMBIENTALE
// ==================================================

async function loadEnvironmentStatus() {

    const sensorLabel =
        document.getElementById(
            "environmentSensor"
        );


    const message =
        document.getElementById(
            "environmentMessage"
        );


    const button =
        document.getElementById(
            "btnReadEnvironment"
        );


    try {

        const response =
            await fetch(
                "/api/environment/status"
            );


        const data =
            await response.json();


        if (
            !data.success
        ) {

            sensorLabel.textContent =
                "Errore";


            message.textContent =
                data.message
                ||
                "Impossibile verificare il sensore ambientale.";


            button.disabled =
                true;


            return false;

        }


        if (
            !data.configured
        ) {

            sensorLabel.textContent =
                "Non configurato";


            message.textContent =
                "Nessun sensore ambientale configurato.";


            button.disabled =
                true;


            clearEnvironmentValues();


            return false;

        }


        sensorLabel.textContent =
            data.sensor
            ||
            "Sensore ambientale";


        if (
            !data.available
        ) {

            message.textContent =
                "Sensore ambientale configurato ma non disponibile.";


            button.disabled =
                true;


            return false;

        }


        message.textContent =
            "Sensore ambientale disponibile.";


        button.disabled =
            false;


        return true;

    }

    catch (error) {

        sensorLabel.textContent =
            "Non verificato";


        message.textContent =
            "Errore durante la verifica del sensore ambientale.";


        button.disabled =
            true;


        return false;

    }

}



// ==================================================
// LETTURA AMBIENTALE
// ==================================================

async function readEnvironment() {

    const button =
        document.getElementById(
            "btnReadEnvironment"
        );


    const sensorLabel =
        document.getElementById(
            "environmentSensor"
        );


    const temperatureLabel =
        document.getElementById(
            "environmentTemperature"
        );


    const humidityLabel =
        document.getElementById(
            "environmentHumidity"
        );


    const timestampLabel =
        document.getElementById(
            "environmentTimestamp"
        );


    const message =
        document.getElementById(
            "environmentMessage"
        );


    button.disabled =
        true;


    message.textContent =
        "Lettura ambientale in corso...";


    try {

        const response =
            await fetch(
                "/api/environment/read"
            );


        const data =
            await response.json();


        if (
            !data.success
        ) {

            message.textContent =
                data.message
                ||
                "Lettura ambientale non disponibile.";


            if (
                data.sensor
            ) {

                sensorLabel.textContent =
                    data.sensor;

            }


            return false;

        }


        sensorLabel.textContent =
            data.sensor;


        temperatureLabel.textContent =
            `${data.temperature_c} °C`;


        humidityLabel.textContent =
            `${data.humidity_percent} %`;


        timestampLabel.textContent =
            formatEnvironmentTimestamp(
                data.timestamp
            );


        message.textContent =
            "Lettura ambientale completata correttamente.";


        return true;

    }

    catch (error) {

        message.textContent =
            "Errore durante la lettura ambientale.";


        return false;

    }

    finally {

        /*
         * Verifichiamo nuovamente lo stato.
         *
         * In questo modo il pulsante viene
         * riabilitato solamente se il sensore
         * risulta ancora disponibile.
         */

        await loadEnvironmentStatus();

    }

}



// ==================================================
// AGGIORNAMENTO AUTOMATICO
// ==================================================

async function automaticEnvironmentUpdate() {

    /*
     * Prima controlliamo che il sottosistema
     * sia realmente disponibile.
     */

    const available =
        await loadEnvironmentStatus();


    if (
        !available
    ) {

        return;

    }


    /*
     * Solo se disponibile eseguiamo
     * una misura reale.
     */

    await readEnvironment();

}