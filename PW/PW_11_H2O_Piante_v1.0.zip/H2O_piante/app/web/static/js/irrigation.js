async function loadIrrigationAdvice() {

    const button =
        document.getElementById(
            "btnIrrigationAdvice"
        );


    const message =
        document.getElementById(
            "irrigationMessage"
        );


    const results =
        document.getElementById(
            "irrigationResults"
        );


    button.disabled =
        true;


    message.textContent =
        "Valutazione in corso...";


    results.style.display =
        "none";


    try {

        const response =
            await fetch(
                "/api/irrigation/advice"
                + "?channel=0"
                + "&samples=10"
            );


        const data =
            await response.json();


        if (
            !data.success
        ) {

            if (
                data.connected
                === false
            ) {

                updateConnectionDisplay(
                    false
                );

            }


            message.textContent =
                data.message;


            return;

        }


        updateConnectionDisplay(
            true
        );


        if (
            data.sensor_detected
            === false
        ) {

            updateSensorDisplay(
                false,
                data.message
            );


            message.textContent =
                data.message;


            return;

        }


        updateSensorDisplay(
            true,
            "Sensore rilevato correttamente."
        );


        if (
            data.decision_available
            !== true
        ) {

            message.textContent =
                data.reason
                || "Decisione non disponibile.";


            return;

        }


        document.getElementById(
            "irrigationState"
        ).textContent =
            data.measurement.state;


        document.getElementById(
            "irrigationHumidity"
        ).textContent =
            data.measurement.humidity_percent
            + " %";


        document.getElementById(
            "irrigationRequired"
        ).textContent =
            data.irrigation_required
            ? "SÌ"
            : "NO";


        if (
            data.recommended_water_ml
            === null
        ) {

            document.getElementById(
                "irrigationWater"
            ).textContent =
                "Da definire";

        }

        else {

            document.getElementById(
                "irrigationWater"
            ).textContent =
                data.recommended_water_ml
                + " ml";

        }


        document.getElementById(
            "irrigationReason"
        ).textContent =
            data.reason;


        document.getElementById(
            "irrigationProfileName"
        ).textContent =
            data.profile.name;


        document.getElementById(
            "irrigationPlantName"
        ).textContent =
            data.profile.plant_name;


        document.getElementById(
            "irrigationProfileSource"
        ).textContent =
            data.profile.source;


        /*
         * Evidenziamo graficamente
         * la decisione.
         */

        const decisionElement =
            document.getElementById(
                "irrigationRequired"
            );


        if (
            data.irrigation_required
        ) {

            decisionElement.className =
                "info-value irrigation-yes";

        }

        else {

            decisionElement.className =
                "info-value irrigation-no";

        }


        message.textContent =
            "Valutazione completata correttamente.";


        results.style.display =
            "block";

    }

    catch (error) {

        message.textContent =
            "Errore durante la valutazione dell'irrigazione.";

    }

    finally {

        button.disabled =
            false;

    }

}