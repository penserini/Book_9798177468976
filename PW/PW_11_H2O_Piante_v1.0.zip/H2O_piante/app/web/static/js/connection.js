function updateConnectionButtons(connected) {
    const btnConnect =
        document.getElementById("btnConnect");

    const btnDisconnect =
        document.getElementById("btnDisconnect");

    if (!btnConnect || !btnDisconnect) {
        return;
    }

    btnConnect.disabled = connected;
    btnDisconnect.disabled = !connected;
}


async function checkConnectionStatus() {
    try {
        const response =
            await fetch(
                "/api/status",
                {
                    cache: "no-store"
                }
            );

        if (!response.ok) {
            throw new Error(
                `HTTP ${response.status}`
            );
        }

        const data =
            await response.json();

        const connected =
            data.connected === true;

        updateConnectionDisplay(
            connected
        );

        updateConnectionButtons(
            connected
        );

        return connected;
    }
    catch (error) {
        console.error(
            "Errore controllo connessione ESP32:",
            error
        );

        updateConnectionDisplay(
            false
        );

        updateConnectionButtons(
            false
        );

        return false;
    }
}


async function connectESP32() {
    const message =
        document.getElementById(
            "connectionMessage"
        );

    const btnConnect =
        document.getElementById(
            "btnConnect"
        );

    const btnDisconnect =
        document.getElementById(
            "btnDisconnect"
        );

    if (btnConnect) {
        btnConnect.disabled = true;
    }

    if (btnDisconnect) {
        btnDisconnect.disabled = true;
    }

    if (message) {
        message.textContent =
            "Connessione in corso...";
    }

    try {
        const response =
            await fetch(
                "/api/connect",
                {
                    method: "POST",
                    cache: "no-store"
                }
            );

        if (!response.ok) {
            throw new Error(
                `HTTP ${response.status}`
            );
        }

        const data =
            await response.json();

        const connected =
            data.connected === true;

        updateConnectionDisplay(
            connected
        );

        updateConnectionButtons(
            connected
        );

        if (message) {
            message.textContent =
                data.message ??
                (
                    connected
                        ? "ESP32 connessa correttamente."
                        : "Connessione ESP32 non riuscita."
                );
        }

        if (connected) {
            await checkSensorStatus();
        }
        else {
            updateSensorDisplay(
                null,
                "Sensore non verificabile: ESP32 non connessa."
            );
        }
    }
    catch (error) {
        console.error(
            "Errore connessione ESP32:",
            error
        );

        updateConnectionDisplay(
            false
        );

        updateConnectionButtons(
            false
        );

        if (message) {
            message.textContent =
                "Errore di comunicazione con il server.";
        }
    }
}


async function disconnectESP32() {
    const message =
        document.getElementById(
            "connectionMessage"
        );

    const btnConnect =
        document.getElementById(
            "btnConnect"
        );

    const btnDisconnect =
        document.getElementById(
            "btnDisconnect"
        );

    if (btnConnect) {
        btnConnect.disabled = true;
    }

    if (btnDisconnect) {
        btnDisconnect.disabled = true;
    }

    if (message) {
        message.textContent =
            "Disconnessione in corso...";
    }

    try {
        const response =
            await fetch(
                "/api/disconnect",
                {
                    method: "POST",
                    cache: "no-store"
                }
            );

        if (!response.ok) {
            throw new Error(
                `HTTP ${response.status}`
            );
        }

        const data =
            await response.json();

        const connected =
            data.connected === true;

        updateConnectionDisplay(
            connected
        );

        updateConnectionButtons(
            connected
        );

        if (message) {
            message.textContent =
                data.message ??
                "ESP32 disconnessa.";
        }

        if (!connected) {
            updateSensorDisplay(
                null,
                "Sensore non verificabile: ESP32 non connessa."
            );
        }
    }
    catch (error) {
        console.error(
            "Errore disconnessione ESP32:",
            error
        );

        if (message) {
            message.textContent =
                "Errore di comunicazione con il server.";
        }

        await checkConnectionStatus();
    }
}


function startConnectionStatusPolling() {
    checkConnectionStatus();

    window.setInterval(
        checkConnectionStatus,
        3000
    );
}


if (document.readyState === "loading") {
    document.addEventListener(
        "DOMContentLoaded",
        startConnectionStatusPolling
    );
}
else {
    startConnectionStatusPolling();
}