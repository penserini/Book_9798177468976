let editingProfileId =
    null;


let editingImages =
    [];


let currentPlantAIResult =
    null;


let plantAIConfigured =
    false;


let requestedPlantTab =
    "profile";


let irrigationSources = {
    minimum_humidity_source: null,
    target_humidity_source: null,
    maximum_humidity_source: null,
    average_water_source: null,
    water_dose_source: null,
    watering_frequency_source: null
};


const irrigationSourceBindings = {
    minimumHumidity: ["minimum_humidity_source", "minimumHumiditySource"],
    targetHumidity: ["target_humidity_source", "targetHumiditySource"],
    maximumHumidity: ["maximum_humidity_source", "maximumHumiditySource"],
    averageWaterMl: ["average_water_source", "averageWaterSource"],
    waterDoseMl: ["water_dose_source", "waterDoseSource"],
    wateringFrequencyDays: ["watering_frequency_source", "wateringFrequencySource"]
};


let profileFieldSources = {
    description_source: null,
    exposure_source: null,
    soil_type_source: null,
    notes_source: null
};


const profileFieldSourceBindings = {
    plantDescription: ["description_source", "plantDescriptionSource"],
    plantExposure: ["exposure_source", "plantExposureSource"],
    soilType: ["soil_type_source", "soilTypeSource"],
    plantNotes: ["notes_source", "plantNotesSource"]
};



// ==================================================
// SUPPORTO CAMPI
// ==================================================

function nullableNumber(
    elementId
) {

    const raw =
        document
        .getElementById(
            elementId
        )
        .value
        .trim();


    return (
        raw === ""
        ? null
        : Number(raw)
    );

}



function nullableText(
    elementId
) {

    const value =
        document
        .getElementById(
            elementId
        )
        .value
        .trim();


    return (
        value === ""
        ? null
        : value
    );

}



function setNullableNumber(
    elementId,
    value
) {

    document.getElementById(
        elementId
    ).value =
        (
            value === null
            ||
            value === undefined
        )
        ? ""
        : value;

}



function setNullableText(
    elementId,
    value
) {

    document.getElementById(
        elementId
    ).value =
        (
            value === null
            ||
            value === undefined
        )
        ? ""
        : value;

}


function normalizeIrrigationSource(value) {

    const allowed = [
        "MANUALE",
        "AI",
        "DATABASE",
        "CALCOLATA"
    ];

    return allowed.includes(value)
        ? value
        : null;

}


function renderIrrigationSources() {

    for (const [inputId, binding] of Object.entries(irrigationSourceBindings)) {

        const [sourceKey, badgeId] = binding;
        const badge = document.getElementById(badgeId);

        if (!badge) {
            continue;
        }

        const source = irrigationSources[sourceKey];
        badge.textContent = `Fonte: ${source || "-"}`;
        badge.dataset.source = source || "";
    }

}


function setIrrigationSource(sourceKey, value) {

    irrigationSources[sourceKey] = normalizeIrrigationSource(value);
    renderIrrigationSources();

}


function resetIrrigationSources() {

    for (const key of Object.keys(irrigationSources)) {
        irrigationSources[key] = null;
    }

    renderIrrigationSources();

}


function bindManualIrrigationSourceTracking() {

    for (const [inputId, binding] of Object.entries(irrigationSourceBindings)) {

        const input = document.getElementById(inputId);

        if (!input) {
            continue;
        }

        const [sourceKey] = binding;

        input.addEventListener(
            "input",
            () => {
                const value = input.value.trim();
                setIrrigationSource(
                    sourceKey,
                    value === "" ? null : "MANUALE"
                );
            }
        );
    }

}


function normalizeProfileFieldSource(value) {

    const allowed = [
        "MANUALE",
        "AI",
        "DATABASE"
    ];

    return allowed.includes(value)
        ? value
        : null;

}


function renderProfileFieldSources() {

    for (const [inputId, binding] of Object.entries(profileFieldSourceBindings)) {

        const [sourceKey, badgeId] = binding;
        const badge = document.getElementById(badgeId);

        if (!badge) {
            continue;
        }

        const source = profileFieldSources[sourceKey];
        badge.textContent = `Fonte: ${source || "-"}`;
        badge.dataset.source = source || "";
    }

}


function setProfileFieldSource(sourceKey, value) {

    profileFieldSources[sourceKey] = normalizeProfileFieldSource(value);
    renderProfileFieldSources();

}


function resetProfileFieldSources() {

    for (const key of Object.keys(profileFieldSources)) {
        profileFieldSources[key] = null;
    }

    renderProfileFieldSources();

}


function bindManualProfileFieldSourceTracking() {

    for (const [inputId, binding] of Object.entries(profileFieldSourceBindings)) {

        const input = document.getElementById(inputId);

        if (!input) {
            continue;
        }

        const [sourceKey] = binding;

        input.addEventListener(
            "input",
            () => {
                const value = input.value.trim();
                setProfileFieldSource(
                    sourceKey,
                    value === "" ? null : "MANUALE"
                );
            }
        );
    }

}


// ==================================================
// NORMALIZZAZIONE RISPOSTA
// ==================================================

function extractProfiles(
    data
) {

    if (
        Array.isArray(
            data.profiles
        )
    ) {

        return data.profiles;

    }


    if (
        data.profiles
        &&
        typeof data.profiles === "object"
    ) {

        return Object.entries(
            data.profiles
        ).map(
            ([profileId, profile]) => ({

                profile_id:
                    profileId,

                ...profile

            })
        );

    }


    return [];

}



function getProfileId(
    profile
) {

    return (
        profile.profile_id
        ||
        profile.id
        ||
        profile.name
    );

}



function isProfileActive(
    profile,
    data
) {

    const activeId =
        data.active_profile_id
        ||
        data.active_profile
        ||
        null;


    return (
        profile.active === true
        ||
        (
            activeId !== null
            &&
            getProfileId(
                profile
            )
            ===
            activeId
        )
    );

}



// ==================================================
// ELENCO PROFILI
// ==================================================

async function loadPlants() {

    const message =
        document.getElementById(
            "plantsMessage"
        );


    message.textContent =
        "Caricamento profili...";


    try {

        const response =
            await fetch(
                "/api/plants"
            );


        const data =
            await response.json();


        if (
            !response.ok
            ||
            data.success === false
        ) {

            message.textContent =
                data.message
                ||
                "Errore durante il caricamento dei profili.";


            return;

        }


        const profiles =
            extractProfiles(
                data
            );


        renderPlants(
            profiles,
            data
        );


        message.textContent =
            (
                profiles.length === 0
                ?
                "Nessun profilo pianta presente."
                :
                `${profiles.length} profilo/i disponibile/i.`
            );

    }

    catch (error) {

        message.textContent =
            "Errore di comunicazione con il backend.";

    }

}



function renderPlants(
    profiles,
    responseData
) {

    const list =
        document.getElementById(
            "plantsList"
        );


    list.innerHTML =
        "";


    for (
        const profile
        of profiles
    ) {

        const profileId =
            getProfileId(
                profile
            );


        const active =
            isProfileActive(
                profile,
                responseData
            );


        const card =
            document.createElement(
                "div"
            );


        card.className =
            "plant-card";


        const title =
            document.createElement(
                "h3"
            );


        title.textContent =
            profile.name
            ||
            profileId;


        card.appendChild(
            title
        );


        const plant =
            document.createElement(
                "p"
            );


        plant.textContent =
            `Pianta: ${
                profile.plant_name
                ||
                "NON IDENTIFICATA"
            }`;


        card.appendChild(
            plant
        );


        if (
            profile.scientific_name
        ) {

            const scientific =
                document.createElement(
                    "p"
                );


            scientific.textContent =
                (
                    "Nome scientifico: "
                    +
                    profile.scientific_name
                );


            card.appendChild(
                scientific
            );

        }


        if (
            profile.location
        ) {

            const location =
                document.createElement(
                    "p"
                );


            location.textContent =
                (
                    "Posizione: "
                    +
                    profile.location
                );


            card.appendChild(
                location
            );

        }


        const source =
            document.createElement(
                "p"
            );


        source.textContent =
            (
                "Origine: "
                +
                (
                    profile.source
                    ||
                    "MANUALE"
                )
            );


        card.appendChild(
            source
        );


        const status =
            document.createElement(
                "p"
            );


        status.innerHTML =
            (
                active
                ?
                "<strong>PROFILO ATTIVO</strong>"
                :
                "Profilo non attivo"
            );


        card.appendChild(
            status
        );


        const actions =
            document.createElement(
                "div"
            );


        actions.className =
            "form-row";


        const editButton =
            document.createElement(
                "button"
            );


        editButton.textContent =
            "MODIFICA";


        editButton.onclick =
            () =>
                editPlantAndOpen(
                    profileId,
                    "profile"
                );


        actions.appendChild(
            editButton
        );


        if (
            !active
        ) {

            const activeButton =
                document.createElement(
                    "button"
                );


            activeButton.textContent =
                "IMPOSTA ATTIVA";


            activeButton.onclick =
                () =>
                    activatePlant(
                        profileId
                    );


            actions.appendChild(
                activeButton
            );

        }


        const aiButton =
            document.createElement(
                "button"
            );


        aiButton.textContent =
            "AI";


        aiButton.onclick =
            () =>
                editPlantAndOpen(
                    profileId,
                    "ai"
                );


        actions.appendChild(
            aiButton
        );


        const historyButton =
            document.createElement(
                "button"
            );


        historyButton.textContent =
            "STORICO AI";


        historyButton.onclick =
            () =>
                editPlantAndOpen(
                    profileId,
                    "history"
                );


        actions.appendChild(
            historyButton
        );


        const deleteButton =
            document.createElement(
                "button"
            );


        deleteButton.textContent =
            "ELIMINA";


        deleteButton.onclick =
            () =>
                deletePlant(
                    profileId
                );


        actions.appendChild(
            deleteButton
        );


        card.appendChild(
            actions
        );


        list.appendChild(
            card
        );

    }

}



// ==================================================
// RESET EDITOR
// ==================================================

function resetEditorFields() {

    document.getElementById(
        "profileId"
    ).value =
        "";


    document.getElementById(
        "profileName"
    ).value =
        "";


    document.getElementById(
        "plantName"
    ).value =
        "NON IDENTIFICATA";


    document.getElementById(
        "profileSource"
    ).value =
        "MANUALE";


    setNullableText(
        "scientificName",
        null
    );


    setNullableText(
        "plantDescription",
        null
    );


    setNullableText(
        "plantLocation",
        null
    );


    setNullableText(
        "plantExposure",
        null
    );


    setNullableText(
        "soilType",
        null
    );


    setNullableText(
        "plantNotes",
        null
    );


    resetProfileFieldSources();


    setNullableNumber(
        "minimumHumidity",
        null
    );


    setNullableNumber(
        "targetHumidity",
        null
    );


    setNullableNumber(
        "maximumHumidity",
        null
    );


    setNullableNumber(
        "averageWaterMl",
        null
    );


    setNullableNumber(
        "waterDoseMl",
        null
    );


    setNullableNumber(
        "wateringFrequencyDays",
        null
    );


    resetIrrigationSources();


    setNullableNumber(
        "minimumTemperature",
        null
    );


    setNullableNumber(
        "maximumTemperature",
        null
    );


    setNullableNumber(
        "minimumAirHumidity",
        null
    );


    setNullableNumber(
        "maximumAirHumidity",
        null
    );


    editingImages =
        [];


    renderPlantImages();


    resetPlantAI();


    loadPlantAIStatus();

}



// ==================================================
// NUOVO PROFILO
// ==================================================

function prepareNewPlant() {

    editingProfileId =
        null;


    resetEditorFields();


    document.getElementById(
        "plantEditorTitle"
    ).textContent =
        "Nuovo profilo pianta";


    const internalIdElement =
        document.getElementById(
            "plantEditorInternalId"
        );


    if (
        internalIdElement
    ) {

        internalIdElement.textContent =
            "L'ID interno verrà definito alla creazione del profilo.";

    }


    document.getElementById(
        "profileId"
    ).disabled =
        false;


    document.getElementById(
        "plantEditorMessage"
    ).textContent =
        "";


    document.getElementById(
        "plantImagesMessage"
    ).textContent =
        "Salvare prima il nuovo profilo per poter caricare immagini.";


    document.getElementById(
        "plantEditorSection"
    ).style.display =
        "block";


    requestedPlantTab =
        "profile";


    openPlantTab(
        "profile"
    );

}



// ==================================================
// MODIFICA PROFILO
// ==================================================

async function editPlant(
    profileId
) {

    const message =
        document.getElementById(
            "plantsMessage"
        );


    try {

        const response =
            await fetch(
                `/api/plants/${encodeURIComponent(profileId)}`
            );


        const data =
            await response.json();


        if (
            !response.ok
            ||
            data.success === false
        ) {

            message.textContent =
                data.message
                ||
                "Impossibile leggere il profilo.";


            return;

        }


        const profile =
            data.profile;


        editingProfileId =
            profileId;


        const displayProfileName =
            profile.name
            ||
            profileId;


        document.getElementById(
            "plantEditorTitle"
        ).textContent =
            `Modifica profilo: ${displayProfileName}`;


        const internalIdElement =
            document.getElementById(
                "plantEditorInternalId"
            );


        if (
            internalIdElement
        ) {

            internalIdElement.textContent =
                `ID interno: ${profileId}`;

        }


        const idInput =
            document.getElementById(
                "profileId"
            );


        idInput.value =
            profileId;


        idInput.disabled =
            true;


        document.getElementById(
            "profileName"
        ).value =
            profile.name
            ||
            profileId;


        document.getElementById(
            "plantName"
        ).value =
            profile.plant_name
            ||
            "NON IDENTIFICATA";


        document.getElementById(
            "profileSource"
        ).value =
            profile.source
            ||
            "MANUALE";


        setNullableText(
            "scientificName",
            profile.scientific_name
        );


        setNullableText(
            "plantDescription",
            profile.description
        );


        setNullableText(
            "plantLocation",
            profile.location
        );


        setNullableText(
            "plantExposure",
            profile.exposure
        );


        setNullableText(
            "soilType",
            profile.soil_type
        );


        setNullableText(
            "plantNotes",
            profile.notes
        );


        profileFieldSources.description_source =
            normalizeProfileFieldSource(
                profile.description_source
            );

        profileFieldSources.exposure_source =
            normalizeProfileFieldSource(
                profile.exposure_source
            );

        profileFieldSources.soil_type_source =
            normalizeProfileFieldSource(
                profile.soil_type_source
            );

        profileFieldSources.notes_source =
            normalizeProfileFieldSource(
                profile.notes_source
            );

        renderProfileFieldSources();


        setNullableNumber(
            "minimumHumidity",
            profile.minimum_humidity_percent
        );


        setNullableNumber(
            "targetHumidity",
            profile.target_humidity_percent
        );


        setNullableNumber(
            "maximumHumidity",
            profile.maximum_humidity_percent
        );


        setNullableNumber(
            "averageWaterMl",
            profile.average_water_ml
        );


        setNullableNumber(
            "waterDoseMl",
            profile.water_dose_ml
        );


        setNullableNumber(
            "wateringFrequencyDays",
            profile.watering_frequency_days
        );


        irrigationSources = {
            minimum_humidity_source: normalizeIrrigationSource(profile.minimum_humidity_source),
            target_humidity_source: normalizeIrrigationSource(profile.target_humidity_source),
            maximum_humidity_source: normalizeIrrigationSource(profile.maximum_humidity_source),
            average_water_source: normalizeIrrigationSource(profile.average_water_source),
            water_dose_source: normalizeIrrigationSource(profile.water_dose_source),
            watering_frequency_source: normalizeIrrigationSource(profile.watering_frequency_source)
        };

        renderIrrigationSources();


        setNullableNumber(
            "minimumTemperature",
            profile.minimum_temperature_c
        );


        setNullableNumber(
            "maximumTemperature",
            profile.maximum_temperature_c
        );


        setNullableNumber(
            "minimumAirHumidity",
            profile.minimum_air_humidity_percent
        );


        setNullableNumber(
            "maximumAirHumidity",
            profile.maximum_air_humidity_percent
        );


        editingImages =
            (
                Array.isArray(
                    profile.images
                )
                ?
                [...profile.images]
                :
                []
            );


        renderPlantImages();


        resetPlantAI();


        await loadPlantAIStatus();


        document.getElementById(
            "plantImagesMessage"
        ).textContent =
            "";


        document.getElementById(
            "plantEditorSection"
        ).style.display =
            "block";


        await loadPlantAIHistory();


        openPlantTab(
            requestedPlantTab
        );


        document.getElementById(
            "plantEditorMessage"
        ).textContent =
            "Profilo caricato correttamente.";

    }

    catch (error) {

        message.textContent =
            "Errore di comunicazione durante il caricamento.";

    }

}



// ==================================================
// GALLERIA IMMAGINI
// ==================================================

function renderPlantImages() {

    const gallery =
        document.getElementById(
            "plantImagesGallery"
        );


    gallery.innerHTML =
        "";


    updateAIImageSelector();


    if (
        editingImages.length === 0
    ) {

        const empty =
            document.createElement(
                "p"
            );


        empty.textContent =
            "Nessuna immagine associata.";


        gallery.appendChild(
            empty
        );


        return;

    }


    for (
        const imageUrl
        of editingImages
    ) {

        const container =
            document.createElement(
                "div"
            );


        container.style.width =
            "180px";


        const image =
            document.createElement(
                "img"
            );


        image.src =
            imageUrl;


        image.alt =
            "Foto della pianta";


        image.style.width =
            "180px";


        image.style.height =
            "135px";


        image.style.objectFit =
            "cover";


        image.style.borderRadius =
            "8px";


        container.appendChild(
            image
        );


        const deleteButton =
            document.createElement(
                "button"
            );


        deleteButton.type =
            "button";


        deleteButton.textContent =
            "ELIMINA FOTO";


        deleteButton.style.marginTop =
            "6px";


        deleteButton.onclick =
            () =>
                deletePlantImage(
                    imageUrl
                );


        container.appendChild(
            deleteButton
        );


        gallery.appendChild(
            container
        );

    }

}



// ==================================================
// UPLOAD IMMAGINE
// ==================================================

async function uploadPlantImage() {

    const message =
        document.getElementById(
            "plantImagesMessage"
        );


    if (
        editingProfileId === null
    ) {

        message.textContent =
            "Salvare prima il nuovo profilo.";


        return;

    }


    const fileInput =
        document.getElementById(
            "plantImageFile"
        );


    if (
        fileInput.files.length === 0
    ) {

        message.textContent =
            "Selezionare prima un'immagine.";


        return;

    }


    const file =
        fileInput.files[0];


    if (
        file.size
        >
        5 * 1024 * 1024
    ) {

        message.textContent =
            "L'immagine supera il limite di 5 MB.";


        return;

    }


    const formData =
        new FormData();


    formData.append(
        "image",
        file
    );


    message.textContent =
        "Caricamento immagine in corso...";


    try {

        const response =
            await fetch(
                `/api/plants/${encodeURIComponent(editingProfileId)}/images`,
                {

                    method:
                        "POST",

                    body:
                        formData

                }
            );


        const data =
            await response.json();


        if (
            !response.ok
            ||
            data.success === false
        ) {

            message.textContent =
                data.message
                ||
                "Errore durante il caricamento dell'immagine.";


            return;

        }


        editingImages =
            (
                Array.isArray(
                    data.profile.images
                )
                ?
                [...data.profile.images]
                :
                []
            );


        renderPlantImages();


        fileInput.value =
            "";


        message.textContent =
            "Immagine caricata correttamente.";

    }

    catch (error) {

        message.textContent =
            "Errore di comunicazione durante l'upload.";

    }

}



// ==================================================
// ELIMINAZIONE IMMAGINE
// ==================================================

async function deletePlantImage(
    imageUrl
) {

    if (
        editingProfileId === null
    ) {

        return;

    }


    if (
        !window.confirm(
            "Eliminare questa immagine?"
        )
    ) {

        return;

    }


    const message =
        document.getElementById(
            "plantImagesMessage"
        );


    const url =
        (
            `/api/plants/`
            +
            `${encodeURIComponent(editingProfileId)}`
            +
            `/images?image_url=`
            +
            encodeURIComponent(
                imageUrl
            )
        );


    try {

        const response =
            await fetch(
                url,
                {
                    method:
                        "DELETE"
                }
            );


        const data =
            await response.json();


        if (
            !response.ok
            ||
            data.success === false
        ) {

            message.textContent =
                data.message
                ||
                "Errore durante l'eliminazione dell'immagine.";


            return;

        }


        editingImages =
            (
                Array.isArray(
                    data.profile.images
                )
                ?
                [...data.profile.images]
                :
                []
            );


        renderPlantImages();


        message.textContent =
            "Immagine eliminata correttamente.";

    }

    catch (error) {

        message.textContent =
            "Errore di comunicazione durante l'eliminazione.";

    }

}



// ==================================================
// SUPPORTO ANALISI AI
// ==================================================

function aiDisplayValue(
    value,
    suffix = ""
) {

    if (
        value === null
        ||
        value === undefined
        ||
        value === ""
    ) {

        return "-";

    }


    return (
        String(value)
        +
        suffix
    );

}



function aiDisplayList(
    values
) {

    if (
        !Array.isArray(values)
        ||
        values.length === 0
    ) {

        return "-";

    }


    return values.join(
        " • "
    );

}


function formatFoodBeverageReference(item) {

    if (!item) {
        return null;
    }

    if (typeof item === "string") {
        return item;
    }

    const locationParts = [
        item.region,
        item.province_or_city
    ].filter(Boolean);

    let text = item.name || "";

    if (locationParts.length > 0) {
        text += ` — ${locationParts.join(" / ")}`;
    }

    if (item.notes) {
        text += ` (${item.notes})`;
    }

    return text || null;

}


function aiDisplayFoodReferences(values) {

    if (!Array.isArray(values) || values.length === 0) {
        return "-";
    }

    const formatted = values
        .map(formatFoodBeverageReference)
        .filter(Boolean);

    return formatted.length > 0
        ? formatted.join(" • ")
        : "-";

}


function resetPlantAI() {

    currentPlantAIResult =
        null;


    const result =
        document.getElementById(
            "plantAIResult"
        );


    if (
        result
    ) {

        result.style.display =
            "none";

    }


    const applyButton =
        document.getElementById(
            "btnApplyAISuggestions"
        );


    if (
        applyButton
    ) {

        applyButton.disabled =
            true;

    }


    const message =
        document.getElementById(
            "plantAIMessage"
        );


    if (
        message
    ) {

        message.textContent =
            "";

    }

}



function updateAIImageSelector() {

    const select =
        document.getElementById(
            "aiImageIndex"
        );


    if (
        !select
    ) {

        return;

    }


    select.innerHTML =
        "";


    if (
        editingImages.length === 0
    ) {

        const option =
            document.createElement(
                "option"
            );


        option.value =
            "";


        option.textContent =
            "Nessuna immagine disponibile";


        select.appendChild(
            option
        );


        return;

    }


    editingImages.forEach(
        (
            imageUrl,
            index
        ) => {

            const option =
                document.createElement(
                    "option"
                );


            option.value =
                String(index);


            option.textContent =
                `Foto ${index + 1}`;


            select.appendChild(
                option
            );

        }
    );

}



async function loadPlantAIStatus() {

    const provider =
        document.getElementById(
            "aiProvider"
        );


    const model =
        document.getElementById(
            "aiModel"
        );


    const configured =
        document.getElementById(
            "aiConfigured"
        );


    if (
        !provider
        ||
        !model
        ||
        !configured
    ) {

        return;

    }


    try {

        const response =
            await fetch(
                "/api/plant-ai/status"
            );


        const data =
            await response.json();


        provider.textContent =
            data.provider
            ||
            "-";


        model.textContent =
            data.model
            ||
            "-";


        plantAIConfigured =
            (
                response.ok
                &&
                data.success !== false
                &&
                data.configured === true
            );


        configured.textContent =
            (
                plantAIConfigured
                ?
                "CONFIGURATA"
                :
                "NON CONFIGURATA"
            );

    }

    catch (error) {

        plantAIConfigured =
            false;


        configured.textContent =
            "NON DISPONIBILE";

    }

}



function renderPlantAIResult(
    data
) {

    const analysis =
        data.analysis
        ||
        {};


    currentPlantAIResult =
        data;


    document.getElementById(
        "aiCommonName"
    ).textContent =
        aiDisplayValue(
            analysis.probable_common_name
        );


    document.getElementById(
        "aiScientificName"
    ).textContent =
        aiDisplayValue(
            analysis.probable_scientific_name
        );


    document.getElementById(
        "aiConfidence"
    ).textContent =
        aiDisplayValue(
            analysis.identification_confidence_percent,
            " %"
        );


    document.getElementById(
        "aiVisualHealth"
    ).textContent =
        aiDisplayValue(
            analysis.visual_health
        );


    document.getElementById(
        "aiSymptoms"
    ).textContent =
        aiDisplayList(
            analysis.visible_symptoms
        );


    document.getElementById(
        "aiWarnings"
    ).textContent =
        aiDisplayList(
            analysis.warnings
        );


    document.getElementById(
        "aiSuggestedExposure"
    ).textContent =
        aiDisplayValue(
            analysis.suggested_exposure
        );


    document.getElementById(
        "aiSuggestedSoilType"
    ).textContent =
        aiDisplayValue(
            analysis.suggested_soil_type
        );


    document.getElementById(
        "aiSuggestedDescription"
    ).textContent =
        aiDisplayValue(
            analysis.suggested_description
        );


    document.getElementById(
        "aiSuggestedNotes"
    ).textContent =
        aiDisplayValue(
            analysis.suggested_notes
        );


    document.getElementById(
        "aiMinimumHumidity"
    ).textContent =
        aiDisplayValue(
            analysis.suggested_minimum_humidity_percent,
            " %"
        );


    document.getElementById(
        "aiTargetHumidity"
    ).textContent =
        aiDisplayValue(
            analysis.suggested_target_humidity_percent,
            " %"
        );


    document.getElementById(
        "aiMaximumHumidity"
    ).textContent =
        aiDisplayValue(
            analysis.suggested_maximum_humidity_percent,
            " %"
        );


    document.getElementById(
        "aiWaterDose"
    ).textContent =
        aiDisplayValue(
            analysis.suggested_water_dose_ml,
            " ml"
        );


    document.getElementById(
        "aiWateringFrequency"
    ).textContent =
        aiDisplayValue(
            analysis.suggested_watering_frequency_days,
            " giorni"
        );


    document.getElementById(
        "aiIrrigationNotes"
    ).textContent =
        aiDisplayValue(
            analysis.irrigation_notes
        );


    document.getElementById(
        "aiMinimumTemperature"
    ).textContent =
        aiDisplayValue(
            analysis.suggested_temperature_min_c,
            " °C"
        );


    document.getElementById(
        "aiMaximumTemperature"
    ).textContent =
        aiDisplayValue(
            analysis.suggested_temperature_max_c,
            " °C"
        );


    document.getElementById(
        "aiMinimumAirHumidity"
    ).textContent =
        aiDisplayValue(
            analysis.suggested_air_humidity_min_percent,
            " %"
        );


    document.getElementById(
        "aiMaximumAirHumidity"
    ).textContent =
        aiDisplayValue(
            analysis.suggested_air_humidity_max_percent,
            " %"
        );


    document.getElementById(
        "aiFoodBeverageRelevant"
    ).textContent =
        analysis.food_beverage_relevant === true
        ? "SÌ"
        : "NO / NON DETERMINATO";


    document.getElementById(
        "aiCulinaryParts"
    ).textContent =
        aiDisplayList(
            analysis.culinary_parts_used
        );


    document.getElementById(
        "aiTypicalDishes"
    ).textContent =
        aiDisplayFoodReferences(
            analysis.typical_dishes
        );


    document.getElementById(
        "aiCocktailsBeverages"
    ).textContent =
        aiDisplayFoodReferences(
            analysis.cocktails_and_beverages
        );


    document.getElementById(
        "aiCulinaryNotes"
    ).textContent =
        aiDisplayValue(
            analysis.culinary_context_notes
        );


    document.getElementById(
        "aiFoodSafetyWarning"
    ).textContent =
        aiDisplayValue(
            analysis.food_safety_warning
        );


    document.getElementById(
        "aiReasoningSummary"
    ).textContent =
        aiDisplayValue(
            analysis.reasoning_summary
        );


    const usage =
        data.usage
        ||
        {};


    document.getElementById(
        "aiTotalTokens"
    ).textContent =
        aiDisplayValue(
            usage.total_tokens
        );


    const cost =
        data.cost
        ||
        {};


    const totalCost =
        cost.total_cost_usd;


    document.getElementById(
        "aiTotalCost"
    ).textContent =
        (
            totalCost === null
            ||
            totalCost === undefined
        )
        ?
        "-"
        :
        `${Number(totalCost).toFixed(6)} USD`;


    document.getElementById(
        "plantAIResult"
    ).style.display =
        "block";


    document.getElementById(
        "btnApplyAISuggestions"
    ).disabled =
        false;

}



async function analyzePlantWithAI() {

    const message =
        document.getElementById(
            "plantAIMessage"
        );


    if (
        editingProfileId === null
    ) {

        message.textContent =
            "Salvare prima il profilo della pianta.";


        return;

    }


    if (
        editingImages.length === 0
    ) {

        message.textContent =
            "Associare almeno una fotografia al profilo.";


        return;

    }


    await loadPlantAIStatus();


    if (
        !plantAIConfigured
    ) {

        message.textContent =
            (
                "Provider AI non configurato. "
                +
                "Verificare OPENAI_API_KEY e riavviare H2O Piante."
            );


        return;

    }


    const select =
        document.getElementById(
            "aiImageIndex"
        );


    const imageIndex =
        Number(
            select.value
        );


    if (
        !Number.isInteger(imageIndex)
        ||
        imageIndex < 0
    ) {

        message.textContent =
            "Selezionare una fotografia valida.";


        return;

    }


    message.textContent =
        "Analisi AI in corso...";


    document.getElementById(
        "btnAnalyzePlantAI"
    ).disabled =
        true;


    resetPlantAI();


    message.textContent =
        "Analisi AI in corso...";


    try {

        const response =
            await fetch(
                (
                    `/api/plant-ai/analyze/`
                    +
                    `${encodeURIComponent(editingProfileId)}`
                    +
                    `?image_index=${imageIndex}`
                ),
                {
                    method:
                        "POST"
                }
            );


        const data =
            await response.json();


        if (
            !response.ok
            ||
            data.success === false
        ) {

            message.textContent =
                data.message
                ||
                "Analisi AI non riuscita.";


            return;

        }


        renderPlantAIResult(
            data
        );


        message.textContent =
            (
                "Analisi AI completata. "
                +
                "I risultati sono proposte e non hanno ancora modificato il profilo."
            );


        await loadPlantAIHistory();

    }

    catch (error) {

        message.textContent =
            "Errore di comunicazione durante l'analisi AI.";

    }

    finally {

        document.getElementById(
            "btnAnalyzePlantAI"
        ).disabled =
            false;

    }

}



function highlightAppliedProfileFields(elementIds) {

    for (const elementId of elementIds) {

        const element = document.getElementById(elementId);

        if (!element) {
            continue;
        }

        element.classList.remove("ai-applied-field");

        // Forza il riavvio dell'animazione/evidenziazione.
        void element.offsetWidth;

        element.classList.add("ai-applied-field");

        window.setTimeout(
            () => {
                element.classList.remove("ai-applied-field");
            },
            4500
        );
    }

}




function applyAISuggestions() {

    if (
        currentPlantAIResult === null
        ||
        !currentPlantAIResult.analysis
    ) {
        return;
    }

    const analysis = currentPlantAIResult.analysis;

    const appliedProfileFields = [];
    const appliedIrrigationFields = [];
    const appliedMicroclimateFields = [];

    if (analysis.probable_common_name) {
        document.getElementById("plantName").value = analysis.probable_common_name;
        appliedProfileFields.push("plantName");
    }

    if (analysis.probable_scientific_name) {
        document.getElementById("scientificName").value = analysis.probable_scientific_name;
        appliedProfileFields.push("scientificName");
    }

    const aiProfileTextValues = [
        ["plantExposure", "exposure_source", analysis.suggested_exposure],
        ["soilType", "soil_type_source", analysis.suggested_soil_type],
        ["plantDescription", "description_source", analysis.suggested_description],
        ["plantNotes", "notes_source", analysis.suggested_notes]
    ];

    for (const [elementId, sourceKey, value] of aiProfileTextValues) {
        if (
            value !== null
            &&
            value !== undefined
            &&
            String(value).trim() !== ""
        ) {
            setNullableText(elementId, value);
            setProfileFieldSource(sourceKey, "AI");
            appliedProfileFields.push(elementId);
        }
    }

    const aiIrrigationValues = [
        ["minimumHumidity", "minimum_humidity_source", analysis.suggested_minimum_humidity_percent],
        ["targetHumidity", "target_humidity_source", analysis.suggested_target_humidity_percent],
        ["maximumHumidity", "maximum_humidity_source", analysis.suggested_maximum_humidity_percent],
        ["waterDoseMl", "water_dose_source", analysis.suggested_water_dose_ml],
        ["wateringFrequencyDays", "watering_frequency_source", analysis.suggested_watering_frequency_days]
    ];

    for (const [elementId, sourceKey, value] of aiIrrigationValues) {
        if (value !== null && value !== undefined) {
            setNullableNumber(elementId, value);
            setIrrigationSource(sourceKey, "AI");
            appliedIrrigationFields.push(elementId);
        }
    }

    const aiMicroclimateValues = [
        ["minimumTemperature", analysis.suggested_temperature_min_c],
        ["maximumTemperature", analysis.suggested_temperature_max_c],
        ["minimumAirHumidity", analysis.suggested_air_humidity_min_percent],
        ["maximumAirHumidity", analysis.suggested_air_humidity_max_percent]
    ];

    for (const [elementId, value] of aiMicroclimateValues) {
        if (value !== null && value !== undefined) {
            setNullableNumber(elementId, value);
            appliedMicroclimateFields.push(elementId);
        }
    }

    document.getElementById("profileSource").value = "AI_FOTO";

    const totalApplied =
        appliedProfileFields.length
        + appliedIrrigationFields.length
        + appliedMicroclimateFields.length;

    const message = document.getElementById("plantAIMessage");

    if (totalApplied === 0) {
        message.textContent =
            "L'AI non ha restituito valori applicabili al profilo. Nessun campo è stato modificato.";
    } else {
        message.textContent =
            `${totalApplied} suggerimenti AI copiati nei campi del profilo. Il profilo NON è ancora salvato.`;
    }

    const editorMessage = document.getElementById("plantEditorMessage");

    if (editorMessage) {
        editorMessage.textContent =
            "Suggerimenti AI applicati localmente: controllare i valori e premere SALVA PROFILO per renderli ufficiali.";
    }

    highlightAppliedProfileFields(
        [
            ...appliedProfileFields,
            ...appliedIrrigationFields,
            ...appliedMicroclimateFields
        ]
    );

    // Se l'AI ha proposto valori di irrigazione, porta subito l'utente
    // nella scheda corretta: è il passaggio che prima risultava poco intuitivo.
    if (appliedIrrigationFields.length > 0) {

        openPlantTab("irrigation");

        const irrigationMessage =
            document.getElementById("irrigationApplyMessage");

        if (irrigationMessage) {

            const count = appliedIrrigationFields.length;

            irrigationMessage.textContent =
                `${count} ${count === 1 ? "valore di irrigazione copiato" : "valori di irrigazione copiati"} dall'AI. `
                + "I campi aggiornati sono evidenziati e riportano Fonte: AI. "
                + "Controllali e premi SALVA PROFILO per renderli definitivi.";
        }

        const irrigationPanel =
            document.getElementById("plantTab-irrigation");

        if (irrigationPanel) {
            irrigationPanel.scrollIntoView({
                behavior: "smooth",
                block: "start"
            });
        }
    }

}



// ==================================================
// COSTRUZIONE PAYLOAD
// ==================================================

function buildPlantPayload() {

    return {

        name:
            document
            .getElementById(
                "profileName"
            )
            .value
            .trim(),

        plant_name:
            document
            .getElementById(
                "plantName"
            )
            .value
            .trim(),

        scientific_name:
            nullableText(
                "scientificName"
            ),

        description:
            nullableText(
                "plantDescription"
            ),

        location:
            nullableText(
                "plantLocation"
            ),

        exposure:
            nullableText(
                "plantExposure"
            ),

        soil_type:
            nullableText(
                "soilType"
            ),

        notes:
            nullableText(
                "plantNotes"
            ),

        description_source:
            profileFieldSources.description_source,

        exposure_source:
            profileFieldSources.exposure_source,

        soil_type_source:
            profileFieldSources.soil_type_source,

        notes_source:
            profileFieldSources.notes_source,

        images:
            [...editingImages],

        minimum_humidity_percent:
            nullableNumber(
                "minimumHumidity"
            ),

        target_humidity_percent:
            nullableNumber(
                "targetHumidity"
            ),

        maximum_humidity_percent:
            nullableNumber(
                "maximumHumidity"
            ),

        average_water_ml:
            nullableNumber(
                "averageWaterMl"
            ),

        water_dose_ml:
            nullableNumber(
                "waterDoseMl"
            ),

        watering_frequency_days:
            nullableNumber(
                "wateringFrequencyDays"
            ),

        minimum_humidity_source:
            irrigationSources.minimum_humidity_source,

        target_humidity_source:
            irrigationSources.target_humidity_source,

        maximum_humidity_source:
            irrigationSources.maximum_humidity_source,

        average_water_source:
            irrigationSources.average_water_source,

        water_dose_source:
            irrigationSources.water_dose_source,

        watering_frequency_source:
            irrigationSources.watering_frequency_source,

        minimum_temperature_c:
            nullableNumber(
                "minimumTemperature"
            ),

        maximum_temperature_c:
            nullableNumber(
                "maximumTemperature"
            ),

        minimum_air_humidity_percent:
            nullableNumber(
                "minimumAirHumidity"
            ),

        maximum_air_humidity_percent:
            nullableNumber(
                "maximumAirHumidity"
            ),

        source:
            document
            .getElementById(
                "profileSource"
            )
            .value

    };

}



// ==================================================
// VALIDAZIONE
// ==================================================

function validatePlantPayload(
    payload
) {

    if (
        payload.minimum_humidity_percent !== null
        &&
        payload.target_humidity_percent !== null
        &&
        payload.minimum_humidity_percent
        >
        payload.target_humidity_percent
    ) {

        return (
            "L'umidità minima del terreno "
            +
            "non può superare l'obiettivo."
        );

    }


    if (
        payload.target_humidity_percent !== null
        &&
        payload.maximum_humidity_percent !== null
        &&
        payload.target_humidity_percent
        >
        payload.maximum_humidity_percent
    ) {

        return (
            "L'umidità obiettivo del terreno "
            +
            "non può superare la massima."
        );

    }


    if (
        payload.minimum_temperature_c !== null
        &&
        payload.maximum_temperature_c !== null
        &&
        payload.minimum_temperature_c
        >
        payload.maximum_temperature_c
    ) {

        return (
            "La temperatura minima "
            +
            "non può superare la massima."
        );

    }


    if (
        payload.minimum_air_humidity_percent !== null
        &&
        payload.maximum_air_humidity_percent !== null
        &&
        payload.minimum_air_humidity_percent
        >
        payload.maximum_air_humidity_percent
    ) {

        return (
            "L'umidità ambiente minima "
            +
            "non può superare la massima."
        );

    }


    return null;

}



// ==================================================
// SALVATAGGIO
// ==================================================

async function savePlant() {

    const profileId =
        document
        .getElementById(
            "profileId"
        )
        .value
        .trim();


    const payload =
        buildPlantPayload();


    const message =
        document.getElementById(
            "plantEditorMessage"
        );


    if (
        profileId === ""
    ) {

        message.textContent =
            "ID profilo obbligatorio.";


        return;

    }


    if (
        payload.name === ""
        ||
        payload.plant_name === ""
    ) {

        message.textContent =
            "Nome profilo e pianta sono obbligatori.";


        return;

    }


    const validationError =
        validatePlantPayload(
            payload
        );


    if (
        validationError !== null
    ) {

        message.textContent =
            validationError;


        return;

    }


    const creating =
        editingProfileId === null;


    const url =
        (
            creating
            ?
            "/api/plants"
            :
            `/api/plants/${encodeURIComponent(editingProfileId)}`
        );


    const requestPayload = {

        profile_id:
            (
                creating
                ?
                profileId
                :
                editingProfileId
            ),

        ...payload

    };


    try {

        const response =
            await fetch(
                url,
                {

                    method:
                        (
                            creating
                            ?
                            "POST"
                            :
                            "PUT"
                        ),

                    headers: {

                        "Content-Type":
                            "application/json"

                    },

                    body:
                        JSON.stringify(
                            requestPayload
                        )

                }
            );


        const data =
            await response.json();


        if (
            !response.ok
            ||
            data.success === false
        ) {

            message.textContent =
                data.message
                ||
                "Errore durante il salvataggio del profilo.";


            return;

        }


        message.textContent =
            "Profilo salvato correttamente.";


        await loadPlants();


        setTimeout(
            cancelPlantEdit,
            500
        );

    }

    catch (error) {

        message.textContent =
            "Errore di comunicazione con il backend.";

    }

}



// ==================================================
// ATTIVAZIONE
// ==================================================

async function activatePlant(
    profileId
) {

    const message =
        document.getElementById(
            "plantsMessage"
        );


    try {

        const response =
            await fetch(
                `/api/plants/${encodeURIComponent(profileId)}/activate`,
                {
                    method:
                        "PUT"
                }
            );


        const data =
            await response.json();


        if (
            !response.ok
            ||
            data.success === false
        ) {

            message.textContent =
                data.message
                ||
                "Impossibile attivare il profilo.";


            return;

        }


        message.textContent =
            `Profilo ${profileId} impostato come attivo.`;


        await loadPlants();

    }

    catch (error) {

        message.textContent =
            "Errore durante l'attivazione del profilo.";

    }

}



// ==================================================
// ELIMINAZIONE PROFILO
// ==================================================

async function deletePlant(
    profileId
) {

    if (
        !window.confirm(
            `Eliminare il profilo ${profileId}?`
        )
    ) {

        return;

    }


    const message =
        document.getElementById(
            "plantsMessage"
        );


    try {

        const response =
            await fetch(
                `/api/plants/${encodeURIComponent(profileId)}`,
                {
                    method:
                        "DELETE"
                }
            );


        const data =
            await response.json();


        if (
            !response.ok
            ||
            data.success === false
        ) {

            message.textContent =
                data.message
                ||
                "Impossibile eliminare il profilo.";


            return;

        }


        message.textContent =
            `Profilo ${profileId} eliminato.`;


        await loadPlants();

    }

    catch (error) {

        message.textContent =
            "Errore durante l'eliminazione del profilo.";

    }

}




// ==================================================
// NAVIGAZIONE INTERNA PROFILO
// ==================================================

function openPlantTab(
    tabName
) {

    const validTabs = [
        "profile",
        "irrigation",
        "microclimate",
        "images",
        "ai",
        "history"
    ];


    const selectedTab =
        validTabs.includes(tabName)
        ? tabName
        : "profile";


    requestedPlantTab =
        selectedTab;


    document
        .querySelectorAll(
            ".plant-tab"
        )
        .forEach(
            button => {
                button.classList.toggle(
                    "active",
                    button.dataset.tab === selectedTab
                );
            }
        );


    document
        .querySelectorAll(
            ".plant-tab-panel"
        )
        .forEach(
            panel => {
                panel.classList.toggle(
                    "active",
                    panel.id === `plantTab-${selectedTab}`
                );
            }
        );


    if (
        selectedTab === "history"
        &&
        editingProfileId !== null
    ) {
        loadPlantAIHistory();
    }


    document.getElementById(
        "plantEditorSection"
    )?.scrollIntoView({
        behavior: "smooth",
        block: "start"
    });

}


async function editPlantAndOpen(
    profileId,
    tabName
) {

    requestedPlantTab =
        tabName;


    await editPlant(
        profileId
    );

}


function formatAIHistoryDate(
    isoTimestamp
) {

    if (!isoTimestamp) {
        return "-";
    }


    const date =
        new Date(isoTimestamp);


    if (
        Number.isNaN(
            date.getTime()
        )
    ) {
        return isoTimestamp;
    }


    return date.toLocaleString(
        "it-IT"
    );

}


function escapeHTML(
    value
) {

    return String(
        value ?? ""
    )
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");

}


function historyValue(
    value,
    suffix = ""
) {

    if (
        value === null
        ||
        value === undefined
        ||
        value === ""
    ) {
        return "-";
    }


    return `${escapeHTML(value)}${suffix}`;

}


async function loadPlantAIHistory() {

    const message =
        document.getElementById(
            "plantAIHistoryMessage"
        );


    const list =
        document.getElementById(
            "plantAIHistoryList"
        );


    const detail =
        document.getElementById(
            "plantAIHistoryDetail"
        );


    if (
        !message
        ||
        !list
    ) {
        return;
    }


    if (
        editingProfileId === null
    ) {
        message.textContent =
            "Selezionare prima un profilo pianta.";

        list.innerHTML = "";

        if (detail) {
            detail.style.display = "none";
        }

        return;
    }


    message.textContent =
        "Caricamento storico AI...";


    try {

        const response =
            await fetch(
                `/api/plant-ai/history/${encodeURIComponent(editingProfileId)}`
            );


        const data =
            await response.json();


        if (
            !response.ok
            ||
            data.success === false
        ) {
            message.textContent =
                data.message
                ||
                "Impossibile caricare lo storico AI.";

            return;
        }


        const entries =
            Array.isArray(data.entries)
            ? data.entries
            : [];


        renderPlantAIHistory(
            entries
        );


        message.textContent =
            entries.length === 0
            ? "Nessuna analisi AI archiviata per questo profilo."
            : `${entries.length} analisi AI archiviate.`;

    }
    catch (error) {

        message.textContent =
            "Errore di comunicazione durante il caricamento dello storico AI.";

    }

}


function renderPlantAIHistory(
    entries
) {

    const list =
        document.getElementById(
            "plantAIHistoryList"
        );


    const detail =
        document.getElementById(
            "plantAIHistoryDetail"
        );


    list.innerHTML = "";


    if (detail) {
        detail.style.display = "none";
        detail.innerHTML = "";
    }


    for (const entry of entries) {

        const analysis =
            entry.analysis
            ||
            {};


        const card =
            document.createElement(
                "article"
            );


        card.className =
            "ai-history-card";


        const confidence =
            analysis.identification_confidence_percent;


        const totalCost =
            entry.cost?.total_cost_usd;


        card.innerHTML = `
            <div class="ai-history-card-main">
                <div>
                    <strong>${historyValue(analysis.probable_common_name || "Analisi AI")}</strong>
                    <div class="muted">${historyValue(analysis.probable_scientific_name)}</div>
                </div>
                <div class="ai-history-meta">
                    <span>${escapeHTML(formatAIHistoryDate(entry.timestamp))}</span>
                    <span>Confidenza: ${historyValue(confidence, "%")}</span>
                    <span>${historyValue(entry.provider)} / ${historyValue(entry.model)}</span>
                    <span>Costo: ${totalCost === null || totalCost === undefined ? "-" : Number(totalCost).toFixed(6) + " USD"}</span>
                </div>
            </div>
            <div class="form-row compact-actions">
                <button type="button" data-action="view">VISUALIZZA</button>
                <button type="button" data-action="apply">APPLICA AL PROFILO</button>
                <button type="button" class="danger-button" data-action="delete">ELIMINA</button>
            </div>
        `;


        card.querySelector(
            '[data-action="view"]'
        ).onclick =
            () =>
                showPlantAIHistoryDetail(
                    entry
                );


        card.querySelector(
            '[data-action="apply"]'
        ).onclick =
            () =>
                applyHistoryEntryToProfile(
                    entry
                );


        card.querySelector(
            '[data-action="delete"]'
        ).onclick =
            () =>
                deletePlantAIHistoryEntry(
                    entry.analysis_id
                );


        list.appendChild(
            card
        );

    }

}


function showPlantAIHistoryDetail(
    entry
) {

    const detail = document.getElementById("plantAIHistoryDetail");

    if (!detail) {
        return;
    }

    const analysis = entry.analysis || {};

    const symptoms = Array.isArray(analysis.visible_symptoms)
        ? analysis.visible_symptoms.join(" • ")
        : "-";

    const warnings = Array.isArray(analysis.warnings)
        ? analysis.warnings.join(" • ")
        : "-";

    const culinaryParts = aiDisplayList(analysis.culinary_parts_used);
    const typicalDishes = aiDisplayFoodReferences(analysis.typical_dishes);
    const cocktails = aiDisplayFoodReferences(analysis.cocktails_and_beverages);

    const imageBlock = entry.image_url
        ? `<div class="ai-history-image-wrap"><img class="ai-history-image" src="${escapeHTML(entry.image_url)}" alt="Foto analizzata"></div>`
        : "";

    detail.innerHTML = `
        <div class="section-title-row">
            <div>
                <h4>Dettaglio analisi AI</h4>
                <p class="muted">${escapeHTML(formatAIHistoryDate(entry.timestamp))} · ${historyValue(entry.provider)} / ${historyValue(entry.model)}</p>
            </div>
            <button type="button" class="secondary-button" onclick="closePlantAIHistoryDetail()">CHIUDI</button>
        </div>

        ${imageBlock}

        <div class="ai-summary-strip">
            <div><span>Nome comune</span><strong>${historyValue(analysis.probable_common_name)}</strong></div>
            <div><span>Nome scientifico</span><strong>${historyValue(analysis.probable_scientific_name)}</strong></div>
            <div><span>Confidenza</span><strong>${historyValue(analysis.identification_confidence_percent, "%")}</strong></div>
            <div><span>Token</span><strong>${historyValue(entry.usage?.total_tokens)}</strong></div>
            <div><span>Costo</span><strong>${entry.cost?.total_cost_usd === null || entry.cost?.total_cost_usd === undefined ? "-" : Number(entry.cost.total_cost_usd).toFixed(6) + " USD"}</strong></div>
        </div>

        <details class="ai-accordion" open>
            <summary>Stato visivo</summary>
            <div class="info-grid">
                <div class="info-card"><span class="info-label">Valutazione generale</span><div>${historyValue(analysis.visual_health)}</div></div>
                <div class="info-card"><span class="info-label">Sintomi visibili</span><div>${escapeHTML(symptoms)}</div></div>
                <div class="info-card"><span class="info-label">Avvertenze</span><div>${escapeHTML(warnings)}</div></div>
            </div>
        </details>

        <details class="ai-accordion">
            <summary>Profilo suggerito</summary>
            <div class="info-grid">
                <div class="info-card"><span class="info-label">Esposizione ideale</span><div>${historyValue(analysis.suggested_exposure)}</div></div>
                <div class="info-card"><span class="info-label">Tipo di terreno consigliato</span><div>${historyValue(analysis.suggested_soil_type)}</div></div>
            </div>
            <div class="info-grid two-columns">
                <div class="info-card"><span class="info-label">Descrizione botanica</span><div>${historyValue(analysis.suggested_description)}</div></div>
                <div class="info-card"><span class="info-label">Note pratiche</span><div>${historyValue(analysis.suggested_notes)}</div></div>
            </div>
        </details>

        <details class="ai-accordion">
            <summary>Irrigazione</summary>
            <div class="info-grid">
                <div class="info-card"><span class="info-label">Umidità minima</span><strong>${historyValue(analysis.suggested_minimum_humidity_percent, "%")}</strong></div>
                <div class="info-card"><span class="info-label">Umidità obiettivo</span><strong>${historyValue(analysis.suggested_target_humidity_percent, "%")}</strong></div>
                <div class="info-card"><span class="info-label">Umidità massima</span><strong>${historyValue(analysis.suggested_maximum_humidity_percent, "%")}</strong></div>
                <div class="info-card"><span class="info-label">Dose acqua</span><strong>${historyValue(analysis.suggested_water_dose_ml, " ml")}</strong></div>
                <div class="info-card"><span class="info-label">Frequenza</span><strong>${historyValue(analysis.suggested_watering_frequency_days, " giorni")}</strong></div>
            </div>
            <div class="info-card"><span class="info-label">Note irrigazione</span><div>${historyValue(analysis.irrigation_notes)}</div></div>
        </details>

        <details class="ai-accordion">
            <summary>Microclima</summary>
            <div class="info-grid">
                <div class="info-card"><span class="info-label">Temperatura minima</span><strong>${historyValue(analysis.suggested_temperature_min_c, " °C")}</strong></div>
                <div class="info-card"><span class="info-label">Temperatura massima</span><strong>${historyValue(analysis.suggested_temperature_max_c, " °C")}</strong></div>
                <div class="info-card"><span class="info-label">Umidità aria minima</span><strong>${historyValue(analysis.suggested_air_humidity_min_percent, "%")}</strong></div>
                <div class="info-card"><span class="info-label">Umidità aria massima</span><strong>${historyValue(analysis.suggested_air_humidity_max_percent, "%")}</strong></div>
            </div>
        </details>

        <details class="ai-accordion">
            <summary>Food &amp; Beverage</summary>
            <div class="info-grid">
                <div class="info-card"><span class="info-label">Rilevanza gastronomica</span><strong>${analysis.food_beverage_relevant === true ? "SÌ" : "NO / NON DETERMINATO"}</strong></div>
                <div class="info-card"><span class="info-label">Parti utilizzate</span><div>${escapeHTML(culinaryParts)}</div></div>
                <div class="info-card"><span class="info-label">Piatti tipici</span><div>${escapeHTML(typicalDishes)}</div></div>
                <div class="info-card"><span class="info-label">Cocktail e bevande</span><div>${escapeHTML(cocktails)}</div></div>
            </div>
            <div class="info-card"><span class="info-label">Contesto gastronomico</span><div>${historyValue(analysis.culinary_context_notes)}</div></div>
            <div class="info-card warning-card"><span class="info-label">Avvertenza alimentare</span><div>${historyValue(analysis.food_safety_warning)}</div></div>
        </details>

        <details class="ai-accordion">
            <summary>Sintesi AI</summary>
            <div class="info-card"><span class="info-label">Sintesi</span><div>${historyValue(analysis.reasoning_summary)}</div></div>
        </details>
    `;

    detail.style.display = "block";

    detail.scrollIntoView({
        behavior: "smooth",
        block: "start"
    });

}


function closePlantAIHistoryDetail() {

    const detail =
        document.getElementById(
            "plantAIHistoryDetail"
        );


    if (detail) {
        detail.style.display = "none";
    }

}


function applyHistoryEntryToProfile(
    entry
) {

    currentPlantAIResult = {
        success: true,
        analysis: entry.analysis,
        usage: entry.usage,
        cost: entry.cost
    };


    applyAISuggestions();


    document.getElementById(
        "plantEditorMessage"
    ).textContent =
        "Suggerimenti dello storico AI applicati ai campi. Verificare e premere SALVA PROFILO.";


    openPlantTab(
        "profile"
    );

}


async function deletePlantAIHistoryEntry(
    analysisId
) {

    if (
        editingProfileId === null
        ||
        !analysisId
    ) {
        return;
    }


    if (
        !window.confirm(
            "Eliminare definitivamente questa analisi AI dallo storico?"
        )
    ) {
        return;
    }


    const message =
        document.getElementById(
            "plantAIHistoryMessage"
        );


    try {

        const response =
            await fetch(
                `/api/plant-ai/history/${encodeURIComponent(editingProfileId)}/${encodeURIComponent(analysisId)}`,
                {
                    method: "DELETE"
                }
            );


        const data =
            await response.json();


        if (
            !response.ok
            ||
            data.success === false
        ) {
            message.textContent =
                data.message
                ||
                "Impossibile eliminare l'analisi AI.";

            return;
        }


        message.textContent =
            "Analisi AI eliminata dallo storico.";


        await loadPlantAIHistory();

    }
    catch (error) {

        message.textContent =
            "Errore di comunicazione durante l'eliminazione dello storico AI.";

    }

}


function handlePlantPageHash() {

    const hash =
        window.location.hash
        .replace("#", "")
        .trim()
        .toLowerCase();


    if (hash === "new") {
        prepareNewPlant();
        return;
    }


    if (
        ["ai", "history", "profile", "irrigation", "microclimate", "images"]
        .includes(hash)
    ) {
        requestedPlantTab = hash;
    }

}


// ==================================================
// ANNULLAMENTO
// ==================================================

function cancelPlantEdit() {

    editingProfileId =
        null;


    resetPlantAI();


    document.getElementById(
        "plantEditorSection"
    ).style.display =
        "none";

}



// ==================================================
// AVVIO
// ==================================================

bindManualIrrigationSourceTracking();
bindManualProfileFieldSourceTracking();
renderIrrigationSources();
renderProfileFieldSources();
loadPlants();