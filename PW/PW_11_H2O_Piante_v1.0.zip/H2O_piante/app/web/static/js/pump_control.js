let pumpControlCalibrationValid = false;
let pumpControlAverageFlowMlS = null;
let pumpControlConnected = false;
let pumpControlRunning = false;
let pumpControlStatusBusy = false;
let pumpControlCalibrationBusy = false;
let pumpControlCommandBusy = false;


function pumpControlFormat(
    value,
    decimals = 2,
    suffix = ""
) {
    if (
        value === null
        || value === undefined
        || !Number.isFinite(Number(value))
    ) {
        return "-";
    }

    return Number(value).toFixed(decimals) + suffix;
}


function updatePumpControlButtons() {
    const runTimeButton = document.getElementById(
        "btnPumpControlRunTime"
    );

    const runMlButton = document.getElementById(
        "btnPumpControlRunMl"
    );

    const stopButton = document.getElementById(
        "btnPumpControlStop"
    );

    const volumeInput = document.getElementById(
        "pumpControlVolume"
    );

    const durationInput = document.getElementById(
        "pumpControlDuration"
    );

    const estimatedDuration = getPumpControlEstimatedDuration();
    const volumeWithinLimit = (
        estimatedDuration !== null
        && estimatedDuration <= 60
    );

    if (runTimeButton) {
        runTimeButton.disabled = (
            !pumpControlConnected
            || pumpControlRunning
            || pumpControlCommandBusy
        );
    }

    if (durationInput) {
        durationInput.disabled = (
            !pumpControlConnected
            || pumpControlRunning
            || pumpControlCommandBusy
        );
    }

    if (runMlButton) {
        runMlButton.disabled = (
            !pumpControlConnected
            || pumpControlRunning
            || !pumpControlCalibrationValid
            || !volumeWithinLimit
            || pumpControlCommandBusy
        );
    }

    if (volumeInput) {
        volumeInput.disabled = (
            !pumpControlConnected
            || pumpControlRunning
            || !pumpControlCalibrationValid
            || pumpControlCommandBusy
        );
    }

    if (stopButton) {
        stopButton.disabled = (
            !pumpControlConnected
            || !pumpControlRunning
            || pumpControlCommandBusy
        );
    }
}


function getPumpControlDurationSeconds() {
    const element = document.getElementById(
        "pumpControlDuration"
    );

    if (!element) {
        return null;
    }

    const value = Number(element.value);

    if (!Number.isFinite(value) || value <= 0) {
        return null;
    }

    return value;
}


function getPumpControlVolumeMl() {
    const element = document.getElementById(
        "pumpControlVolume"
    );

    if (!element) {
        return null;
    }

    const value = Number(element.value);

    if (!Number.isFinite(value) || value <= 0) {
        return null;
    }

    return value;
}


function getPumpControlEstimatedDuration() {
    const volumeMl = getPumpControlVolumeMl();

    if (
        !pumpControlCalibrationValid
        || pumpControlAverageFlowMlS === null
        || pumpControlAverageFlowMlS <= 0
        || volumeMl === null
    ) {
        return null;
    }

    return volumeMl / pumpControlAverageFlowMlS;
}


function updatePumpControlConversions() {
    const durationSeconds = getPumpControlDurationSeconds();
    const volumeMl = getPumpControlVolumeMl();

    const estimatedVolumeElement = document.getElementById(
        "pumpControlEstimatedVolume"
    );

    const estimatedDurationElement = document.getElementById(
        "pumpControlEstimatedDuration"
    );

    const maxVolumeElement = document.getElementById(
        "pumpControlMaximumVolume"
    );

    if (
        pumpControlCalibrationValid
        && pumpControlAverageFlowMlS !== null
        && pumpControlAverageFlowMlS > 0
    ) {
        if (estimatedVolumeElement) {
            estimatedVolumeElement.textContent = (
                durationSeconds === null
                    ? "-"
                    : pumpControlFormat(
                        durationSeconds * pumpControlAverageFlowMlS,
                        2,
                        " ml"
                    )
            );
        }

        if (estimatedDurationElement) {
            estimatedDurationElement.textContent = (
                volumeMl === null
                    ? "-"
                    : pumpControlFormat(
                        volumeMl / pumpControlAverageFlowMlS,
                        2,
                        " s"
                    )
            );
        }

        if (maxVolumeElement) {
            maxVolumeElement.textContent = pumpControlFormat(
                pumpControlAverageFlowMlS * 60,
                1,
                " ml"
            );
        }
    } else {
        if (estimatedVolumeElement) {
            estimatedVolumeElement.textContent = (
                "Disponibile dopo calibrazione"
            );
        }

        if (estimatedDurationElement) {
            estimatedDurationElement.textContent = (
                "Disponibile dopo calibrazione"
            );
        }

        if (maxVolumeElement) {
            maxVolumeElement.textContent = "-";
        }
    }

    updatePumpControlButtons();
}


async function loadPumpControlCalibration() {
    if (pumpControlCalibrationBusy) {
        return;
    }

    pumpControlCalibrationBusy = true;

    const statusElement = document.getElementById(
        "pumpControlCalibrationStatus"
    );

    const flowElement = document.getElementById(
        "pumpControlAverageFlow"
    );

    const secondsToMlElement = document.getElementById(
        "pumpControlSecondsToMl"
    );

    const mlToSecondsElement = document.getElementById(
        "pumpControlMlToSeconds"
    );

    const message = document.getElementById(
        "pumpControlCalibrationMessage"
    );

    try {
        const response = await fetch(
            "/api/pump-calibration/status",
            {cache: "no-store"}
        );

        const data = await response.json();

        if (!response.ok || data.success === false) {
            throw new Error(
                data.message
                || "Stato calibrazione non disponibile."
            );
        }

        const statistics = data.statistics || {};
        const validation = data.validation || {};

        pumpControlAverageFlowMlS = Number(
            statistics.average_flow_ml_s
        );

        if (!Number.isFinite(pumpControlAverageFlowMlS)) {
            pumpControlAverageFlowMlS = null;
        }

        pumpControlCalibrationValid = (
            validation.valid === true
            && pumpControlAverageFlowMlS !== null
            && pumpControlAverageFlowMlS > 0
        );

        statusElement.textContent = (
            validation.status || "NON DISPONIBILE"
        );

        flowElement.textContent = (
            pumpControlAverageFlowMlS === null
                ? "-"
                : pumpControlFormat(
                    pumpControlAverageFlowMlS,
                    4,
                    " ml/s"
                )
        );

        secondsToMlElement.textContent = (
            pumpControlCalibrationValid
                ? (
                    "1 s ≈ "
                    + pumpControlFormat(
                        pumpControlAverageFlowMlS,
                        4,
                        " ml"
                    )
                )
                : "-"
        );

        mlToSecondsElement.textContent = (
            pumpControlCalibrationValid
                ? (
                    "1 ml ≈ "
                    + pumpControlFormat(
                        1 / pumpControlAverageFlowMlS,
                        4,
                        " s"
                    )
                )
                : "-"
        );

        message.textContent = (
            validation.message || ""
        );
    } catch (error) {
        pumpControlCalibrationValid = false;
        pumpControlAverageFlowMlS = null;

        statusElement.textContent = "NON DISPONIBILE";
        flowElement.textContent = "-";
        secondsToMlElement.textContent = "-";
        mlToSecondsElement.textContent = "-";
        message.textContent = error.message;
    }

    pumpControlCalibrationBusy = false;
    updatePumpControlConversions();
}


async function loadPumpControlStatus() {
    if (pumpControlStatusBusy) {
        return;
    }

    pumpControlStatusBusy = true;

    const espElement = document.getElementById(
        "pumpControlEsp32"
    );

    const runningElement = document.getElementById(
        "pumpControlRunning"
    );

    const remainingElement = document.getElementById(
        "pumpControlRemaining"
    );

    const message = document.getElementById(
        "pumpControlStatusMessage"
    );

    const data = await getPumpStatus();

    if (data.success === false) {
        pumpControlConnected = false;
        pumpControlRunning = false;

        espElement.textContent = "NON CONNESSA";
        runningElement.textContent = "FERMA";
        remainingElement.textContent = "0 s";
        message.textContent = (
            data.message || "Stato pompa non disponibile."
        );

        pumpControlStatusBusy = false;
        updatePumpControlButtons();
        return;
    }

    pumpControlConnected = data.connected === true;
    pumpControlRunning = data.running === true;

    espElement.textContent = (
        pumpControlConnected
            ? "CONNESSA"
            : "NON CONNESSA"
    );

    runningElement.textContent = (
        pumpControlRunning
            ? "IN FUNZIONE"
            : "FERMA"
    );

    remainingElement.textContent = (
        pumpControlRunning
            ? pumpControlFormat(
                Number(data.remaining_ms || 0) / 1000,
                1,
                " s"
            )
            : "0 s"
    );

    message.textContent = "";

    pumpControlStatusBusy = false;
    updatePumpControlButtons();
}


async function runPumpControlByTime() {
    if (pumpControlCommandBusy) {
        return;
    }

    const durationSeconds = getPumpControlDurationSeconds();
    const message = document.getElementById(
        "pumpControlTimeMessage"
    );

    if (durationSeconds === null || durationSeconds > 60) {
        message.textContent = (
            "Inserire una durata valida tra 0,1 e 60 secondi."
        );
        return;
    }

    const estimatedVolume = (
        pumpControlCalibrationValid
        && pumpControlAverageFlowMlS !== null
            ? durationSeconds * pumpControlAverageFlowMlS
            : null
    );

    const confirmed = window.confirm(
        "Avviare la pompa per "
        + durationSeconds.toFixed(1)
        + " s?"
        + (
            estimatedVolume === null
                ? ""
                : (
                    "\nVolume stimato: "
                    + estimatedVolume.toFixed(2)
                    + " ml"
                )
        )
    );

    if (!confirmed) {
        return;
    }

    pumpControlCommandBusy = true;
    updatePumpControlButtons();

    try {
        await runPump(
            durationSeconds,
            "pumpControlTimeMessage"
        );
    } finally {
        pumpControlCommandBusy = false;
        await loadPumpControlStatus();
        updatePumpControlButtons();
    }
}


async function runPumpControlByVolume() {
    if (pumpControlCommandBusy) {
        return;
    }

    const volumeMl = getPumpControlVolumeMl();
    const message = document.getElementById(
        "pumpControlVolumeMessage"
    );

    const estimatedDuration = getPumpControlEstimatedDuration();

    if (!pumpControlCalibrationValid) {
        message.textContent = (
            "Comando in millilitri non disponibile: calibrazione non valida."
        );
        return;
    }

    if (volumeMl === null) {
        message.textContent = "Quantità non valida.";
        return;
    }

    if (estimatedDuration === null || estimatedDuration > 60) {
        message.textContent = (
            "La quantità richiede più di 60 secondi di funzionamento."
        );
        return;
    }

    const confirmed = window.confirm(
        "Erogare "
        + volumeMl.toFixed(1)
        + " ml?"
        + "\nTempo stimato: "
        + estimatedDuration.toFixed(2)
        + " s"
    );

    if (!confirmed) {
        return;
    }

    pumpControlCommandBusy = true;
    updatePumpControlButtons();

    try {
        const result = await runPumpByVolume(
            volumeMl,
            "pumpControlVolumeMessage"
        );

        if (result !== null) {
            message.textContent = (
                Number(result.volume_ml).toFixed(1)
                + " ml richiesti; durata calcolata dal backend: "
                + Number(result.duration_s).toFixed(2)
                + " s; portata usata: "
                + Number(result.flow_ml_s).toFixed(4)
                + " ml/s."
            );
        }
    } finally {
        pumpControlCommandBusy = false;
        await loadPumpControlStatus();
        updatePumpControlButtons();
    }
}


async function stopPumpControl() {
    if (pumpControlCommandBusy) {
        return;
    }

    pumpControlCommandBusy = true;
    updatePumpControlButtons();

    try {
        await stopPump(
            "pumpControlStopMessage"
        );
    } finally {
        pumpControlCommandBusy = false;
        await loadPumpControlStatus();
        updatePumpControlButtons();
    }
}


async function initializePumpControlPage() {
    await Promise.all([
        loadPumpControlCalibration(),
        loadPumpControlStatus()
    ]);

    updatePumpControlConversions();
}


initializePumpControlPage();

setInterval(
    loadPumpControlStatus,
    1000
);

setInterval(
    loadPumpControlCalibration,
    5000
);
