async function checkSensorStatus() {

    try {

        const response =
            await fetch(
                "/api/sensor/status"
                + "?channel=0"
                + "&samples=5"
            );


        const data =
            await response.json();


        if (
            !data.success
        ) {

            if (
                data.connected
                === false
            ) {

                updateConnectionDisplay(
                    false
                );

            }


            return;

        }


        updateConnectionDisplay(
            true
        );


        updateSensorDisplay(
            data.sensor_detected,
            data.sensor_message
        );

    }

    catch (error) {

        updateSensorDisplay(
            null,
            "Impossibile verificare il sensore."
        );

    }

}



async function readOperationalSensor() {

    const button =
        document.getElementById(
            "btnReadSensor"
        );


    const message =
        document.getElementById(
            "operationalMessage"
        );


    const results =
        document.getElementById(
            "operationalResults"
        );


    button.disabled =
        true;


    message.textContent =
        "Lettura in corso...";


    results.style.display =
        "none";


    try {

        const response =
            await fetch(
                "/api/sensor/read"
                + "?channel=0"
                + "&samples=10"
            );


        const data =
            await response.json();


        if (
            !data.success
        ) {

            if (
                data.connected
                === false
            ) {

                updateConnectionDisplay(
                    false
                );

            }


            message.textContent =
                data.message;


            return;

        }


        updateConnectionDisplay(
            true
        );


        updateSensorDisplay(
            data.sensor_detected,
            data.sensor_message
        );


        document.getElementById(
            "operationalRaw"
        ).textContent =
            data.raw_average;


        document.getElementById(
            "operationalStd"
        ).textContent =
            data.standard_deviation;


        document.getElementById(
            "operationalMin"
        ).textContent =
            data.minimum;


        document.getElementById(
            "operationalMax"
        ).textContent =
            data.maximum;


        const list =
            document.getElementById(
                "operationalMeasurements"
            );


        list.innerHTML =
            "";


        data.values.forEach(
            function(value) {

                const item =
                    document.createElement(
                        "li"
                    );


                item.textContent =
                    value;


                list.appendChild(
                    item
                );

            }
        );


        if (
            data.sensor_detected
            === false
        ) {

            disableCalibrationSave();


            document.getElementById(
                "operationalState"
            ).textContent =
                "NON DISPONIBILE";


            document.getElementById(
                "operationalPercent"
            ).textContent =
                "Non disponibile";


            message.textContent =
                data.sensor_message;


            results.style.display =
                "block";


            return;

        }


        document.getElementById(
            "operationalState"
        ).textContent =
            (
                data.state !== null
            )
            ? data.state
            : "NON CALIBRATO";


        document.getElementById(
            "operationalPercent"
        ).textContent =
            (
                data.humidity_percent !== null
            )
            ? data.humidity_percent + " %"
            : "Non disponibile";


        if (
            data.humidity_percent
            === null
        ) {

            message.textContent =
                "Lettura completata. "
                + "L'indice percentuale non è ancora "
                + "disponibile perché la calibrazione "
                + "ASCIUTTO-SATURO non è completa.";

        }

        else {

            message.textContent =
                "Lettura completata correttamente.";

        }


        results.style.display =
            "block";

    }

    catch (error) {

        updateConnectionDisplay(
            false
        );


        disableCalibrationSave();


        message.textContent =
            "Errore durante la lettura del sensore.";

    }

    finally {

        button.disabled =
            false;

    }

}