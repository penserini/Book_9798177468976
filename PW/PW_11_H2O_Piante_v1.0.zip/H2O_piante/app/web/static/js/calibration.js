async function acquireMeasurements() {

    const message =
        document.getElementById(
            "acquisitionMessage"
        );


    const results =
        document.getElementById(
            "results"
        );


    const button =
        document.getElementById(
            "btnAcquire"
        );


    const saveButton =
        document.getElementById(
            "btnSave"
        );


    disableCalibrationSave();


    button.disabled =
        true;


    message.textContent =
        "Acquisizione in corso...";


    results.style.display =
        "none";


    try {

        const response =
            await fetch(
                "/api/calibration/acquire"
                + "?channel=0"
                + "&samples=10"
            );


        const data =
            await response.json();


        if (
            !data.success
        ) {

            if (
                data.connected
                === false
            ) {

                updateConnectionDisplay(
                    false
                );

            }


            if (
                data.sensor_detected
                === false
            ) {

                updateSensorDisplay(
                    false,
                    data.message
                );

            }


            disableCalibrationSave();


            message.textContent =
                data.message;


            return;

        }


        updateConnectionDisplay(
            true
        );


        updateSensorDisplay(
            true,
            "Sensore rilevato correttamente."
        );


        message.textContent =
            "Acquisizione completata correttamente.";


        document.getElementById(
            "averageValue"
        ).textContent =
            data.average;


        document.getElementById(
            "minimumValue"
        ).textContent =
            data.minimum;


        document.getElementById(
            "maximumValue"
        ).textContent =
            data.maximum;


        document.getElementById(
            "stdValue"
        ).textContent =
            data.standard_deviation;


        const list =
            document.getElementById(
                "measurementsList"
            );


        list.innerHTML =
            "";


        data.values.forEach(
            function(value) {

                const item =
                    document.createElement(
                        "li"
                    );


                item.textContent =
                    value;


                list.appendChild(
                    item
                );

            }
        );


        /*
         * Soltanto una nuova acquisizione valida
         * abilita il salvataggio.
         */
        saveButton.disabled =
            false;


        document.getElementById(
            "saveMessage"
        ).textContent =
            "";


        results.style.display =
            "block";

    }

    catch (error) {

        updateConnectionDisplay(
            false
        );


        disableCalibrationSave();


        message.textContent =
            "Errore durante l'acquisizione.";

    }

    finally {

        button.disabled =
            false;

    }

}



async function saveCalibrationPoint() {

    const type =
        document.getElementById(
            "calibrationType"
        ).value;


    const message =
        document.getElementById(
            "saveMessage"
        );


    const button =
        document.getElementById(
            "btnSave"
        );


    button.disabled =
        true;


    let saveSuccessful =
        false;


    message.textContent =
        "Salvataggio in corso...";


    try {

        const response =
            await fetch(
                "/api/calibration/save",
                {

                    method:
                        "POST",

                    headers: {

                        "Content-Type":
                            "application/json"

                    },

                    body:
                        JSON.stringify(
                            {
                                name:
                                    type
                            }
                        )

                }
            );


        const data =
            await response.json();


        if (
            !data.success
        ) {

            message.textContent =
                data.message;


            if (
                data.already_saved
            ) {

                saveSuccessful =
                    true;

            }


            return;

        }


        saveSuccessful =
            true;


        message.textContent =
            data.message
            + " Per salvare un altro punto "
            + "eseguire una nuova acquisizione.";


        await loadCalibrationPoints();

        await loadCalibrationStatus();

    }

    catch (error) {

        message.textContent =
            "Errore durante il salvataggio.";

    }

    finally {

        if (
            !saveSuccessful
        ) {

            button.disabled =
                false;

        }

    }

}



async function deleteCalibrationPoint(
    name
) {

    const confirmed =
        confirm(
            "Eliminare il punto di calibrazione "
            + name
            + "?"
        );


    if (
        !confirmed
    ) {

        return;

    }


    try {

        const response =
            await fetch(

                "/api/calibration/points/"
                + encodeURIComponent(
                    name
                ),

                {
                    method:
                        "DELETE"
                }

            );


        const data =
            await response.json();


        if (
            !data.success
        ) {

            alert(
                data.message
            );


            return;

        }


        await loadCalibrationPoints();

        await loadCalibrationStatus();

    }

    catch (error) {

        alert(
            "Errore durante l'eliminazione."
        );

    }

}



async function loadCalibrationPoints() {

    const body =
        document.getElementById(
            "calibrationPointsBody"
        );


    const message =
        document.getElementById(
            "pointsMessage"
        );


    try {

        const response =
            await fetch(
                "/api/calibration/points"
            );


        const data =
            await response.json();


        if (
            !data.success
        ) {

            message.textContent =
                data.message;


            return;

        }


        body.innerHTML =
            "";


        if (
            data.points.length === 0
        ) {

            message.textContent =
                "Nessun punto di calibrazione memorizzato.";


            return;

        }


        message.textContent =
            "";


        data.points.forEach(
            function(point) {

                const row =
                    document.createElement(
                        "tr"
                    );


                const values = [

                    point.name,
                    point.average,
                    point.minimum,
                    point.maximum,
                    point.standard_deviation,
                    point.samples,
                    point.timestamp

                ];


                values.forEach(
                    function(value) {

                        const cell =
                            document.createElement(
                                "td"
                            );


                        cell.textContent =
                            value;


                        row.appendChild(
                            cell
                        );

                    }
                );


                const actionCell =
                    document.createElement(
                        "td"
                    );


                const deleteButton =
                    document.createElement(
                        "button"
                    );


                deleteButton.textContent =
                    "ELIMINA";


                deleteButton.onclick =
                    function() {

                        deleteCalibrationPoint(
                            point.name
                        );

                    };


                actionCell.appendChild(
                    deleteButton
                );


                row.appendChild(
                    actionCell
                );


                body.appendChild(
                    row
                );

            }
        );

    }

    catch (error) {

        message.textContent =
            "Errore durante il caricamento dei punti.";

    }

}