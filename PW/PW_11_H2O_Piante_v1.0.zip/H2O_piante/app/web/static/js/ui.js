function disableCalibrationSave() {

    document.getElementById(
        "btnSave"
    ).disabled = true;

}



function clearCalibrationMessages() {

    document.getElementById(
        "acquisitionMessage"
    ).textContent = "";


    document.getElementById(
        "saveMessage"
    ).textContent = "";

}



function updateConnectionDisplay(
    connected
) {

    const status =
        document.getElementById(
            "connectionStatus"
        );


    const message =
        document.getElementById(
            "connectionMessage"
        );


    if (connected) {

        status.textContent =
            "CONNESSA";


        status.className =
            "status connected";


        if (
            message.textContent
            === "Connessione con ESP32 persa."
        ) {

            message.textContent =
                "ESP32 connessa correttamente.";

        }

    }

    else {

        status.textContent =
            "NON CONNESSA";


        status.className =
            "status disconnected";


        message.textContent =
            "Connessione con ESP32 persa.";


        disableCalibrationSave();


        updateSensorDisplay(
            null,
            "Sensore non verificabile: ESP32 non connessa."
        );

    }

}



function updateSensorDisplay(
    detected,
    message
) {

    const status =
        document.getElementById(
            "sensorStatus"
        );


    const sensorMessage =
        document.getElementById(
            "sensorMessage"
        );


    if (
        detected === true
    ) {

        status.textContent =
            "RILEVATO";


        status.className =
            "sensor-status sensor-ok";


        clearCalibrationMessages();

    }

    else if (
        detected === false
    ) {

        status.textContent =
            "NON RILEVATO";


        status.className =
            "sensor-status sensor-error";


        disableCalibrationSave();

    }

    else {

        status.textContent =
            "NON VERIFICATO";


        status.className =
            "sensor-status sensor-error";


        disableCalibrationSave();

    }


    sensorMessage.textContent =
        message || "";

}