// ==================================================
// FORMATTAZIONE
// ==================================================

function formatPumpValue(
    value,
    decimals = 2,
    suffix = ""
) {

    if (
        value === null
        ||
        value === undefined
    ) {

        return "-";

    }


    return (
        Number(value)
        .toFixed(decimals)
        +
        suffix
    );

}



// ==================================================
// CARICAMENTO STATO
// ==================================================

async function loadPumpCalibration() {

    const message =
        document.getElementById(
            "pumpCalibrationMessage"
        );


    try {

        const response =
            await fetch(
                "/api/pump-calibration/status"
            );


        const data =
            await response.json();


        if (
            !response.ok
            ||
            data.success === false
        ) {

            message.textContent =
                data.message
                ||
                "Errore durante il caricamento della calibrazione.";


            return;

        }


        renderPumpStatistics(
            data.statistics
        );


        renderPumpValidation(
            data.validation
        );


        renderPumpMeasurements(
            data.measurements
        );

    }

    catch (error) {

        message.textContent =
            "Errore di comunicazione con il backend.";

    }

}



// ==================================================
// STATISTICHE
// ==================================================

function renderPumpStatistics(
    statistics
) {

    document.getElementById(
        "averageFlow"
    ).textContent =
        formatPumpValue(
            statistics.average_flow_ml_s,
            4,
            " ml/s"
        );


    document.getElementById(
        "minimumFlow"
    ).textContent =
        formatPumpValue(
            statistics.minimum_flow_ml_s,
            4,
            " ml/s"
        );


    document.getElementById(
        "maximumFlow"
    ).textContent =
        formatPumpValue(
            statistics.maximum_flow_ml_s,
            4,
            " ml/s"
        );


    document.getElementById(
        "flowStdDev"
    ).textContent =
        formatPumpValue(
            statistics.standard_deviation_ml_s,
            4,
            " ml/s"
        );


    document.getElementById(
        "flowVariation"
    ).textContent =
        formatPumpValue(
            statistics.coefficient_of_variation_percent,
            2,
            " %"
        );


    document.getElementById(
        "pumpSamples"
    ).textContent =
        statistics.samples
        ??
        0;

}



// ==================================================
// VALIDAZIONE
// ==================================================

function renderPumpValidation(
    validation
) {

    document.getElementById(
        "pumpCalibrationStatus"
    ).textContent =
        validation.status
        ||
        "INCOMPLETA";


    document.getElementById(
        "pumpCalibrationValidationMessage"
    ).textContent =
        validation.message
        ||
        "";

}



// ==================================================
// TABELLA MISURE
// ==================================================

function renderPumpMeasurements(
    measurements
) {

    const body =
        document.getElementById(
            "pumpMeasurementsBody"
        );


    body.innerHTML =
        "";


    if (
        !measurements
        ||
        measurements.length === 0
    ) {

        const row =
            document.createElement(
                "tr"
            );


        const cell =
            document.createElement(
                "td"
            );


        cell.colSpan =
            7;


        cell.textContent =
            "Nessuna misura salvata.";


        row.appendChild(
            cell
        );


        body.appendChild(
            row
        );


        return;

    }


    measurements.forEach(
        (
            measurement,
            index
        ) => {

            const row =
                document.createElement(
                    "tr"
                );


            const values = [

                index + 1,

                measurement.duration_s,

                measurement.volume_ml,

                measurement.voltage_v,

                measurement.flow_ml_s,

                measurement.timestamp

            ];


            for (
                const value
                of values
            ) {

                const cell =
                    document.createElement(
                        "td"
                    );


                cell.textContent =
                    value;


                row.appendChild(
                    cell
                );

            }


            const actionCell =
                document.createElement(
                    "td"
                );


            const deleteButton =
                document.createElement(
                    "button"
                );


            deleteButton.type =
                "button";


            deleteButton.textContent =
                "ELIMINA";


            deleteButton.onclick =
                () =>
                    deletePumpMeasurement(
                        measurement.measurement_id
                    );


            actionCell.appendChild(
                deleteButton
            );


            row.appendChild(
                actionCell
            );


            body.appendChild(
                row
            );

        }
    );

}



// ==================================================
// COMANDO POMPA DALLA PAGINA DI CALIBRAZIONE
// ==================================================

async function runCalibrationPump() {

    const durationRaw =
        document
        .getElementById(
            "pumpDuration"
        )
        .value;


    const message =
        document.getElementById(
            "pumpHardwareMessage"
        );


    if (
        durationRaw === ""
    ) {

        message.textContent =
            "Inserire la durata di attivazione della pompa.";


        return false;
    }


    const duration =
        Number(
            durationRaw
        );


    if (
        !Number.isFinite(duration)
        ||
        duration <= 0
    ) {

        message.textContent =
            "Durata pompa non valida.";


        return false;
    }


    message.textContent =
        "Avvio pompa in corso...";


    return await runPump(
        duration,
        "pumpHardwareMessage"
    );

}



// ==================================================
// SALVATAGGIO NUOVA MISURA
// ==================================================

async function savePumpMeasurement() {

    const durationRaw =
        document
        .getElementById(
            "pumpDuration"
        )
        .value;


    const volumeRaw =
        document
        .getElementById(
            "pumpVolume"
        )
        .value;


    const voltageRaw =
        document
        .getElementById(
            "pumpVoltage"
        )
        .value;


    const message =
        document.getElementById(
            "pumpCalibrationMessage"
        );


    if (
        durationRaw === ""
        ||
        volumeRaw === ""
        ||
        voltageRaw === ""
    ) {

        message.textContent =
            "Compilare durata, volume e tensione.";


        return;

    }


    const duration =
        Number(
            durationRaw
        );


    const volume =
        Number(
            volumeRaw
        );


    const voltage =
        Number(
            voltageRaw
        );


    if (
        !Number.isFinite(duration)
        ||
        duration <= 0
    ) {

        message.textContent =
            "Durata non valida.";


        return;

    }


    if (
        !Number.isFinite(volume)
        ||
        volume <= 0
    ) {

        message.textContent =
            "Volume non valido.";


        return;

    }


    if (
        !Number.isFinite(voltage)
        ||
        voltage <= 0
    ) {

        message.textContent =
            "Tensione non valida.";


        return;

    }


    const payload = {

        duration_s:
            duration,

        volume_ml:
            volume,

        voltage_v:
            voltage

    };


    try {

        const response =
            await fetch(
                "/api/pump-calibration/measurements",
                {

                    method:
                        "POST",

                    headers: {

                        "Content-Type":
                            "application/json"

                    },

                    body:
                        JSON.stringify(
                            payload
                        )

                }
            );


        const data =
            await response.json();


        if (
            !response.ok
            ||
            data.success === false
        ) {

            message.textContent =
                data.message
                ||
                "Errore durante il salvataggio.";


            return;

        }


        message.textContent =
            (
                "Misura salvata. Portata calcolata: "
                +
                data.measurement.flow_ml_s
                +
                " ml/s."
            );


        document.getElementById(
            "pumpDuration"
        ).value =
            "";


        document.getElementById(
            "pumpVolume"
        ).value =
            "";


        await loadPumpCalibration();

    }

    catch (error) {

        message.textContent =
            "Errore di comunicazione con il backend.";

    }

}



// ==================================================
// ELIMINAZIONE MISURA
// ==================================================

async function deletePumpMeasurement(
    measurementId
) {

    if (
        !window.confirm(
            "Eliminare questa misura?"
        )
    ) {

        return;

    }


    const message =
        document.getElementById(
            "pumpCalibrationMessage"
        );


    try {

        const response =
            await fetch(
                (
                    "/api/pump-calibration/measurements/"
                    +
                    encodeURIComponent(
                        measurementId
                    )
                ),

                {
                    method:
                        "DELETE"
                }
            );


        const data =
            await response.json();


        if (
            !response.ok
            ||
            data.success === false
        ) {

            message.textContent =
                data.message
                ||
                "Errore durante l'eliminazione.";


            return;

        }


        message.textContent =
            "Misura eliminata correttamente.";


        await loadPumpCalibration();

    }

    catch (error) {

        message.textContent =
            "Errore di comunicazione con il backend.";

    }

}



// ==================================================
// AVVIO PAGINA
// ==================================================

loadPumpCalibration();