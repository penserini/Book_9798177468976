// ==================================================
// AVVIO POMPA
// ==================================================

async function runPump(
    durationSeconds,
    messageElementId
) {

    const message =
        document.getElementById(
            messageElementId
        );


    if (
        !Number.isFinite(
            durationSeconds
        )
        ||
        durationSeconds <= 0
    ) {

        if (message) {

            message.textContent =
                "Durata pompa non valida.";

        }

        return false;
    }


    if (
        durationSeconds > 60
    ) {

        if (message) {

            message.textContent =
                "Durata massima consentita: 60 secondi.";

        }

        return false;
    }


    try {

        const response =
            await fetch(
                "/api/pump/run",
                {
                    method:
                        "POST",

                    headers: {
                        "Content-Type":
                            "application/json"
                    },

                    body:
                        JSON.stringify(
                            {
                                duration_s:
                                    durationSeconds
                            }
                        )
                }
            );


        const data =
            await response.json();


        if (
            !response.ok
            ||
            data.success === false
        ) {

            if (message) {

                message.textContent =
                    data.message
                    ||
                    "Errore durante l'avvio della pompa.";

            }

            return false;
        }


        if (message) {

            message.textContent =
                (
                    "Pompa avviata per "
                    +
                    durationSeconds
                    +
                    " secondi."
                );

        }


        return true;

    }

    catch (error) {

        if (message) {

            message.textContent =
                "Errore di comunicazione con il backend.";

        }


        return false;
    }
}


// ==================================================
// STOP POMPA
// ==================================================

async function stopPump(
    messageElementId = "pumpHardwareMessage"
) {

    const message =
        document.getElementById(
            messageElementId
        );


    try {

        const response =
            await fetch(
                "/api/pump/stop",
                {
                    method:
                        "POST"
                }
            );


        const data =
            await response.json();


        if (
            !response.ok
            ||
            data.success === false
        ) {

            if (message) {

                message.textContent =
                    data.message
                    ||
                    "Errore durante l'arresto della pompa.";

            }

            return false;
        }


        if (message) {

            message.textContent =
                "POMPA ARRESTATA.";

        }


        return true;

    }

    catch (error) {

        if (message) {

            message.textContent =
                "Errore di comunicazione durante lo STOP.";

        }


        return false;
    }
}


// ==================================================
// STATO
// ==================================================

async function getPumpStatus() {

    try {

        const response =
            await fetch(
                "/api/pump/status",
                {
                    cache: "no-store"
                }
            );


        return (
            await response.json()
        );

    }

    catch (error) {

        return {
            success:
                false,

            connected:
                false,

            running:
                false,

            remaining_ms:
                0
        };
    }
}
// ==================================================
// AVVIO POMPA PER VOLUME
// ==================================================

async function runPumpByVolume(
    volumeMl,
    messageElementId
) {

    const message =
        document.getElementById(
            messageElementId
        );


    if (
        !Number.isFinite(
            volumeMl
        )
        ||
        volumeMl <= 0
    ) {

        if (message) {

            message.textContent =
                "Quantità d'acqua non valida.";

        }

        return null;
    }


    try {

        const response =
            await fetch(
                "/api/pump/run-ml",
                {
                    method:
                        "POST",

                    headers: {
                        "Content-Type":
                            "application/json"
                    },

                    body:
                        JSON.stringify(
                            {
                                volume_ml:
                                    volumeMl
                            }
                        )
                }
            );


        const data =
            await response.json();


        if (
            !response.ok
            ||
            data.success === false
        ) {

            if (message) {

                message.textContent =
                    data.message
                    ||
                    "Errore durante l'erogazione in millilitri.";

            }

            return null;
        }


        if (message) {

            message.textContent =
                (
                    "Pompa avviata per erogare "
                    +
                    volumeMl
                    +
                    " ml."
                );

        }


        return data;

    }

    catch (error) {

        if (message) {

            message.textContent =
                "Errore di comunicazione con il backend.";

        }


        return null;
    }
}
