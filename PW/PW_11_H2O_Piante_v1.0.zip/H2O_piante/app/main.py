from pathlib import Path

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from app.api.web_routes import router as web_router
from app.api.connection_routes import router as connection_router
from app.api.sensor_routes import router as sensor_router
from app.api.calibration_routes import router as calibration_router
from app.api.plant_routes import router as plant_router
from app.api.plant_ai_routes import router as plant_ai_router
from app.api.irrigation_routes import router as irrigation_router
from app.api.environment_routes import router as environment_router
from app.api.pump_calibration_routes import router as pump_calibration_router
from app.api.pump_routes import router as pump_router

from app.core.app_context import AppContext


app = FastAPI(
    title="H2O Piante",
    version="0.5.0"
)


app.state.ctx = (
    AppContext()
)


BASE_DIR = (
    Path(__file__)
    .resolve()
    .parent
)


app.mount(
    "/static",

    StaticFiles(
        directory=
            BASE_DIR
            /
            "web"
            /
            "static"
    ),

    name="static"
)


app.include_router(
    web_router
)


app.include_router(
    connection_router
)


app.include_router(
    sensor_router
)


app.include_router(
    calibration_router
)


app.include_router(
    plant_router
)


app.include_router(
    plant_ai_router
)


app.include_router(
    irrigation_router
)


app.include_router(
    environment_router
)


app.include_router(
    pump_calibration_router
)


app.include_router(
    pump_router
)