from pathlib import Path

from fastapi import (
    APIRouter,
    Request
)

from fastapi.responses import HTMLResponse

from fastapi.templating import Jinja2Templates


router = APIRouter(
    tags=["Web"]
)


BASE_DIR = (
    Path(__file__)
    .resolve()
    .parents[1]
)


templates = (
    Jinja2Templates(
        directory=
            BASE_DIR
            /
            "web"
            /
            "template"
    )
)


# ==================================================
# DASHBOARD
# ==================================================

@router.get(
    "/",
    response_class=HTMLResponse
)
def home(
    request: Request
):

    return templates.TemplateResponse(

        request=
            request,

        name=
            "index.html",

        context={}
    )


# ==================================================
# GESTIONE PIANTE
# ==================================================

@router.get(
    "/plants",
    response_class=HTMLResponse
)
def plants_page(
    request: Request
):

    return templates.TemplateResponse(

        request=
            request,

        name=
            "plants.html",

        context={}
    )


# ==================================================
# CALIBRAZIONE POMPA
# ==================================================

@router.get(
    "/pump-calibration",
    response_class=HTMLResponse
)
def pump_calibration_page(
    request: Request
):

    return templates.TemplateResponse(

        request=
            request,

        name=
            "pump_calibration.html",

        context={}
    )

# ==================================================
# CONTROLLO POMPA
# ==================================================

@router.get(
    "/pump-control",
    response_class=HTMLResponse
)
def pump_control_page(
    request: Request
):

    return templates.TemplateResponse(

        request=
            request,

        name=
            "pump_control.html",

        context={}
    )

