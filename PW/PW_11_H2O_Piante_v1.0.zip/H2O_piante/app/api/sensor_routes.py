from fastapi import APIRouter, Request

from app.core.app_context import AppContext


router = APIRouter(
    prefix="/api/sensor",
    tags=["Sensor"]
)


def get_context(request: Request) -> AppContext:
    return request.app.state.ctx


@router.get("/status")
def sensor_status(
    request: Request,
    channel: int = 0,
    samples: int = 5
):
    ctx = get_context(request)

    try:
        if not ctx.check_esp32_connection():
            return {
                "success": False,
                "connected": False,
                "sensor_detected": None,
                "message": "ESP32 non connessa."
            }

        values = ctx.calibration_service.acquire_measurements(
            connection=ctx.connection,
            channel=channel,
            samples=samples
        )

        ctx.mark_connection_alive()

        stats = ctx.calibration_service.calculate_statistics(values)
        validation = ctx.calibration_service.validate_measurements(values)

        return {
            "success": True,
            "connected": True,
            "sensor_detected": validation["valid"],
            "sensor_status": validation["status"],
            "sensor_message": validation["reason"],
            "channel": channel,
            "samples": len(values),
            "average": round(stats["average"], 2),
            "minimum": stats["minimum"],
            "maximum": stats["maximum"],
            "standard_deviation": round(stats["standard_deviation"], 2)
        }

    except Exception as error:
        return {
            "success": False,
            "connected": ctx.connection.is_connected(),
            "sensor_detected": None,
            "message": str(error)
        }


@router.get("/read")
def read_sensor_operational(
    request: Request,
    channel: int = 0,
    samples: int = 10
):
    ctx = get_context(request)

    try:
        if not ctx.check_esp32_connection():
            ctx.invalidate_pending_calibration()

            return {
                "success": False,
                "connected": False,
                "sensor_detected": None,
                "message": "ESP32 non connessa."
            }

        values = ctx.calibration_service.acquire_measurements(
            connection=ctx.connection,
            channel=channel,
            samples=samples
        )

        ctx.mark_connection_alive()

        stats = ctx.calibration_service.calculate_statistics(values)
        validation = ctx.calibration_service.validate_measurements(values)
        raw_average = round(stats["average"], 2)

        if not validation["valid"]:
            ctx.invalidate_pending_calibration()

            return {
                "success": True,
                "connected": True,
                "sensor_detected": False,
                "sensor_status": validation["status"],
                "sensor_message": validation["reason"],
                "channel": channel,
                "samples": len(values),
                "values": values,
                "raw_average": raw_average,
                "minimum": stats["minimum"],
                "maximum": stats["maximum"],
                "standard_deviation": round(stats["standard_deviation"], 2),
                "state": None,
                "humidity_percent": None
            }

        try:
            state = ctx.calibration_service.classify_moisture(raw_average)
        except RuntimeError:
            state = None

        try:
            humidity_percent = (
                ctx.calibration_service
                .calculate_moisture_percentage(raw_average)
            )
        except RuntimeError:
            humidity_percent = None

        return {
            "success": True,
            "connected": True,
            "sensor_detected": True,
            "sensor_status": "RILEVATO",
            "sensor_message": "Sensore rilevato correttamente.",
            "channel": channel,
            "samples": len(values),
            "values": values,
            "raw_average": raw_average,
            "minimum": stats["minimum"],
            "maximum": stats["maximum"],
            "standard_deviation": round(stats["standard_deviation"], 2),
            "state": state,
            "humidity_percent": humidity_percent
        }

    except Exception as error:
        ctx.invalidate_pending_calibration()
        ctx.connection.disconnect()
        ctx.connection_failures = 0

        return {
            "success": False,
            "connected": False,
            "sensor_detected": None,
            "message": str(error)
        }
