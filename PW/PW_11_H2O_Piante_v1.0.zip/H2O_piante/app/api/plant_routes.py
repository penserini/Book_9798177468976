from dataclasses import asdict
from pathlib import Path
from uuid import uuid4

from fastapi import (
    APIRouter,
    Request,
    UploadFile,
    File
)

from app.core.app_context import AppContext
from app.models.api_models import PlantProfilePayload
from app.models.plant_profile import PlantProfile


router = APIRouter(
    tags=["Plant"]
)


# ==================================================
# CONFIGURAZIONE IMMAGINI
# ==================================================

APP_DIR = (
    Path(__file__)
    .resolve()
    .parents[1]
)


PLANT_UPLOAD_ROOT = (
    APP_DIR
    / "web"
    / "static"
    / "uploads"
    / "plants"
)


ALLOWED_IMAGE_EXTENSIONS = {
    ".jpg",
    ".jpeg",
    ".png",
    ".webp"
}


MAX_IMAGE_SIZE_BYTES = (
    5
    *
    1024
    *
    1024
)


# ==================================================
# CONTEXTO APPLICATIVO
# ==================================================

def get_context(
    request: Request
) -> AppContext:

    return (
        request.app.state.ctx
    )


# ==================================================
# CONVERSIONE PAYLOAD → MODELLO
# ==================================================

def payload_to_profile(
    profile_id: str,
    payload: PlantProfilePayload
) -> PlantProfile:

    data = (
        payload.model_dump()
    )


    data["profile_id"] = (
        profile_id
    )


    return PlantProfile(
        **data
    )


# ==================================================
# ENDPOINT LEGACY - PROFILO ATTIVO
# ==================================================

@router.get(
    "/api/plant/profile"
)
def get_active_plant_profile(
    request: Request
):

    ctx = get_context(
        request
    )


    try:

        profile = (
            ctx
            .plant_profile_service
            .get_profile()
        )


        return {
            "success":
                True,

            "profile":
                asdict(
                    profile
                )
        }


    except Exception as error:

        return {
            "success":
                False,

            "message":
                str(
                    error
                )
        }


@router.put(
    "/api/plant/profile"
)
def update_active_plant_profile(
    request: Request,
    payload: PlantProfilePayload
):

    ctx = get_context(
        request
    )


    try:

        data = (
            payload.model_dump(
                exclude={
                    "profile_id"
                }
            )
        )


        profile = (
            ctx
            .plant_profile_service
            .update_profile(
                **data
            )
        )


        ctx.irrigation_service.profile = (
            profile
        )


        return {
            "success":
                True,

            "message":
                "Profilo pianta aggiornato correttamente.",

            "profile":
                asdict(
                    profile
                )
        }


    except Exception as error:

        return {
            "success":
                False,

            "message":
                str(
                    error
                )
        }


# ==================================================
# ELENCO PROFILI
# ==================================================

@router.get(
    "/api/plants"
)
def get_plant_profiles(
    request: Request
):

    ctx = get_context(
        request
    )


    profiles = (
        ctx
        .plant_profile_service
        .get_profiles()
    )


    return {
        "success":
            True,

        "active_profile_id":
            ctx
            .plant_profile_service
            .active_profile_id,

        "profiles": {

            profile_id:
                asdict(
                    profile
                )

            for (
                profile_id,
                profile
            )
            in profiles.items()
        }
    }


# ==================================================
# CREAZIONE PROFILO
# ==================================================

@router.post(
    "/api/plants"
)
def create_plant_profile(
    request: Request,
    payload: PlantProfilePayload
):

    ctx = get_context(
        request
    )


    try:

        if not payload.profile_id:

            return {
                "success":
                    False,

                "message":
                    "profile_id obbligatorio per creare un nuovo profilo."
            }


        profile = (
            payload_to_profile(
                payload.profile_id,
                payload
            )
        )


        created = (
            ctx
            .plant_profile_service
            .create_profile(
                profile
            )
        )


        return {
            "success":
                True,

            "message":
                (
                    f"Profilo {created.profile_id} "
                    "creato correttamente."
                ),

            "profile":
                asdict(
                    created
                )
        }


    except Exception as error:

        return {
            "success":
                False,

            "message":
                str(
                    error
                )
        }


# ==================================================
# LETTURA SINGOLO PROFILO
# ==================================================

@router.get(
    "/api/plants/{profile_id}"
)
def get_plant_profile(
    profile_id: str,
    request: Request
):

    ctx = get_context(
        request
    )


    profile = (
        ctx
        .plant_profile_service
        .get_profile_by_id(
            profile_id
        )
    )


    if profile is None:

        return {
            "success":
                False,

            "message":
                (
                    f"Profilo {profile_id} "
                    "non trovato."
                )
        }


    return {
        "success":
            True,

        "active":
            (
                ctx
                .plant_profile_service
                .active_profile_id
                ==
                profile_id
            ),

        "profile":
            asdict(
                profile
            )
    }


# ==================================================
# MODIFICA PROFILO
# ==================================================

@router.put(
    "/api/plants/{profile_id}"
)
def update_plant_profile(
    profile_id: str,
    request: Request,
    payload: PlantProfilePayload
):

    ctx = get_context(
        request
    )


    try:

        profile = (
            payload_to_profile(
                profile_id,
                payload
            )
        )


        updated = (
            ctx
            .plant_profile_service
            .update_profile_by_id(
                profile_id,
                profile
            )
        )


        if (
            ctx
            .plant_profile_service
            .active_profile_id
            ==
            profile_id
        ):

            ctx.irrigation_service.profile = (
                updated
            )


        return {
            "success":
                True,

            "message":
                (
                    f"Profilo {profile_id} "
                    "aggiornato correttamente."
                ),

            "profile":
                asdict(
                    updated
                )
        }


    except Exception as error:

        return {
            "success":
                False,

            "message":
                str(
                    error
                )
        }


# ==================================================
# ELIMINAZIONE PROFILO
# ==================================================

@router.delete(
    "/api/plants/{profile_id}"
)
def delete_plant_profile(
    profile_id: str,
    request: Request
):

    ctx = get_context(
        request
    )


    try:

        was_active = (
            ctx
            .plant_profile_service
            .active_profile_id
            ==
            profile_id
        )


        ctx.plant_profile_service.delete_profile(
            profile_id
        )


        if was_active:

            ctx.irrigation_service.profile = (
                ctx
                .plant_profile_service
                .get_profile()
            )


        return {
            "success":
                True,

            "active_profile_id":
                ctx
                .plant_profile_service
                .active_profile_id,

            "message":
                (
                    f"Profilo {profile_id} "
                    "eliminato correttamente."
                )
        }


    except Exception as error:

        return {
            "success":
                False,

            "message":
                str(
                    error
                )
        }


# ==================================================
# ATTIVAZIONE PROFILO
# ==================================================

@router.put(
    "/api/plants/{profile_id}/activate"
)
def activate_plant_profile(
    profile_id: str,
    request: Request
):

    ctx = get_context(
        request
    )


    try:

        profile = (
            ctx
            .plant_profile_service
            .activate_profile(
                profile_id
            )
        )


        ctx.irrigation_service.profile = (
            profile
        )


        return {
            "success":
                True,

            "active_profile_id":
                profile_id,

            "message":
                (
                    f"Profilo {profile_id} "
                    "impostato come attivo."
                ),

            "profile":
                asdict(
                    profile
                )
        }


    except Exception as error:

        return {
            "success":
                False,

            "message":
                str(
                    error
                )
        }


# ==================================================
# UPLOAD IMMAGINE PROFILO
# ==================================================
#
# NUOVO.
#
# Il file viene salvato in:
#
# app/web/static/uploads/plants/<profile_id>/
#
# PlantProfile.images conserva invece l'URL pubblico.
# ==================================================

@router.post(
    "/api/plants/{profile_id}/images"
)
async def upload_plant_image(
    profile_id: str,
    request: Request,
    image: UploadFile = File(...)
):

    ctx = get_context(
        request
    )


    profile = (
        ctx
        .plant_profile_service
        .get_profile_by_id(
            profile_id
        )
    )


    if profile is None:

        return {
            "success":
                False,

            "message":
                (
                    f"Profilo {profile_id} "
                    "non trovato."
                )
        }


    original_name = (
        image.filename
        or
        ""
    )


    extension = (
        Path(
            original_name
        )
        .suffix
        .lower()
    )


    if (
        extension
        not in
        ALLOWED_IMAGE_EXTENSIONS
    ):

        return {
            "success":
                False,

            "message":
                (
                    "Formato immagine non supportato. "
                    "Usare JPG, JPEG, PNG o WEBP."
                )
        }


    content = (
        await image.read()
    )


    if len(content) == 0:

        return {
            "success":
                False,

            "message":
                "Il file immagine è vuoto."
        }


    if (
        len(content)
        >
        MAX_IMAGE_SIZE_BYTES
    ):

        return {
            "success":
                False,

            "message":
                (
                    "Immagine troppo grande. "
                    "Dimensione massima: 5 MB."
                )
        }


    safe_filename = (
        f"{uuid4().hex}"
        f"{extension}"
    )


    profile_directory = (
        PLANT_UPLOAD_ROOT
        /
        profile_id
    )


    profile_directory.mkdir(
        parents=True,
        exist_ok=True
    )


    file_path = (
        profile_directory
        /
        safe_filename
    )


    with open(
        file_path,
        "wb"
    ) as output_file:

        output_file.write(
            content
        )


    image_url = (
        f"/static/uploads/plants/"
        f"{profile_id}/"
        f"{safe_filename}"
    )


    if (
        image_url
        not in
        profile.images
    ):

        profile.images.append(
            image_url
        )


    ctx.plant_profile_service.save()


    return {
        "success":
            True,

        "message":
            "Immagine caricata correttamente.",

        "image_url":
            image_url,

        "profile":
            asdict(
                profile
            )
    }


# ==================================================
# ELIMINAZIONE IMMAGINE PROFILO
# ==================================================

@router.delete(
    "/api/plants/{profile_id}/images"
)
def delete_plant_image(
    profile_id: str,
    image_url: str,
    request: Request
):

    ctx = get_context(
        request
    )


    profile = (
        ctx
        .plant_profile_service
        .get_profile_by_id(
            profile_id
        )
    )


    if profile is None:

        return {
            "success":
                False,

            "message":
                (
                    f"Profilo {profile_id} "
                    "non trovato."
                )
        }


    if (
        image_url
        not in
        profile.images
    ):

        return {
            "success":
                False,

            "message":
                "Immagine non associata al profilo."
        }


    expected_prefix = (
        f"/static/uploads/plants/"
        f"{profile_id}/"
    )


    if not image_url.startswith(
        expected_prefix
    ):

        return {
            "success":
                False,

            "message":
                "Percorso immagine non valido."
        }


    filename = (
        Path(
            image_url
        )
        .name
    )


    file_path = (
        PLANT_UPLOAD_ROOT
        /
        profile_id
        /
        filename
    )


    if file_path.exists():

        file_path.unlink()


    profile.images.remove(
        image_url
    )


    ctx.plant_profile_service.save()


    return {
        "success":
            True,

        "message":
            "Immagine eliminata correttamente.",

        "profile":
            asdict(
                profile
            )
    }