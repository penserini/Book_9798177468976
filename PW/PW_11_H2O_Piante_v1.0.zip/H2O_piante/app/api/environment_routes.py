from fastapi import APIRouter, Request


router = APIRouter(
    prefix="/api/environment",
    tags=["Environment"]
)


# ==================================================
# STATO SENSORE AMBIENTALE
# ==================================================

@router.get(
    "/status"
)
def environment_status(
    request: Request
):

    ctx = (
        request.app.state.ctx
    )


    service = (
        ctx.environment_service
    )


    configured = (
        service.has_sensor()
    )


    available = (
        service.is_sensor_available()
    )


    return {
        "success":
            True,

        "configured":
            configured,

        "available":
            available,

        "sensor":
            service.get_sensor_name(),

        "message":
            (
                "Sensore ambientale disponibile."
                if available
                else
                (
                    "Sensore ambientale configurato "
                    "ma non disponibile."
                    if configured
                    else
                    "Nessun sensore ambientale configurato."
                )
            )
    }


# ==================================================
# LETTURA AMBIENTALE
# ==================================================
#
# NUOVO endpoint.
#
# Non modifica calibrazione, profilo pianta
# o decisione di irrigazione.
# ==================================================

@router.get(
    "/read"
)
def environment_read(
    request: Request
):

    ctx = (
        request.app.state.ctx
    )


    service = (
        ctx.environment_service
    )


    try:

        if not ctx.check_esp32_connection():

            return {
                "success":
                    False,

                "connected":
                    False,

                "sensor":
                    service.get_sensor_name(),

                "message":
                    "ESP32 non connessa."
            }


        reading = (
            service
            .read_environment()
        )


        # Una lettura reale riuscita conferma
        # che la comunicazione ESP32 è attiva.

        ctx.mark_connection_alive()


        return {
            "success":
                True,

            "connected":
                True,

            "sensor":
                service.get_sensor_name(),

            "temperature_c":
                reading.temperature_c,

            "humidity_percent":
                reading.humidity_percent,

            "timestamp":
                reading.timestamp,

            "message":
                "Lettura ambientale completata correttamente."
        }


    except Exception as error:

        return {
            "success":
                False,

            "connected":
                ctx.connection.is_connected(),

            "sensor":
                service.get_sensor_name(),

            "message":
                str(error)
        }