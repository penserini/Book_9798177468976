from fastapi import APIRouter, Request

from app.core.app_context import AppContext


router = APIRouter(
    prefix="/api",
    tags=["Connection"]
)


def get_context(request: Request) -> AppContext:
    return request.app.state.ctx


@router.post("/connect")
def connect_esp32(request: Request):
    ctx = get_context(request)

    try:
        if not ctx.connection.is_connected():
            ctx.connection.connect()

        if ctx.connection.ping():
            ctx.mark_connection_alive()

            return {
                "success": True,
                "connected": True,
                "mode": ctx.connection_mode,
                "target": ctx.connection_target,
                "message": "ESP32 connessa correttamente."
            }

        ctx.connection.disconnect()
        ctx.connection_failures = 0

        return {
            "success": False,
            "connected": False,
            "mode": ctx.connection_mode,
            "target": ctx.connection_target,
            "message": "ESP32 non risponde al PING."
        }

    except Exception as error:
        ctx.connection.disconnect()
        ctx.connection_failures = 0

        return {
            "success": False,
            "connected": False,
            "mode": ctx.connection_mode,
            "target": ctx.connection_target,
            "message": str(error)
        }


@router.post("/disconnect")
def disconnect_esp32(request: Request):
    ctx = get_context(request)

    try:
        ctx.connection.disconnect()
        ctx.connection_failures = 0
        ctx.invalidate_pending_calibration()

        return {
            "success": True,
            "connected": False,
            "mode": ctx.connection_mode,
            "target": ctx.connection_target,
            "message": "ESP32 disconnessa correttamente."
        }

    except Exception as error:
        return {
            "success": False,
            "connected": ctx.connection.is_connected(),
            "mode": ctx.connection_mode,
            "target": ctx.connection_target,
            "message": str(error)
        }


@router.get("/status")
def connection_status(request: Request):
    ctx = get_context(request)

    connected = ctx.check_esp32_connection()

    return {
        "connected": connected,
        "mode": ctx.connection_mode,
        "target": ctx.connection_target,
        "connection_failures": ctx.connection_failures,
        "max_connection_failures": ctx.max_connection_failures
    }
