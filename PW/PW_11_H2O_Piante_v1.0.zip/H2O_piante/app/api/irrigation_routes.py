from fastapi import APIRouter, Request

from app.core.app_context import AppContext


router = APIRouter(
    prefix="/api/irrigation",
    tags=["Irrigation"]
)


def get_context(request: Request) -> AppContext:
    return request.app.state.ctx


@router.get("/advice")
def irrigation_advice(
    request: Request,
    channel: int = 0,
    samples: int = 10
):
    ctx = get_context(request)

    try:
        if not ctx.check_esp32_connection():
            return {
                "success": False,
                "connected": False,
                "decision_available": False,
                "message": "ESP32 non connessa."
            }

        values = ctx.calibration_service.acquire_measurements(
            connection=ctx.connection,
            channel=channel,
            samples=samples
        )

        ctx.mark_connection_alive()

        stats = ctx.calibration_service.calculate_statistics(values)
        validation = ctx.calibration_service.validate_measurements(values)
        raw_average = round(stats["average"], 2)

        if not validation["valid"]:
            return {
                "success": True,
                "connected": True,
                "sensor_detected": False,
                "decision_available": False,
                "message": validation["reason"],
                "raw_average": raw_average
            }

        state = ctx.calibration_service.classify_moisture(raw_average)
        humidity_percent = (
            ctx.calibration_service
            .calculate_moisture_percentage(raw_average)
        )

        current_profile = ctx.plant_profile_service.get_profile()
        ctx.irrigation_service.profile = current_profile

        advice = ctx.irrigation_service.get_advice(
            humidity_percent=humidity_percent,
            state=state
        )

        return {
            "success": True,
            "connected": True,
            "sensor_detected": True,
            "profile": {
                "name": current_profile.name,
                "plant_name": current_profile.plant_name,
                "source": current_profile.source,
                "minimum_humidity_percent": (
                    current_profile.minimum_humidity_percent
                ),
                "target_humidity_percent": (
                    current_profile.target_humidity_percent
                ),
                "maximum_humidity_percent": (
                    current_profile.maximum_humidity_percent
                ),
                "water_dose_ml": current_profile.water_dose_ml
            },
            "measurement": {
                "raw_average": raw_average,
                "humidity_percent": humidity_percent,
                "state": state,
                "standard_deviation": round(
                    stats["standard_deviation"],
                    2
                )
            },
            **advice
        }

    except Exception as error:
        return {
            "success": False,
            "decision_available": False,
            "message": str(error)
        }
