from fastapi import (
    APIRouter,
    Request
)

from pydantic import (
    BaseModel,
    Field
)


router = APIRouter(
    prefix="/api/pump",
    tags=["Pump"]
)


class PumpRunPayload(
    BaseModel
):

    duration_s: float = Field(
        gt=0,
        le=60
    )


class PumpRunVolumePayload(
    BaseModel
):

    volume_ml: float = Field(
        gt=0
    )


# ==================================================
# STATO
# ==================================================

@router.get(
    "/status"
)
def get_pump_status(
    request: Request
):

    ctx = (
        request.app.state.ctx
    )


    try:

        status = (
            ctx
            .pump_service
            .get_status()
        )


        return {
            "success":
                True,

            **status
        }


    except Exception as error:

        return {
            "success":
                False,

            "message":
                str(
                    error
                )
        }


# ==================================================
# AVVIO A TEMPO
# ==================================================

@router.post(
    "/run"
)
def run_pump(
    payload: PumpRunPayload,
    request: Request
):

    ctx = (
        request.app.state.ctx
    )


    try:

        result = (
            ctx
            .pump_service
            .run_for_seconds(
                payload.duration_s
            )
        )


        return {
            "success":
                True,

            "message":
                (
                    "Pompa avviata per "
                    f"{payload.duration_s} secondi."
                ),

            **result
        }


    except Exception as error:

        return {
            "success":
                False,

            "message":
                str(
                    error
                )
        }


# ==================================================
# AVVIO PER VOLUME
# ==================================================

@router.post(
    "/run-ml"
)
def run_pump_by_volume(
    payload: PumpRunVolumePayload,
    request: Request
):

    ctx = (
        request.app.state.ctx
    )


    try:

        result = (
            ctx
            .pump_service
            .run_for_volume_ml(
                payload.volume_ml
            )
        )


        return {
            "success":
                True,

            "message":
                (
                    "Pompa avviata per erogare "
                    f"{payload.volume_ml:g} ml."
                ),

            **result
        }


    except Exception as error:

        return {
            "success":
                False,

            "message":
                str(
                    error
                )
        }


# ==================================================
# STOP
# ==================================================

@router.post(
    "/stop"
)
def stop_pump(
    request: Request
):

    ctx = (
        request.app.state.ctx
    )


    try:

        result = (
            ctx
            .pump_service
            .stop()
        )


        return {
            "success":
                True,

            "message":
                "Pompa arrestata.",

            **result
        }


    except Exception as error:

        return {
            "success":
                False,

            "message":
                str(
                    error
                )
        }
