from fastapi import (
    APIRouter,
    Request
)

from app.models.pump_calibration import (
    PumpCalibrationPayload
)


router = APIRouter(
    prefix="/api/pump-calibration",
    tags=["Pump Calibration"]
)


# ==================================================
# STATO COMPLETO
# ==================================================

@router.get(
    "/status"
)
def get_pump_calibration_status(
    request: Request
):

    ctx = (
        request.app.state.ctx
    )


    return {
        "success":
            True,

        **ctx
        .pump_calibration_service
        .get_status()
    }


# ==================================================
# ELENCO MISURE
# ==================================================

@router.get(
    "/measurements"
)
def get_pump_measurements(
    request: Request
):

    ctx = (
        request.app.state.ctx
    )


    return {
        "success":
            True,

        "measurements":
            ctx
            .pump_calibration_service
            .get_measurements()
    }


# ==================================================
# NUOVA MISURA
# ==================================================

@router.post(
    "/measurements"
)
def create_pump_measurement(
    payload: PumpCalibrationPayload,
    request: Request
):

    ctx = (
        request.app.state.ctx
    )


    try:

        measurement = (
            ctx
            .pump_calibration_service
            .create_measurement(

                duration_s=
                    payload.duration_s,

                volume_ml=
                    payload.volume_ml,

                voltage_v=
                    payload.voltage_v
            )
        )


        return {
            "success":
                True,

            "message":
                "Misura salvata correttamente.",

            "measurement":
                {
                    "measurement_id":
                        measurement.measurement_id,

                    "duration_s":
                        measurement.duration_s,

                    "volume_ml":
                        measurement.volume_ml,

                    "voltage_v":
                        measurement.voltage_v,

                    "flow_ml_s":
                        measurement.flow_ml_s,

                    "timestamp":
                        measurement.timestamp
                },

            "status":
                ctx
                .pump_calibration_service
                .get_status()
        }


    except Exception as error:

        return {
            "success":
                False,

            "message":
                str(
                    error
                )
        }


# ==================================================
# ELIMINAZIONE MISURA
# ==================================================

@router.delete(
    "/measurements/{measurement_id}"
)
def delete_pump_measurement(
    measurement_id: str,
    request: Request
):

    ctx = (
        request.app.state.ctx
    )


    deleted = (
        ctx
        .pump_calibration_service
        .delete_measurement(
            measurement_id
        )
    )


    if not deleted:

        return {
            "success":
                False,

            "message":
                "Misura non trovata."
        }


    return {
        "success":
            True,

        "message":
            "Misura eliminata correttamente.",

        "status":
            ctx
            .pump_calibration_service
            .get_status()
    }