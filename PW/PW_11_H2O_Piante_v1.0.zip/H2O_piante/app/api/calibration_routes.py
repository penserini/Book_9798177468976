from fastapi import APIRouter, Request

from app.core.app_context import AppContext
from app.models.api_models import CalibrationSaveRequest, CalibrationType


router = APIRouter(
    prefix="/api/calibration",
    tags=["Calibration"]
)


def get_context(request: Request) -> AppContext:
    return request.app.state.ctx


@router.get("/acquire")
def acquire_measurements(
    request: Request,
    channel: int = 0,
    samples: int = 10
):
    ctx = get_context(request)

    try:
        if not ctx.check_esp32_connection():
            ctx.invalidate_pending_calibration()

            return {
                "success": False,
                "connected": False,
                "sensor_detected": None,
                "message": "ESP32 non connessa."
            }

        values = ctx.calibration_service.acquire_measurements(
            connection=ctx.connection,
            channel=channel,
            samples=samples
        )

        ctx.mark_connection_alive()

        stats = ctx.calibration_service.calculate_statistics(values)
        validation = ctx.calibration_service.validate_measurements(values)

        if not validation["valid"]:
            ctx.invalidate_pending_calibration()

            return {
                "success": False,
                "connected": True,
                "sensor_detected": False,
                "sensor_status": validation["status"],
                "message": validation["reason"],
                "values": values,
                "average": round(stats["average"], 2),
                "minimum": stats["minimum"],
                "maximum": stats["maximum"],
                "standard_deviation": round(stats["standard_deviation"], 2)
            }

        ctx.last_measurements = values.copy()
        ctx.last_measurements_saved = False

        return {
            "success": True,
            "connected": True,
            "sensor_detected": True,
            "sensor_status": "RILEVATO",
            "channel": channel,
            "samples": len(values),
            "values": values,
            "average": round(stats["average"], 2),
            "minimum": stats["minimum"],
            "maximum": stats["maximum"],
            "standard_deviation": round(stats["standard_deviation"], 2),
            "saved": False
        }

    except Exception as error:
        ctx.invalidate_pending_calibration()
        ctx.connection.disconnect()
        ctx.connection_failures = 0

        return {
            "success": False,
            "connected": False,
            "sensor_detected": None,
            "message": str(error)
        }


@router.post("/save")
def save_calibration_point(
    request: Request,
    payload: CalibrationSaveRequest
):
    ctx = get_context(request)

    try:
        if not ctx.last_measurements:
            return {
                "success": False,
                "message": (
                    "Nessuna acquisizione valida disponibile. "
                    "Eseguire nuovamente ACQUISISCI 10 MISURE."
                )
            }

        if ctx.last_measurements_saved:
            return {
                "success": False,
                "already_saved": True,
                "message": (
                    "Questa acquisizione è già stata salvata. "
                    "Eseguire una nuova acquisizione."
                )
            }

        if ctx.calibration_service.has_point(payload.name):
            return {
                "success": False,
                "point_exists": True,
                "message": (
                    f"Il punto {payload.name} è già presente. "
                    "Eliminarlo prima di eseguire una nuova calibrazione."
                )
            }

        point = ctx.calibration_service.create_point(
            name=payload.name,
            values=ctx.last_measurements
        )

        ctx.calibration_service.save()
        ctx.last_measurements_saved = True

        return {
            "success": True,
            "already_saved": True,
            "message": (
                f"Punto di calibrazione {point.name} "
                "salvato correttamente."
            ),
            "point": {
                "name": point.name,
                "average": point.average,
                "minimum": point.minimum,
                "maximum": point.maximum,
                "standard_deviation": point.standard_deviation,
                "samples": point.samples,
                "timestamp": point.timestamp
            }
        }

    except Exception as error:
        return {
            "success": False,
            "message": str(error)
        }


@router.get("/points")
def get_calibration_points(request: Request):
    ctx = get_context(request)

    try:
        points = ctx.calibration_service.get_points()
        result = []

        for _, point in points.items():
            result.append({
                "name": point.name,
                "average": point.average,
                "minimum": point.minimum,
                "maximum": point.maximum,
                "standard_deviation": point.standard_deviation,
                "samples": point.samples,
                "timestamp": point.timestamp
            })

        return {
            "success": True,
            "points": result
        }

    except Exception as error:
        return {
            "success": False,
            "message": str(error)
        }


@router.get("/status")
def calibration_status(request: Request):
    ctx = get_context(request)

    try:
        result = ctx.calibration_service.validate_calibration()

        return {
            "success": True,
            **result
        }

    except Exception as error:
        return {
            "success": False,
            "message": str(error)
        }


@router.delete("/points/{name}")
def delete_calibration_point(
    name: CalibrationType,
    request: Request
):
    ctx = get_context(request)

    try:
        deleted = ctx.calibration_service.delete_point(name)

        if not deleted:
            return {
                "success": False,
                "message": f"Il punto {name} non esiste."
            }

        return {
            "success": True,
            "message": (
                f"Punto di calibrazione {name} "
                "eliminato correttamente."
            )
        }

    except Exception as error:
        return {
            "success": False,
            "message": str(error)
        }
