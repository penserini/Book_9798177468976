from pathlib import Path

from fastapi import (
    APIRouter,
    Query,
    Request
)


router = APIRouter(
    prefix="/api/plant-ai",
    tags=["Plant AI"]
)


APP_DIR = (
    Path(__file__)
    .resolve()
    .parents[1]
)


STATIC_DIR = (
    APP_DIR
    / "web"
    / "static"
)


# ==================================================
# STATO AI
# ==================================================

@router.get(
    "/status"
)
def get_plant_ai_status(
    request: Request
):

    ctx = request.app.state.ctx

    return {
        "success": True,
        "provider": (
            ctx
            .plant_ai_service
            .get_provider_name()
        ),
        "model": (
            ctx
            .plant_ai_service
            .get_model_name()
        ),
        "configured": (
            ctx
            .plant_ai_service
            .is_configured()
        )
    }


# ==================================================
# STORICO AI - ELENCO PER PROFILO
# ==================================================

@router.get(
    "/history/{profile_id}"
)
def get_plant_ai_history(
    profile_id: str,
    request: Request
):

    ctx = request.app.state.ctx

    profile = (
        ctx
        .plant_profile_service
        .get_profile_by_id(
            profile_id
        )
    )

    if profile is None:
        return {
            "success": False,
            "message": (
                f"Profilo {profile_id} non trovato."
            )
        }

    entries = (
        ctx
        .plant_ai_history_service
        .get_entries_for_profile(
            profile_id
        )
    )

    return {
        "success": True,
        "profile_id": profile_id,
        "count": len(entries),
        "entries": [
            entry.model_dump()
            for entry in entries
        ]
    }


# ==================================================
# STORICO AI - SINGOLA ANALISI
# ==================================================

@router.get(
    "/history/{profile_id}/{analysis_id}"
)
def get_plant_ai_history_entry(
    profile_id: str,
    analysis_id: str,
    request: Request
):

    ctx = request.app.state.ctx

    entry = (
        ctx
        .plant_ai_history_service
        .get_entry(
            profile_id=profile_id,
            analysis_id=analysis_id
        )
    )

    if entry is None:
        return {
            "success": False,
            "message": (
                "Analisi AI non trovata nello storico."
            )
        }

    return {
        "success": True,
        "entry": entry.model_dump()
    }


# ==================================================
# STORICO AI - ELIMINAZIONE
# ==================================================

@router.delete(
    "/history/{profile_id}/{analysis_id}"
)
def delete_plant_ai_history_entry(
    profile_id: str,
    analysis_id: str,
    request: Request
):

    ctx = request.app.state.ctx

    deleted = (
        ctx
        .plant_ai_history_service
        .delete_entry(
            profile_id=profile_id,
            analysis_id=analysis_id
        )
    )

    if not deleted:
        return {
            "success": False,
            "message": (
                "Analisi AI non trovata nello storico."
            )
        }

    return {
        "success": True,
        "profile_id": profile_id,
        "analysis_id": analysis_id,
        "message": "Analisi AI eliminata dallo storico."
    }


# ==================================================
# ANALISI IMMAGINE
# ==================================================

@router.post(
    "/analyze/{profile_id}"
)
def analyze_plant_image(
    profile_id: str,
    request: Request,
    image_index: int = Query(
        default=0,
        ge=0
    )
):

    ctx = request.app.state.ctx

    profile = (
        ctx
        .plant_profile_service
        .get_profile_by_id(
            profile_id
        )
    )

    if profile is None:
        return {
            "success": False,
            "message": (
                f"Profilo {profile_id} non trovato."
            )
        }

    if not profile.images:
        return {
            "success": False,
            "message": (
                "Il profilo non contiene immagini."
            )
        }

    if image_index >= len(
        profile.images
    ):
        return {
            "success": False,
            "message": (
                "Indice immagine non valido. "
                f"Il profilo contiene "
                f"{len(profile.images)} immagine/i."
            )
        }

    image_url = (
        profile.images[
            image_index
        ]
    )

    static_prefix = "/static/"

    if not image_url.startswith(
        static_prefix
    ):
        return {
            "success": False,
            "message": (
                "Percorso immagine non valido."
            )
        }

    relative_path = (
        image_url[
            len(static_prefix):
        ]
    )

    image_path = (
        STATIC_DIR
        /
        relative_path
    ).resolve()

    static_root = (
        STATIC_DIR.resolve()
    )

    try:
        image_path.relative_to(
            static_root
        )
    except ValueError:
        return {
            "success": False,
            "message": (
                "Percorso immagine non consentito."
            )
        }

    if not image_path.exists():
        return {
            "success": False,
            "message": (
                "Il file immagine associato "
                "al profilo non esiste."
            )
        }

    if not (
        ctx
        .plant_ai_service
        .is_configured()
    ):
        return {
            "success": False,
            "provider": (
                ctx
                .plant_ai_service
                .get_provider_name()
            ),
            "model": (
                ctx
                .plant_ai_service
                .get_model_name()
            ),
            "message": (
                "Provider AI non configurato. "
                "Verificare OPENAI_API_KEY."
            )
        }

    try:
        result = (
            ctx
            .plant_ai_service
            .analyze_image(
                image_path=image_path,
                profile=profile
            )
        )

        provider_name = (
            ctx
            .plant_ai_service
            .get_provider_name()
        )

        model_name = (
            ctx
            .plant_ai_service
            .get_model_name()
        )

        history_entry = (
            ctx
            .plant_ai_history_service
            .add_analysis(
                profile_id=profile_id,
                image_index=image_index,
                image_url=image_url,
                provider=provider_name,
                model=model_name,
                result=result
            )
        )

        return {
            "success": True,
            "provider": provider_name,
            "model": model_name,
            "profile_id": profile_id,
            "image_index": image_index,
            "image_url": image_url,
            "analysis": (
                result
                .analysis
                .model_dump()
            ),
            "usage": (
                result
                .usage
                .model_dump()
            ),
            "cost": (
                result
                .cost
                .model_dump()
            ),
            "history": {
                "saved": True,
                "analysis_id": history_entry.analysis_id,
                "timestamp": history_entry.timestamp
            },
            "message": (
                "Analisi AI completata e salvata "
                "nello storico."
            )
        }

    except Exception as error:
        return {
            "success": False,
            "provider": (
                ctx
                .plant_ai_service
                .get_provider_name()
            ),
            "model": (
                ctx
                .plant_ai_service
                .get_model_name()
            ),
            "message": str(error)
        }
