"""
Provider AI utilizzabili dal progetto H2O Piante.
"""