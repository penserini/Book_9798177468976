from abc import ABC, abstractmethod
from pathlib import Path

from app.models.plant_ai_result import PlantAIResult
from app.models.plant_profile import PlantProfile


class PlantAIProvider(ABC):
    """
    Interfaccia comune per qualsiasi provider AI
    utilizzato per analizzare una pianta.

    Il resto dell'applicazione non deve conoscere
    il provider concreto utilizzato.
    """


    @abstractmethod
    def get_name(
        self
    ) -> str:
        """
        Restituisce il nome del provider AI.
        """
        pass


    @abstractmethod
    def get_model_name(
        self
    ) -> str:
        """
        Restituisce il modello attualmente configurato.
        """
        pass


    @abstractmethod
    def is_configured(
        self
    ) -> bool:
        """
        Indica se il provider dispone della
        configurazione minima necessaria.
        """
        pass


    @abstractmethod
    def analyze(
        self,
        image_path: Path,
        profile: PlantProfile,
        environment_data: dict | None = None,
        soil_data: dict | None = None
    ) -> PlantAIResult:
        """
        Analizza una fotografia e restituisce
        analisi, consumo e costo.
        """
        pass