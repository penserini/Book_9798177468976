import base64
import mimetypes
import os

from pathlib import Path

from openai import OpenAI

from app.ai.plant_ai_provider import PlantAIProvider
from app.models.plant_ai_analysis import PlantAIAnalysis
from app.models.plant_ai_result import (
    PlantAICost,
    PlantAIResult,
    PlantAIUsage
)
from app.models.plant_profile import PlantProfile


class OpenAIPlantAIProvider(
    PlantAIProvider
):
    """
    Implementazione OpenAI del provider AI.
    """


    # ==================================================
    # PREZZI API
    # USD per 1 milione di token.
    #
    # Aggiornamento: 31/08/2026.
    # ==================================================

    MODEL_PRICING = {

        "gpt-5.6-terra": {
            "input":
                2.00,

            "cached_input":
                0.20,

            "output":
                12.00
        }

    }


    def __init__(
        self,
        model: str | None = None
    ):

        self.model = (
            model
            or
            os.getenv(
                "OPENAI_PLANT_MODEL",
                "gpt-5.6-terra"
            )
        )


    # ==================================================
    # IDENTIFICAZIONE PROVIDER
    # ==================================================

    def get_name(
        self
    ) -> str:

        return "OpenAI"


    def get_model_name(
        self
    ) -> str:

        return self.model


    # ==================================================
    # CONFIGURAZIONE
    # ==================================================

    def is_configured(
        self
    ) -> bool:

        api_key = os.getenv(
            "OPENAI_API_KEY"
        )

        return bool(
            api_key
            and
            api_key.strip()
        )


    def _get_client(
        self
    ) -> OpenAI:

        if not self.is_configured():

            raise RuntimeError(
                "OPENAI_API_KEY non configurata."
            )


        return OpenAI(
            api_key=os.getenv(
                "OPENAI_API_KEY"
            )
        )


    # ==================================================
    # PREPARAZIONE IMMAGINE
    # ==================================================

    @staticmethod
    def _image_to_data_url(
        image_path: Path
    ) -> str:

        if not image_path.exists():

            raise FileNotFoundError(
                f"Immagine non trovata: {image_path}"
            )


        if not image_path.is_file():

            raise ValueError(
                "Il percorso indicato non è un file."
            )


        mime_type, _ = mimetypes.guess_type(
            str(image_path)
        )


        allowed_mime_types = {
            "image/jpeg",
            "image/png",
            "image/webp"
        }


        if mime_type not in allowed_mime_types:

            raise ValueError(
                "Formato immagine non supportato "
                "per l'analisi AI."
            )


        encoded_image = (
            base64
            .b64encode(
                image_path.read_bytes()
            )
            .decode(
                "ascii"
            )
        )


        return (
            f"data:{mime_type};base64,"
            f"{encoded_image}"
        )


    # ==================================================
    # COSTRUZIONE CONTESTO
    # ==================================================

    @staticmethod
    def _format_value(
        value
    ) -> str:

        if value is None:
            return "NON DISPONIBILE"

        return str(value)


    def _build_context(
        self,
        profile: PlantProfile,
        environment_data: dict | None,
        soil_data: dict | None
    ) -> str:

        lines = [

            "DATI DEL PROFILO:",

            (
                "ID profilo: "
                +
                self._format_value(
                    profile.profile_id
                )
            ),

            (
                "Nome profilo: "
                +
                self._format_value(
                    profile.name
                )
            ),

            (
                "Nome comune dichiarato: "
                +
                self._format_value(
                    profile.plant_name
                )
            ),

            (
                "Nome scientifico dichiarato: "
                +
                self._format_value(
                    profile.scientific_name
                )
            ),

            (
                "Descrizione: "
                +
                self._format_value(
                    profile.description
                )
            ),

            (
                "Posizione: "
                +
                self._format_value(
                    profile.location
                )
            ),

            (
                "Esposizione: "
                +
                self._format_value(
                    profile.exposure
                )
            ),

            (
                "Tipo di terreno: "
                +
                self._format_value(
                    profile.soil_type
                )
            ),

            (
                "Note: "
                +
                self._format_value(
                    profile.notes
                )
            )

        ]


        if environment_data:

            lines.extend([

                "",

                "DATI AMBIENTALI LOCALI:",

                (
                    "Temperatura ambiente: "
                    +
                    self._format_value(
                        environment_data.get(
                            "temperature_c"
                        )
                    )
                    +
                    " °C"
                ),

                (
                    "Umidità aria: "
                    +
                    self._format_value(
                        environment_data.get(
                            "humidity_percent"
                        )
                    )
                    +
                    " %"
                )

            ])


        if soil_data:

            lines.extend([

                "",

                "DATI DEL TERRENO:",

                (
                    "Stato terreno: "
                    +
                    self._format_value(
                        soil_data.get(
                            "state"
                        )
                    )
                ),

                (
                    "Umidità terreno: "
                    +
                    self._format_value(
                        soil_data.get(
                            "humidity_percent"
                        )
                    )
                    +
                    " %"
                ),

                (
                    "ADC medio: "
                    +
                    self._format_value(
                        soil_data.get(
                            "raw_average"
                        )
                    )
                )

            ])


        return "\n".join(
            lines
        )


    # ==================================================
    # LETTURA USAGE
    # ==================================================

    @staticmethod
    def _extract_usage(
        response
    ) -> PlantAIUsage:

        usage = response.usage


        if usage is None:

            return PlantAIUsage()


        input_tokens = (
            getattr(
                usage,
                "input_tokens",
                0
            )
            or
            0
        )


        output_tokens = (
            getattr(
                usage,
                "output_tokens",
                0
            )
            or
            0
        )


        total_tokens = (
            getattr(
                usage,
                "total_tokens",
                0
            )
            or
            0
        )


        cached_tokens = 0


        input_details = getattr(
            usage,
            "input_tokens_details",
            None
        )


        if input_details is not None:

            cached_tokens = (
                getattr(
                    input_details,
                    "cached_tokens",
                    0
                )
                or
                0
            )


        reasoning_tokens = 0


        output_details = getattr(
            usage,
            "output_tokens_details",
            None
        )


        if output_details is not None:

            reasoning_tokens = (
                getattr(
                    output_details,
                    "reasoning_tokens",
                    0
                )
                or
                0
            )


        return PlantAIUsage(
            input_tokens=input_tokens,
            cached_input_tokens=cached_tokens,
            output_tokens=output_tokens,
            reasoning_tokens=reasoning_tokens,
            total_tokens=total_tokens
        )


    # ==================================================
    # CALCOLO COSTO
    # ==================================================

    def _calculate_cost(
        self,
        usage: PlantAIUsage
    ) -> PlantAICost:

        pricing = self.MODEL_PRICING.get(
            self.model
        )


        if pricing is None:

            return PlantAICost()


        cached_tokens = min(
            usage.cached_input_tokens,
            usage.input_tokens
        )


        normal_input_tokens = (
            usage.input_tokens
            -
            cached_tokens
        )


        input_cost = (
            normal_input_tokens
            /
            1_000_000
            *
            pricing["input"]
        )


        cached_input_cost = (
            cached_tokens
            /
            1_000_000
            *
            pricing["cached_input"]
        )


        output_cost = (
            usage.output_tokens
            /
            1_000_000
            *
            pricing["output"]
        )


        total_cost = (
            input_cost
            +
            cached_input_cost
            +
            output_cost
        )


        return PlantAICost(

            currency=
                "USD",

            input_price_per_million=
                pricing["input"],

            cached_input_price_per_million=
                pricing["cached_input"],

            output_price_per_million=
                pricing["output"],

            input_cost_usd=
                round(
                    input_cost,
                    8
                ),

            cached_input_cost_usd=
                round(
                    cached_input_cost,
                    8
                ),

            output_cost_usd=
                round(
                    output_cost,
                    8
                ),

            total_cost_usd=
                round(
                    total_cost,
                    8
                )
        )


    # ==================================================
    # ANALISI OPENAI
    # ==================================================

    def analyze(
        self,
        image_path: Path,
        profile: PlantProfile,
        environment_data: dict | None = None,
        soil_data: dict | None = None
    ) -> PlantAIResult:

        client = self._get_client()


        image_data_url = (
            self._image_to_data_url(
                image_path
            )
        )


        context = (
            self._build_context(
                profile=profile,
                environment_data=environment_data,
                soil_data=soil_data
            )
        )


        instructions = """
Sei il modulo di analisi visiva del progetto H2O Piante.

Devi analizzare la fotografia di una pianta insieme
alle informazioni di contesto eventualmente disponibili.

REGOLE:

1. Non dichiarare certa l'identificazione botanica quando
   la fotografia non fornisce elementi sufficienti.

2. Usa identification_confidence_percent per esprimere
   il livello di confidenza dell'identificazione.

3. Distingui chiaramente osservazioni visibili da ipotesi.

4. Non diagnosticare con certezza malattie o parassiti
   usando soltanto una fotografia.

5. I parametri di irrigazione devono essere soltanto
   suggerimenti prudenti.

6. Non assumere che i parametri suggeriti verranno
   utilizzati automaticamente per comandare una pompa.

7. Se una stima non è ragionevolmente supportabile,
   restituisci null per quel valore.

8. Considera temperatura ambiente, umidità dell'aria
   e umidità del terreno quando tali dati sono disponibili.

9. Evita falsa precisione numerica.

10. reasoning_summary deve contenere una breve spiegazione
    destinata all'utente. Non deve contenere una catena
    interna di ragionamento.

11. Scrivi tutti i testi descrittivi in italiano.

12. Quando l'identificazione botanica è sufficientemente
    plausibile e la specie ha un impiego gastronomico o beverage
    riconoscibile, compila anche la sezione Food & Beverage.

13. Per i piatti tipici e per cocktail/bevande indica, solo quando
    ragionevolmente supportabile, il nome e l'area geografica
    tradizionalmente associata: regione e, se pertinente,
    provincia o città. Non inventare associazioni territoriali.

14. Se l'uso gastronomico non è rilevante, non è noto con
    sufficiente affidabilità o l'identificazione della pianta è
    troppo incerta, imposta food_beverage_relevant=false e lascia
    vuote le liste relative a piatti e bevande.

15. Le informazioni Food & Beverage sono esclusivamente
    descrittive e didattiche. Non usare mai la fotografia come
    certificazione di commestibilità, sicurezza alimentare o
    idoneità al consumo. food_safety_warning deve ricordarlo
    esplicitamente e segnalare eventuali cautele note.

16. Puoi proporre anche suggested_exposure, suggested_soil_type,
    suggested_description e suggested_notes, ma SOLO quando il dato
    è ragionevolmente supportato dall'identificazione e dal contesto.

17. suggested_exposure indica l'esposizione IDEALE consigliata
    (es. pieno sole, luce filtrata, mezz'ombra), non la posizione
    fisica attuale della pianta.

18. suggested_soil_type indica un substrato o terreno ADATTO alla
    pianta. Non dichiarare come certo il terreno realmente presente
    se non è noto dal profilo.

19. suggested_description deve essere una breve descrizione botanica
    e morfologica utile al profilo. suggested_notes deve contenere
    solo note pratiche realmente utili.

20. Se uno di questi quattro campi non è supportabile con sufficiente
    affidabilità, restituisci null. È preferibile lasciare il campo
    vuoto piuttosto che inventare un valore.

21. Non proporre mai la posizione fisica della pianta (location):
    resta un dato inserito manualmente dall'utente.
"""


        user_text = f"""
Analizza la fotografia allegata della pianta.

Usa anche il seguente contesto:

{context}

L'obiettivo è:

- proporre una possibile identificazione botanica;
- valutare ciò che è visibile della condizione della pianta;
- segnalare eventuali sintomi osservabili;
- fornire indicazioni prudenti sull'irrigazione;
- proporre, solamente quando ragionevole, valori
  utilizzabili come suggerimenti per il PlantProfile;
- proporre, quando supportabile, esposizione ideale, tipo di terreno,
  descrizione botanica e note pratiche; se non supportabili, lasciarli null;
- quando pertinente, riportare i principali impieghi Food & Beverage,
  includendo parti della pianta utilizzate, piatti tipici, cocktail
  o bevande e relativa associazione geografica regionale/provinciale.

Non modificare alcun profilo.
Non presentare mai l'identificazione fotografica come prova di
commestibilità o sicurezza alimentare.
"""


        response = client.responses.parse(

            model=self.model,

            instructions=instructions,

            input=[
                {
                    "role":
                        "user",

                    "content": [
                        {
                            "type":
                                "input_text",

                            "text":
                                user_text
                        },

                        {
                            "type":
                                "input_image",

                            "image_url":
                                image_data_url,

                            "detail":
                                "high"
                        }
                    ]
                }
            ],

            text_format=
                PlantAIAnalysis
        )


        analysis = (
            response.output_parsed
        )


        if analysis is None:

            raise RuntimeError(
                "OpenAI non ha restituito "
                "un'analisi strutturata valida."
            )


        usage = (
            self._extract_usage(
                response
            )
        )


        cost = (
            self._calculate_cost(
                usage
            )
        )


        return PlantAIResult(
            analysis=analysis,
            usage=usage,
            cost=cost
        )