from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator


CalibrationType = Literal[
    "ARIA",
    "ASCIUTTO",
    "UMIDO",
    "BAGNATO",
    "SATURO"
]


class CalibrationSaveRequest(BaseModel):
    name: CalibrationType


PlantProfileSource = Literal[
    "MANUALE",
    "DATABASE",
    "AI_FOTO"
]


ProfileFieldValueSource = Literal[
    "MANUALE",
    "AI",
    "DATABASE"
]


IrrigationValueSource = Literal[
    "MANUALE",
    "AI",
    "DATABASE",
    "CALCOLATA"
]


class PlantProfilePayload(BaseModel):
    """Payload comune agli endpoint dei profili pianta."""

    model_config = ConfigDict(extra="forbid")

    profile_id: str | None = Field(default=None, min_length=1, max_length=60)

    name: str = Field(min_length=1, max_length=60)
    plant_name: str = Field(min_length=1, max_length=120)
    scientific_name: str | None = Field(default=None, max_length=160)

    description: str | None = Field(default=None, max_length=2000)
    location: str | None = Field(default=None, max_length=200)       # NUOVO
    exposure: str | None = Field(default=None, max_length=200)       # NUOVO
    soil_type: str | None = Field(default=None, max_length=200)      # NUOVO
    notes: str | None = Field(default=None, max_length=3000)
    images: list[str] = Field(default_factory=list)

    description_source: ProfileFieldValueSource | None = None
    exposure_source: ProfileFieldValueSource | None = None
    soil_type_source: ProfileFieldValueSource | None = None
    notes_source: ProfileFieldValueSource | None = None

    minimum_humidity_percent: float | None = Field(default=None, ge=0, le=100)
    target_humidity_percent: float | None = Field(default=None, ge=0, le=100)
    maximum_humidity_percent: float | None = Field(default=None, ge=0, le=100)

    average_water_ml: float | None = Field(default=None, ge=0)       # NUOVO
    water_dose_ml: float | None = Field(default=None, ge=0)
    watering_frequency_days: float | None = Field(default=None, gt=0)

    minimum_humidity_source: IrrigationValueSource | None = None
    target_humidity_source: IrrigationValueSource | None = None
    maximum_humidity_source: IrrigationValueSource | None = None
    average_water_source: IrrigationValueSource | None = None
    water_dose_source: IrrigationValueSource | None = None
    watering_frequency_source: IrrigationValueSource | None = None

    minimum_temperature_c: float | None = None
    maximum_temperature_c: float | None = None
    minimum_air_humidity_percent: float | None = Field(default=None, ge=0, le=100)
    maximum_air_humidity_percent: float | None = Field(default=None, ge=0, le=100)

    source: PlantProfileSource = "MANUALE"

    @field_validator(
        "profile_id",
        "name",
        "plant_name",
        "scientific_name",
        "description",
        "location",
        "exposure",
        "soil_type",
        "notes",
        mode="before"
    )
    @classmethod
    def normalize_text(cls, value):
        if value is None or not isinstance(value, str):
            return value

        cleaned = value.strip()

        if cleaned == "":
            return None

        if cleaned.lower() == "string":
            raise ValueError(
                '"string" è un segnaposto di Swagger e non è un dato valido.'
            )

        return cleaned


class ActivePlantProfileUpdatePayload(BaseModel):
    profile_id: str = Field(min_length=1, max_length=60)