from pydantic import BaseModel, Field


class FoodBeverageReference(BaseModel):
    """Riferimento gastronomico associato alla pianta, quando pertinente."""

    name: str
    region: str | None = None
    province_or_city: str | None = None
    notes: str | None = None


class PlantAIAnalysis(BaseModel):
    """
    Risultato strutturato di un'analisi AI della pianta.

    I valori contenuti in questo modello sono suggerimenti.

    NON modificano automaticamente PlantProfile e NON possono
    comandare direttamente il sistema di irrigazione.
    """

    probable_common_name: str | None = None

    probable_scientific_name: str | None = None

    identification_confidence_percent: float = Field(
        ge=0,
        le=100
    )

    visual_health: str

    visible_symptoms: list[str] = Field(
        default_factory=list
    )

    irrigation_notes: str

    suggested_minimum_humidity_percent: float | None = Field(
        default=None,
        ge=0,
        le=100
    )

    suggested_target_humidity_percent: float | None = Field(
        default=None,
        ge=0,
        le=100
    )

    suggested_maximum_humidity_percent: float | None = Field(
        default=None,
        ge=0,
        le=100
    )

    suggested_water_dose_ml: float | None = Field(
        default=None,
        ge=0
    )

    suggested_watering_frequency_days: float | None = Field(
        default=None,
        gt=0
    )

    # ==================================================
    # PROFILO DESCRITTIVO SUGGERITO
    # ==================================================
    #
    # Questi campi sono sempre opzionali.
    # Se la fotografia e il contesto non permettono una proposta
    # ragionevolmente supportata, il provider deve restituire null.
    # La posizione fisica della pianta resta invece un dato manuale.
    # ==================================================

    suggested_exposure: str | None = None

    suggested_soil_type: str | None = None

    suggested_description: str | None = None

    suggested_notes: str | None = None

    suggested_temperature_min_c: float | None = None

    suggested_temperature_max_c: float | None = None

    suggested_air_humidity_min_percent: float | None = Field(
        default=None,
        ge=0,
        le=100
    )

    suggested_air_humidity_max_percent: float | None = Field(
        default=None,
        ge=0,
        le=100
    )

    # ==================================================
    # FOOD & BEVERAGE
    # ==================================================

    food_beverage_relevant: bool = False

    culinary_parts_used: list[str] = Field(
        default_factory=list
    )

    typical_dishes: list[FoodBeverageReference] = Field(
        default_factory=list
    )

    cocktails_and_beverages: list[FoodBeverageReference] = Field(
        default_factory=list
    )

    culinary_context_notes: str | None = None

    food_safety_warning: str = (
        "Informazioni gastronomiche a scopo descrittivo e didattico. "
        "Non usare l'identificazione fotografica AI per stabilire "
        "commestibilità o sicurezza per il consumo."
    )

    warnings: list[str] = Field(
        default_factory=list
    )

    reasoning_summary: str
