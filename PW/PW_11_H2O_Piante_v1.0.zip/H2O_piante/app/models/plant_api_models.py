from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator


PlantProfileSource = Literal[
    "MANUALE",
    "AI_FOTO",
    "DATABASE"
]


class ActivePlantProfileUpdatePayload(BaseModel):
    """
    Payload compatibile con la dashboard attuale.
    Non richiede profile_id e mantiene il contratto API già collaudato.
    """

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "name": "PIANTA_1",
                "plant_name": "NON IDENTIFICATA",
                "minimum_humidity_percent": None,
                "target_humidity_percent": None,
                "maximum_humidity_percent": None,
                "water_dose_ml": None,
                "source": "MANUALE"
            }
        }
    )

    name: str = Field(
        min_length=1,
        max_length=80
    )

    plant_name: str = Field(
        min_length=1,
        max_length=120
    )

    minimum_humidity_percent: float | None = Field(
        default=None,
        ge=0,
        le=100
    )

    target_humidity_percent: float | None = Field(
        default=None,
        ge=0,
        le=100
    )

    maximum_humidity_percent: float | None = Field(
        default=None,
        ge=0,
        le=100
    )

    water_dose_ml: float | None = Field(
        default=None,
        ge=0
    )

    source: PlantProfileSource = "MANUALE"


    @field_validator(
        "name",
        "plant_name"
    )
    @classmethod
    def validate_required_text(
        cls,
        value: str
    ) -> str:

        cleaned = value.strip()

        if not cleaned:

            raise ValueError(
                "Il valore non può essere vuoto."
            )


        if cleaned.lower() == "string":

            raise ValueError(
                'Il valore "string" è un segnaposto di Swagger.'
            )


        return cleaned


class PlantProfilePayload(BaseModel):
    """
    Payload completo per la gestione multi-profilo.
    """

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "profile_id": "PIANTA_2",
                "name": "PIANTA_2",
                "plant_name": "NON IDENTIFICATA",
                "scientific_name": None,
                "description": None,
                "minimum_humidity_percent": None,
                "target_humidity_percent": None,
                "maximum_humidity_percent": None,
                "water_dose_ml": None,
                "watering_frequency_days": None,
                "minimum_temperature_c": None,
                "maximum_temperature_c": None,
                "minimum_air_humidity_percent": None,
                "maximum_air_humidity_percent": None,
                "images": [],
                "notes": None,
                "source": "MANUALE"
            }
        }
    )

    profile_id: str = Field(
        min_length=1,
        max_length=80
    )

    name: str = Field(
        min_length=1,
        max_length=80
    )

    plant_name: str = Field(
        min_length=1,
        max_length=120
    )

    scientific_name: str | None = Field(
        default=None,
        max_length=160
    )

    description: str | None = None


    minimum_humidity_percent: float | None = Field(
        default=None,
        ge=0,
        le=100
    )

    target_humidity_percent: float | None = Field(
        default=None,
        ge=0,
        le=100
    )

    maximum_humidity_percent: float | None = Field(
        default=None,
        ge=0,
        le=100
    )


    water_dose_ml: float | None = Field(
        default=None,
        ge=0
    )

    watering_frequency_days: float | None = Field(
        default=None,
        gt=0
    )


    minimum_temperature_c: float | None = None

    maximum_temperature_c: float | None = None


    minimum_air_humidity_percent: float | None = Field(
        default=None,
        ge=0,
        le=100
    )

    maximum_air_humidity_percent: float | None = Field(
        default=None,
        ge=0,
        le=100
    )


    images: list[str] = Field(
        default_factory=list
    )

    notes: str | None = None


    source: PlantProfileSource = "MANUALE"


    @field_validator(
        "profile_id",
        "name",
        "plant_name"
    )
    @classmethod
    def validate_required_text(
        cls,
        value: str
    ) -> str:

        cleaned = value.strip()


        if not cleaned:

            raise ValueError(
                "Il valore non può essere vuoto."
            )


        if cleaned.lower() == "string":

            raise ValueError(
                'Il valore "string" è un segnaposto di Swagger.'
            )


        return cleaned