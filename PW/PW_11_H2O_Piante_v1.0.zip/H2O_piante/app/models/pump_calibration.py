from dataclasses import dataclass
from datetime import datetime

from pydantic import BaseModel, Field


@dataclass
class PumpCalibrationMeasurement:
    """
    Singola misura sperimentale della portata
    del circuito pompa + tubo + gocciolatoio.
    """

    measurement_id: str

    duration_s: float

    volume_ml: float

    voltage_v: float

    flow_ml_s: float

    timestamp: str


    @classmethod
    def create(
        cls,
        measurement_id: str,
        duration_s: float,
        volume_ml: float,
        voltage_v: float
    ):

        flow_ml_s = (
            volume_ml
            /
            duration_s
        )


        return cls(

            measurement_id=
                measurement_id,

            duration_s=
                round(
                    duration_s,
                    3
                ),

            volume_ml=
                round(
                    volume_ml,
                    3
                ),

            voltage_v=
                round(
                    voltage_v,
                    2
                ),

            flow_ml_s=
                round(
                    flow_ml_s,
                    4
                ),

            timestamp=
                datetime.now()
                .isoformat(
                    timespec="seconds"
                )
        )


class PumpCalibrationPayload(BaseModel):
    """
    Payload ricevuto dalla GUI/API
    per registrare una nuova misura.
    """

    duration_s: float = Field(
        gt=0,
        le=120
    )

    volume_ml: float = Field(
        gt=0,
        le=5000
    )

    voltage_v: float = Field(
        default=5.0,
        gt=0,
        le=24
    )