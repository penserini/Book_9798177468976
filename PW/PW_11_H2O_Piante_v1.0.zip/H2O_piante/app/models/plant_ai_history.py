from pydantic import BaseModel, Field

from app.models.plant_ai_analysis import PlantAIAnalysis
from app.models.plant_ai_result import PlantAICost, PlantAIUsage


class PlantAIHistoryEntry(BaseModel):
    """
    Voce persistente dello storico delle analisi AI di una pianta.

    Lo storico mantiene separato il risultato AI dal PlantProfile:
    i suggerimenti restano consultabili nel tempo e non modificano
    automaticamente i dati ufficiali della pianta.
    """

    analysis_id: str

    profile_id: str

    image_index: int = Field(
        ge=0
    )

    image_url: str

    timestamp: str

    provider: str

    model: str

    analysis: PlantAIAnalysis

    usage: PlantAIUsage

    cost: PlantAICost
