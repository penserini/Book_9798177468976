from dataclasses import dataclass
from datetime import datetime


@dataclass
class EnvironmentReading:
    """
    Rappresenta una singola misura delle condizioni
    ambientali attorno alla pianta.

    Il modello è indipendente dal sensore utilizzato:
    DHT11, SHT31 o altri dispositivi futuri.
    """

    temperature_c: float
    humidity_percent: float
    timestamp: str


    @classmethod
    def create(
        cls,
        temperature_c: float,
        humidity_percent: float
    ):
        """
        Crea una misura ambientale aggiungendo
        automaticamente data e ora.
        """

        return cls(
            temperature_c=round(
                temperature_c,
                2
            ),

            humidity_percent=round(
                humidity_percent,
                2
            ),

            timestamp=datetime.now().isoformat(
                timespec="seconds"
            )
        )