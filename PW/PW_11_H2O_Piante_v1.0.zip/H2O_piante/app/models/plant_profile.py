from dataclasses import dataclass, field


@dataclass
class PlantProfile:
    """Profilo persistente di una pianta gestita da H2O Piante."""

    # Identificazione
    profile_id: str
    name: str
    plant_name: str
    scientific_name: str | None = None

    # Descrizione
    description: str | None = None
    location: str | None = None
    exposure: str | None = None
    soil_type: str | None = None
    notes: str | None = None
    images: list[str] = field(default_factory=list)

    # Provenienza dei campi descrittivi modificabili dall'AI.
    # Valori previsti: MANUALE, AI, DATABASE.
    description_source: str | None = None
    exposure_source: str | None = None
    soil_type_source: str | None = None
    notes_source: str | None = None

    # Umidità del terreno
    minimum_humidity_percent: float | None = None
    target_humidity_percent: float | None = None
    maximum_humidity_percent: float | None = None

    # Irrigazione
    average_water_ml: float | None = None
    water_dose_ml: float | None = None
    watering_frequency_days: float | None = None

    # Provenienza dei singoli parametri di irrigazione.
    # Valori previsti: MANUALE, AI, DATABASE, CALCOLATA.
    minimum_humidity_source: str | None = None
    target_humidity_source: str | None = None
    maximum_humidity_source: str | None = None
    average_water_source: str | None = None
    water_dose_source: str | None = None
    watering_frequency_source: str | None = None

    # Microclima ideale
    minimum_temperature_c: float | None = None
    maximum_temperature_c: float | None = None
    minimum_air_humidity_percent: float | None = None
    maximum_air_humidity_percent: float | None = None

    # Provenienza generale del profilo
    source: str = "MANUALE"
