from pydantic import BaseModel

from app.models.plant_ai_analysis import PlantAIAnalysis


class PlantAIUsage(BaseModel):
    """
    Consumo di token della singola analisi AI.
    """

    input_tokens: int = 0

    cached_input_tokens: int = 0

    output_tokens: int = 0

    reasoning_tokens: int = 0

    total_tokens: int = 0


class PlantAICost(BaseModel):
    """
    Costo stimato della singola richiesta.

    I prezzi sono espressi in USD per milione di token.
    """

    currency: str = "USD"

    input_price_per_million: float | None = None

    cached_input_price_per_million: float | None = None

    output_price_per_million: float | None = None

    input_cost_usd: float | None = None

    cached_input_cost_usd: float | None = None

    output_cost_usd: float | None = None

    total_cost_usd: float | None = None


class PlantAIResult(BaseModel):
    """
    Risultato completo restituito da un PlantAIProvider.

    Mantiene separati:
    - contenuto dell'analisi;
    - consumo;
    - costo.
    """

    analysis: PlantAIAnalysis

    usage: PlantAIUsage

    cost: PlantAICost