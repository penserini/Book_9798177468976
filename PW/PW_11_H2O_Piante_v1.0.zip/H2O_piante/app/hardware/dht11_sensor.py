from app.hardware.environment_sensor import EnvironmentSensor
from app.hardware.serial_connection import SerialConnection

from app.models.environment_reading import EnvironmentReading


class DHT11Sensor(
    EnvironmentSensor
):

    """
    Implementazione concreta di EnvironmentSensor
    per un DHT11 collegato alla ESP32.

    Questa classe viene mantenuta come implementazione
    alternativa/di backup.

    Python non comunica direttamente con il DHT11.

    La catena è:

    DHT11
       ↓
    ESP32
       ↓
    protocollo seriale ENV
       ↓
    SerialConnection
       ↓
    DHT11Sensor
    """


    def __init__(
        self,
        connection: SerialConnection
    ):

        self.connection = (
            connection
        )


    # ==================================================
    # NOME
    # ==================================================

    def get_name(
        self
    ) -> str:

        return "DHT11"


    # ==================================================
    # DISPONIBILITÀ
    # ==================================================

    def is_available(
        self
    ) -> bool:

        return (
            self.connection
            .is_connected()
        )


    # ==================================================
    # LETTURA
    # ==================================================

    def read(
        self
    ) -> EnvironmentReading:

        if not self.is_available():

            raise RuntimeError(
                "ESP32 non connessa."
            )


        environment_data = (
            self.connection
            .read_environment()
        )


        temperature = (
            environment_data[
                "temperature_c"
            ]
        )


        humidity = (
            environment_data[
                "humidity_percent"
            ]
        )


        return (
            EnvironmentReading
            .create(
                temperature_c=
                    temperature,

                humidity_percent=
                    humidity
            )
        )
