from abc import ABC, abstractmethod

from app.models.environment_reading import EnvironmentReading


class EnvironmentSensor(ABC):
    """
    Interfaccia astratta comune a tutti i sensori
    ambientali utilizzabili dal progetto H2O Piante.

    Il resto dell'applicazione non deve sapere
    se il dispositivo concreto è:

    - DHT11
    - SHT31
    - BME280
    - un sensore futuro

    Deve conoscere solamente questa interfaccia.
    """


    @abstractmethod
    def get_name(
        self
    ) -> str:
        """
        Restituisce il nome del sensore concreto.
        """
        pass


    @abstractmethod
    def is_available(
        self
    ) -> bool:
        """
        Indica se il sensore è attualmente
        disponibile per una misura.
        """
        pass


    @abstractmethod
    def read(
        self
    ) -> EnvironmentReading:
        """
        Acquisisce temperatura e umidità ambiente.

        Deve restituire un EnvironmentReading.
        """
        pass