from app.hardware.connection import DeviceConnection
from app.hardware.environment_sensor import EnvironmentSensor
from app.models.environment_reading import EnvironmentReading


class SHT31Sensor(EnvironmentSensor):
    """
    Implementazione concreta di EnvironmentSensor
    per SHT31 collegato alla ESP32 tramite I2C.

    La modalità con cui Python raggiunge la ESP32
    può essere seriale USB oppure Wi-Fi/HTTP.
    """

    def __init__(
        self,
        connection: DeviceConnection
    ):
        self.connection = connection

    def get_name(self) -> str:
        return "SHT31"

    def is_available(self) -> bool:
        return self.connection.is_connected()

    def read(self) -> EnvironmentReading:
        if not self.is_available():
            raise RuntimeError(
                "ESP32 non connessa."
            )

        environment_data = (
            self.connection.read_environment()
        )

        return EnvironmentReading.create(
            temperature_c=environment_data["temperature_c"],
            humidity_percent=environment_data["humidity_percent"]
        )
