from abc import ABC, abstractmethod


class DeviceConnection(ABC):
    """
    Interfaccia astratta comune per tutte le modalità
    di comunicazione con ESP32.

    Le implementazioni concrete possono essere, ad esempio:
    - SerialConnection: USB/COM
    - HttpConnection: Wi-Fi/HTTP
    """

    @abstractmethod
    def connect(self) -> None:
        pass

    @abstractmethod
    def disconnect(self) -> None:
        pass

    @abstractmethod
    def is_connected(self) -> bool:
        pass

    @abstractmethod
    def ping(self) -> bool:
        pass

    @abstractmethod
    def read_sensor(self, channel: int) -> int:
        pass

    @abstractmethod
    def read_environment(self) -> dict:
        pass

    @abstractmethod
    def run_pump(self, duration_ms: int) -> dict:
        pass

    @abstractmethod
    def stop_pump(self) -> dict:
        pass

    @abstractmethod
    def get_pump_status(self) -> dict:
        pass
