import threading
import time

import serial

from app.hardware.connection import DeviceConnection


class SerialConnection(DeviceConnection):
    """
    Connessione seriale USB verso ESP32.

    Tutte le transazioni richiesta/risposta condividono
    lo stesso RLock per evitare interferenze tra:

    - heartbeat PING
    - READ ADC
    - ENV
    - PUMP
    - PUMP_STOP
    - PUMP_STATUS
    """

    def __init__(
        self,
        port: str,
        baudrate: int = 115200
    ):

        self.port = port

        self.baudrate = baudrate

        self._serial = None

        self._io_lock = threading.RLock()


    # ==================================================
    # CONNESSIONE
    # ==================================================

    def connect(
        self
    ) -> None:

        with self._io_lock:

            if self.is_connected():
                return


            self._serial = serial.Serial(
                port=self.port,
                baudrate=self.baudrate,
                timeout=0.2
            )


            # Alcune ESP32 effettuano un reset
            # all'apertura della porta seriale.
            time.sleep(1)


            # Elimina eventuali dati prodotti
            # durante il boot della ESP32.
            self._serial.reset_input_buffer()


    # ==================================================
    # DISCONNESSIONE
    # ==================================================

    def disconnect(
        self
    ) -> None:

        with self._io_lock:

            if (
                self._serial is not None
                and
                self._serial.is_open
            ):

                self._serial.close()


            self._serial = None


    # ==================================================
    # STATO PORTA
    # ==================================================

    def is_connected(
        self
    ) -> bool:

        return (
            self._serial is not None
            and
            self._serial.is_open
        )


    # ==================================================
    # PREPARAZIONE TRANSAZIONE
    # ==================================================

    def _prepare_transaction(
        self
    ) -> None:

        if not self.is_connected():

            raise RuntimeError(
                "Connessione seriale non attiva."
            )


        # Pulizia effettuata PRIMA
        # dell'invio del nuovo comando.
        self._serial.reset_input_buffer()


    # ==================================================
    # INVIO COMANDO
    # ==================================================

    def _send_command(
        self,
        command: str
    ) -> None:

        if not self.is_connected():

            raise RuntimeError(
                "Connessione seriale non attiva."
            )


        payload = (
            command.strip()
            +
            "\n"
        )


        self._serial.write(
            payload.encode(
                "utf-8"
            )
        )


        self._serial.flush()


    # ==================================================
    # ATTESA RISPOSTA
    # ==================================================

    def _wait_for_response(
        self,
        accepted_prefixes: tuple[str, ...],
        timeout_seconds: float = 3.0
    ) -> str:

        if not self.is_connected():

            raise RuntimeError(
                "Connessione seriale non attiva."
            )


        deadline = (
            time.monotonic()
            +
            timeout_seconds
        )


        while (
            time.monotonic()
            <
            deadline
        ):

            raw_line = (
                self._serial.readline()
            )


            # Una singola lettura vuota non deve
            # terminare la transazione.
            if not raw_line:
                continue


            response = (
                raw_line
                .decode(
                    "utf-8",
                    errors="ignore"
                )
                .strip()
            )


            if not response:
                continue


            if response.startswith(
                "ERROR"
            ):

                raise RuntimeError(
                    f"Errore ESP32: {response}"
                )


            for prefix in accepted_prefixes:

                if response.startswith(
                    prefix
                ):

                    return response


            # Se arrivasse una riga non pertinente,
            # continuiamo ad attendere la risposta
            # del comando corrente.


        raise TimeoutError(
            "Nessuna risposta ricevuta dalla ESP32."
        )


    # ==================================================
    # PING
    # ==================================================

    def ping(
        self
    ) -> bool:

        if not self.is_connected():
            return False


        with self._io_lock:

            try:

                self._prepare_transaction()


                self._send_command(
                    "PING"
                )


                response = (
                    self._wait_for_response(
                        accepted_prefixes=(
                            "PONG",
                        ),
                        timeout_seconds=2.0
                    )
                )


                return (
                    response
                    ==
                    "PONG"
                )


            except Exception:

                return False


    # ==================================================
    # LETTURA ADC
    # ==================================================

    def read_sensor(
        self,
        channel: int
    ) -> int:

        if (
            channel < 0
            or
            channel > 3
        ):

            raise ValueError(
                "Canale ADS1115 non valido."
            )


        with self._io_lock:

            self._prepare_transaction()


            self._send_command(
                f"READ {channel}"
            )


            expected_prefix = (
                f"VALUE {channel} "
            )


            response = (
                self._wait_for_response(
                    accepted_prefixes=(
                        expected_prefix,
                    ),
                    timeout_seconds=3.0
                )
            )


            value_text = (
                response[
                    len(
                        expected_prefix
                    ):
                ]
                .strip()
            )


            return int(
                value_text
            )


    # ==================================================
    # LETTURA AMBIENTALE
    # ==================================================

    def read_environment(
        self
    ) -> dict:

        with self._io_lock:

            self._prepare_transaction()


            self._send_command(
                "ENV"
            )


            response = (
                self._wait_for_response(
                    accepted_prefixes=(
                        "ENV ",
                    ),
                    timeout_seconds=3.0
                )
            )


            parts = (
                response.split()
            )


            if (
                len(parts)
                != 3
            ):

                raise RuntimeError(
                    "Risposta ENV non valida."
                )


            return {
                "temperature_c":
                    float(
                        parts[1]
                    ),

                "humidity_percent":
                    float(
                        parts[2]
                    )
            }


    # ==================================================
    # AVVIO POMPA
    # ==================================================

    def run_pump(
        self,
        duration_ms: int
    ) -> dict:

        if (
            duration_ms <= 0
        ):

            raise ValueError(
                "La durata deve essere maggiore di zero."
            )


        with self._io_lock:

            self._prepare_transaction()


            self._send_command(
                f"PUMP {duration_ms}"
            )


            response = (
                self._wait_for_response(
                    accepted_prefixes=(
                        "PUMP_OK ",
                    ),
                    timeout_seconds=3.0
                )
            )


            parts = (
                response.split()
            )


            if (
                len(parts)
                != 2
            ):

                raise RuntimeError(
                    "Risposta PUMP non valida."
                )


            return {
                "running":
                    True,

                "duration_ms":
                    int(
                        parts[1]
                    )
            }


    # ==================================================
    # STOP POMPA
    # ==================================================

    def stop_pump(
        self
    ) -> dict:

        with self._io_lock:

            self._prepare_transaction()


            self._send_command(
                "PUMP_STOP"
            )


            response = (
                self._wait_for_response(
                    accepted_prefixes=(
                        "PUMP_STOPPED",
                    ),
                    timeout_seconds=2.0
                )
            )


            if (
                response
                !=
                "PUMP_STOPPED"
            ):

                raise RuntimeError(
                    "Risposta PUMP_STOP non valida."
                )


            return {
                "running":
                    False,

                "remaining_ms":
                    0
            }


    # ==================================================
    # STATO POMPA
    # ==================================================

    def get_pump_status(
        self
    ) -> dict:

        with self._io_lock:

            self._prepare_transaction()


            self._send_command(
                "PUMP_STATUS"
            )


            response = (
                self._wait_for_response(
                    accepted_prefixes=(
                        "PUMP_STOPPED",
                        "PUMP_RUNNING "
                    ),
                    timeout_seconds=2.0
                )
            )


            if (
                response
                ==
                "PUMP_STOPPED"
            ):

                return {
                    "running":
                        False,

                    "remaining_ms":
                        0
                }


            if response.startswith(
                "PUMP_RUNNING "
            ):

                parts = (
                    response.split()
                )


                if (
                    len(parts)
                    != 2
                ):

                    raise RuntimeError(
                        "Risposta PUMP_STATUS non valida."
                    )


                return {
                    "running":
                        True,

                    "remaining_ms":
                        int(
                            parts[1]
                        )
                }


            raise RuntimeError(
                "Risposta PUMP_STATUS non riconosciuta."
            )