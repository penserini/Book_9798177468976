import json
import threading
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from app.hardware.connection import DeviceConnection


class HttpConnection(DeviceConnection):
    """
    Connessione Wi-Fi/HTTP verso ESP32.

    Il browser continua a parlare soltanto con FastAPI.
    È il backend Python che usa questa classe per parlare
    con la ESP32 sulla rete locale.
    """

    def __init__(
        self,
        base_url: str,
        timeout_seconds: float = 2.0
    ):
        self.base_url = base_url.rstrip("/")
        self.timeout_seconds = timeout_seconds
        self._connected = False
        self._io_lock = threading.RLock()

    def connect(self) -> None:
        with self._io_lock:
            if self.ping():
                self._connected = True
                return

            self._connected = False
            raise RuntimeError(
                "ESP32 non raggiungibile via Wi-Fi/HTTP."
            )

    def disconnect(self) -> None:
        with self._io_lock:
            self._connected = False

    def is_connected(self) -> bool:
        return self._connected

    def ping(self) -> bool:
        with self._io_lock:
            try:
                data = self._request_json(
                    method="GET",
                    path="/ping"
                )

                if data.get("success") is True:
                    self._connected = True
                    return True

            except Exception:
                pass

            return False

    def read_sensor(self, channel: int) -> int:
        if channel < 0 or channel > 3:
            raise ValueError(
                "Canale ADS1115 non valido."
            )

        self._require_connected()

        with self._io_lock:
            data = self._request_json(
                method="GET",
                path="/sensor",
                query={"channel": channel}
            )

            return int(data["value"])

    def read_environment(self) -> dict:
        self._require_connected()

        with self._io_lock:
            data = self._request_json(
                method="GET",
                path="/environment"
            )

            return {
                "temperature_c": float(data["temperature_c"]),
                "humidity_percent": float(data["humidity_percent"])
            }

    def run_pump(self, duration_ms: int) -> dict:
        if duration_ms <= 0:
            raise ValueError(
                "La durata deve essere maggiore di zero."
            )

        self._require_connected()

        with self._io_lock:
            data = self._request_json(
                method="POST",
                path="/pump/run",
                query={"duration_ms": duration_ms}
            )

            return {
                "running": bool(data["running"]),
                "duration_ms": int(data["duration_ms"])
            }

    def stop_pump(self) -> dict:
        self._require_connected()

        with self._io_lock:
            data = self._request_json(
                method="POST",
                path="/pump/stop"
            )

            return {
                "running": bool(data["running"]),
                "remaining_ms": int(data["remaining_ms"])
            }

    def get_pump_status(self) -> dict:
        self._require_connected()

        with self._io_lock:
            data = self._request_json(
                method="GET",
                path="/pump/status"
            )

            return {
                "running": bool(data["running"]),
                "remaining_ms": int(data["remaining_ms"])
            }

    def _require_connected(self) -> None:
        if not self.is_connected():
            raise RuntimeError(
                "Connessione Wi-Fi/HTTP non attiva."
            )

    def _request_json(
        self,
        method: str,
        path: str,
        query: dict | None = None
    ) -> dict:
        url = self.base_url + path

        if query:
            url += "?" + urlencode(query)

        request = Request(
            url=url,
            method=method,
            headers={
                "Accept": "application/json"
            }
        )

        try:
            with urlopen(
                request,
                timeout=self.timeout_seconds
            ) as response:
                payload = response.read().decode("utf-8")

        except HTTPError as error:
            body = error.read().decode(
                "utf-8",
                errors="ignore"
            )
            raise RuntimeError(
                f"Errore HTTP ESP32 {error.code}: {body}"
            ) from error

        except URLError as error:
            raise RuntimeError(
                f"ESP32 non raggiungibile: {error.reason}"
            ) from error

        except TimeoutError as error:
            raise RuntimeError(
                "Timeout nella comunicazione Wi-Fi con ESP32."
            ) from error

        try:
            data = json.loads(payload)
        except json.JSONDecodeError as error:
            raise RuntimeError(
                f"Risposta JSON ESP32 non valida: {payload}"
            ) from error

        if data.get("success") is False:
            raise RuntimeError(
                data.get("message")
                or
                "Errore restituito dalla ESP32."
            )

        return data
