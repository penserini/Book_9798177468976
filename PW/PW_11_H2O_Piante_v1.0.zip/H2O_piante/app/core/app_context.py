import os

from app.hardware.http_connection import HttpConnection
from app.hardware.serial_connection import SerialConnection
from app.hardware.sht31_sensor import SHT31Sensor

from app.services.calibration_service import CalibrationService
from app.services.irrigation_service import IrrigationService
from app.services.plant_profile_service import PlantProfileService
from app.services.environment_service import EnvironmentService
from app.services.plant_ai_service import PlantAIService
from app.services.plant_ai_history_service import PlantAIHistoryService
from app.services.pump_calibration_service import PumpCalibrationService
from app.services.pump_service import PumpService

from app.ai.openai_plant_ai_provider import OpenAIPlantAIProvider


class AppContext:
    """
    Stato condiviso dell'applicazione H2O Piante.

    La modalità di collegamento alla ESP32 viene scelta
    tramite variabile d'ambiente:

    H2O_CONNECTION_MODE=serial
    oppure
    H2O_CONNECTION_MODE=wifi
    """

    def __init__(self):
        self.connection_mode = (
            os.getenv(
                "H2O_CONNECTION_MODE",
                "serial"
            )
            .strip()
            .lower()
        )

        if self.connection_mode == "wifi":
            self.connection_target = os.getenv(
                "H2O_ESP32_URL",
                "http://192.168.1.100"
            ).strip()

            self.connection = HttpConnection(
                base_url=self.connection_target,
                timeout_seconds=2.0
            )

        elif self.connection_mode == "serial":
            self.connection_target = os.getenv(
                "H2O_SERIAL_PORT",
                "COM3"
            ).strip()

            self.connection = SerialConnection(
                port=self.connection_target,
                baudrate=115200
            )

        else:
            raise ValueError(
                (
                    "H2O_CONNECTION_MODE non valido. "
                    "Usare 'serial' oppure 'wifi'."
                )
            )

        self.calibration_service = CalibrationService()

        self.plant_profile_service = PlantProfileService()

        self.irrigation_service = IrrigationService(
            profile=(
                self.plant_profile_service.get_profile()
            )
        )

        self.pump_calibration_service = (
            PumpCalibrationService()
        )

        self.pump_service = PumpService(
            connection=self.connection,
            calibration_service=(
                self.pump_calibration_service
            )
        )

        self.environment_sensor = SHT31Sensor(
            connection=self.connection
        )

        self.environment_service = EnvironmentService(
            sensor=self.environment_sensor
        )

        self.plant_ai_provider = OpenAIPlantAIProvider()

        self.plant_ai_service = PlantAIService(
            provider=self.plant_ai_provider
        )

        self.plant_ai_history_service = (
            PlantAIHistoryService()
        )

        self.last_measurements: list[int] = []
        self.last_measurements_saved: bool = False

        self.connection_failures: int = 0
        self.max_connection_failures: int = 3

    def mark_connection_alive(self) -> None:
        self.connection_failures = 0

    def invalidate_pending_calibration(self) -> None:
        self.last_measurements = []
        self.last_measurements_saved = False

    def check_esp32_connection(self) -> bool:
        if not self.connection.is_connected():
            self.connection_failures = 0
            return False

        try:
            if self.connection.ping():
                self.connection_failures = 0
                return True
        except Exception:
            pass

        self.connection_failures += 1

        if (
            self.connection_failures
            <
            self.max_connection_failures
        ):
            return True

        self.connection.disconnect()
        self.connection_failures = 0

        return False
