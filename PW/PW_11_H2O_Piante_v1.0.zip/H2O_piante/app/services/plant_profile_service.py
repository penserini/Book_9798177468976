import json

from dataclasses import asdict, fields
from pathlib import Path

from app.models.plant_profile import PlantProfile


class PlantProfileService:
    """Gestione persistente multi-profilo in data/plants.json."""

    def __init__(self):
        project_root = Path(__file__).resolve().parents[2]

        self.data_file = project_root / "data" / "plants.json"
        self.legacy_data_file = project_root / "data" / "plant_profile.json"

        self.profiles: dict[str, PlantProfile] = {}
        self.active_profile_id: str | None = None

        self.load()

    @staticmethod
    def _profile_from_dict(profile_id: str, data: dict) -> PlantProfile:
        """
        Carica anche JSON creati con versioni precedenti:
        i nuovi campi mancanti assumono i default della dataclass.
        """
        allowed = {item.name for item in fields(PlantProfile)}

        filtered = {
            key: value
            for key, value in data.items()
            if key in allowed
        }

        filtered["profile_id"] = profile_id
        filtered.setdefault("name", profile_id)
        filtered.setdefault("plant_name", "NON IDENTIFICATA")

        return PlantProfile(**filtered)

    def load(self) -> None:
        if self.data_file.exists():
            with open(self.data_file, "r", encoding="utf-8") as file:
                raw = json.load(file)

            raw_profiles = raw.get("profiles", {})

            self.profiles = {
                profile_id: self._profile_from_dict(profile_id, profile_data)
                for profile_id, profile_data in raw_profiles.items()
            }

            self.active_profile_id = raw.get("active_profile_id")

            if self.active_profile_id not in self.profiles:
                self.active_profile_id = next(iter(self.profiles), None)

            return

        self._migrate_legacy_profile()

    def _migrate_legacy_profile(self) -> None:
        if self.legacy_data_file.exists():
            with open(self.legacy_data_file, "r", encoding="utf-8") as file:
                legacy = json.load(file)

            profile_id = (
                legacy.get("profile_id")
                or legacy.get("name")
                or "PIANTA_1"
            )

            profile = self._profile_from_dict(profile_id, legacy)

        else:
            profile_id = "PIANTA_1"

            profile = PlantProfile(
                profile_id=profile_id,
                name=profile_id,
                plant_name="NON IDENTIFICATA"
            )

        self.profiles = {profile_id: profile}
        self.active_profile_id = profile_id
        self.save()

    def save(self) -> None:
        self.data_file.parent.mkdir(parents=True, exist_ok=True)

        payload = {
            "active_profile_id": self.active_profile_id,

            "profiles": {
                profile_id: asdict(profile)
                for profile_id, profile in self.profiles.items()
            }
        }

        with open(self.data_file, "w", encoding="utf-8") as file:
            json.dump(
                payload,
                file,
                ensure_ascii=False,
                indent=4
            )

    # ==================================================
    # COMPATIBILITÀ CON /api/plant/profile
    # ==================================================

    def get_profile(self) -> PlantProfile:
        if (
            self.active_profile_id is None
            or self.active_profile_id not in self.profiles
        ):
            raise RuntimeError("Nessun profilo pianta attivo.")

        return self.profiles[self.active_profile_id]

    def update_profile(self, **values) -> PlantProfile:
        current = self.get_profile()

        profile_id = current.profile_id

        updated_data = asdict(current)
        updated_data.update(values)
        updated_data["profile_id"] = profile_id

        updated = self._profile_from_dict(
            profile_id,
            updated_data
        )

        self.profiles[profile_id] = updated

        self.save()

        return updated

    # ==================================================
    # MULTI-PROFILO
    # ==================================================

    def get_profiles(self) -> dict[str, PlantProfile]:
        return self.profiles.copy()

    def get_profile_by_id(self, profile_id: str) -> PlantProfile | None:
        return self.profiles.get(profile_id)

    def create_profile(self, profile: PlantProfile) -> PlantProfile:
        profile_id = profile.profile_id.strip()

        if profile_id in self.profiles:
            raise ValueError(
                f"Il profilo {profile_id} esiste già."
            )

        profile.profile_id = profile_id
        self.profiles[profile_id] = profile

        if self.active_profile_id is None:
            self.active_profile_id = profile_id

        self.save()

        return profile

    def update_profile_by_id(
        self,
        profile_id: str,
        profile: PlantProfile
    ) -> PlantProfile:

        if profile_id not in self.profiles:
            raise KeyError(
                f"Profilo {profile_id} non trovato."
            )

        profile.profile_id = profile_id

        self.profiles[profile_id] = profile

        self.save()

        return profile

    def activate_profile(self, profile_id: str) -> PlantProfile:
        if profile_id not in self.profiles:
            raise KeyError(
                f"Profilo {profile_id} non trovato."
            )

        self.active_profile_id = profile_id

        self.save()

        return self.profiles[profile_id]

    def delete_profile(self, profile_id: str) -> None:
        if profile_id not in self.profiles:
            raise KeyError(
                f"Profilo {profile_id} non trovato."
            )

        if len(self.profiles) <= 1:
            raise ValueError(
                "Non è possibile eliminare l'unico profilo presente."
            )

        del self.profiles[profile_id]

        if self.active_profile_id == profile_id:
            self.active_profile_id = next(
                iter(self.profiles)
            )

        self.save()