from app.hardware.environment_sensor import EnvironmentSensor
from app.models.environment_reading import EnvironmentReading


class EnvironmentService:
    """
    Servizio applicativo per la gestione
    delle condizioni ambientali della pianta.

    Il servizio dipende dall'interfaccia astratta
    EnvironmentSensor e non da DHT11 o SHT31.
    """


    def __init__(
        self,
        sensor: EnvironmentSensor | None = None
    ):

        self.sensor = sensor

        self.last_reading: EnvironmentReading | None = None


    # ==================================================
    # CONFIGURAZIONE SENSORE
    # ==================================================

    def set_sensor(
        self,
        sensor: EnvironmentSensor
    ) -> None:
        """
        Permette di sostituire il sensore concreto
        senza modificare il servizio.
        """

        self.sensor = sensor


    # ==================================================
    # CONTROLLO CONFIGURAZIONE
    # ==================================================

    def has_sensor(
        self
    ) -> bool:

        return (
            self.sensor
            is not None
        )


    # ==================================================
    # NOME SENSORE
    # ==================================================

    def get_sensor_name(
        self
    ) -> str | None:

        if self.sensor is None:

            return None


        return self.sensor.get_name()


    # ==================================================
    # DISPONIBILITÀ
    # ==================================================

    def is_sensor_available(
        self
    ) -> bool:

        if self.sensor is None:

            return False


        try:

            return self.sensor.is_available()

        except Exception:

            return False


    # ==================================================
    # LETTURA
    # ==================================================

    def read_environment(
        self
    ) -> EnvironmentReading:

        if self.sensor is None:

            raise RuntimeError(
                "Nessun sensore ambientale configurato."
            )


        if not self.sensor.is_available():

            raise RuntimeError(
                "Sensore ambientale non disponibile."
            )


        reading = (
            self.sensor.read()
        )


        self.validate_reading(
            reading
        )


        self.last_reading = reading


        return reading


    # ==================================================
    # ULTIMA LETTURA
    # ==================================================

    def get_last_reading(
        self
    ) -> EnvironmentReading | None:

        return self.last_reading


    # ==================================================
    # VALIDAZIONE
    # ==================================================

    def validate_reading(
        self,
        reading: EnvironmentReading
    ) -> None:
        """
        Primo controllo di plausibilità.

        Le soglie sono volutamente molto ampie:
        servono a intercettare dati manifestamente
        errati, non a stabilire il comfort della pianta.
        """

        if (
            reading.temperature_c < -40
            or
            reading.temperature_c > 85
        ):

            raise ValueError(
                "Temperatura ambientale non plausibile."
            )


        if (
            reading.humidity_percent < 0
            or
            reading.humidity_percent > 100
        ):

            raise ValueError(
                "Umidità ambientale non plausibile."
            )