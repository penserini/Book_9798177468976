import json
import statistics

from dataclasses import asdict

from pathlib import Path

from uuid import uuid4

from app.models.pump_calibration import (
    PumpCalibrationMeasurement
)


class PumpCalibrationService:
    """
    Gestisce la calibrazione idraulica della pompa.

    Le misure descrivono l'intera catena reale:

    serbatoio
        ↓
    pompa
        ↓
    tubo
        ↓
    gocciolatoio
        ↓
    acqua erogata

    Il servizio NON comanda la pompa.
    Memorizza e caratterizza solamente la portata.
    """


    MINIMUM_VALID_MEASUREMENTS = 3

    MAX_COEFFICIENT_OF_VARIATION_PERCENT = 10.0


    def __init__(
        self
    ):

        project_root = (
            Path(__file__)
            .resolve()
            .parents[2]
        )


        self.data_file = (
            project_root
            /
            "data"
            /
            "pump_calibration.json"
        )


        self.measurements: list[
            PumpCalibrationMeasurement
        ] = []


        self.load()


    # ==================================================
    # CARICAMENTO
    # ==================================================

    def load(
        self
    ) -> None:

        self.measurements = []


        if not self.data_file.exists():

            return


        try:

            with open(
                self.data_file,
                "r",
                encoding="utf-8"
            ) as file:

                data = json.load(
                    file
                )


            raw_measurements = (
                data.get(
                    "measurements",
                    []
                )
            )


            for raw in raw_measurements:

                self.measurements.append(

                    PumpCalibrationMeasurement(
                        measurement_id=
                            raw["measurement_id"],

                        duration_s=
                            float(
                                raw["duration_s"]
                            ),

                        volume_ml=
                            float(
                                raw["volume_ml"]
                            ),

                        voltage_v=
                            float(
                                raw.get(
                                    "voltage_v",
                                    5.0
                                )
                            ),

                        flow_ml_s=
                            float(
                                raw["flow_ml_s"]
                            ),

                        timestamp=
                            raw["timestamp"]
                    )
                )


        except Exception:

            self.measurements = []


    # ==================================================
    # SALVATAGGIO
    # ==================================================

    def save(
        self
    ) -> None:

        self.data_file.parent.mkdir(
            parents=True,
            exist_ok=True
        )


        payload = {

            "measurements": [

                asdict(
                    measurement
                )

                for measurement
                in self.measurements

            ],

            "statistics":
                self.calculate_statistics(),

            "validation":
                self.validate_calibration()
        }


        with open(
            self.data_file,
            "w",
            encoding="utf-8"
        ) as file:

            json.dump(
                payload,
                file,
                ensure_ascii=False,
                indent=4
            )


    # ==================================================
    # NUOVA MISURA
    # ==================================================

    def create_measurement(
        self,
        duration_s: float,
        volume_ml: float,
        voltage_v: float = 5.0
    ) -> PumpCalibrationMeasurement:

        if duration_s <= 0:

            raise ValueError(
                "La durata deve essere maggiore di zero."
            )


        if volume_ml <= 0:

            raise ValueError(
                "Il volume deve essere maggiore di zero."
            )


        if voltage_v <= 0:

            raise ValueError(
                "La tensione deve essere maggiore di zero."
            )


        measurement = (
            PumpCalibrationMeasurement
            .create(

                measurement_id=
                    uuid4().hex,

                duration_s=
                    duration_s,

                volume_ml=
                    volume_ml,

                voltage_v=
                    voltage_v
            )
        )


        self.measurements.append(
            measurement
        )


        self.save()


        return measurement


    # ==================================================
    # ELIMINAZIONE
    # ==================================================

    def delete_measurement(
        self,
        measurement_id: str
    ) -> bool:

        original_count = (
            len(
                self.measurements
            )
        )


        self.measurements = [

            measurement

            for measurement
            in self.measurements

            if (
                measurement.measurement_id
                !=
                measurement_id
            )
        ]


        deleted = (
            len(
                self.measurements
            )
            <
            original_count
        )


        if deleted:

            self.save()


        return deleted


    # ==================================================
    # LETTURA
    # ==================================================

    def get_measurements(
        self
    ) -> list[dict]:

        return [

            asdict(
                measurement
            )

            for measurement
            in self.measurements
        ]


    # ==================================================
    # STATISTICHE
    # ==================================================

    def calculate_statistics(
        self
    ) -> dict:

        if not self.measurements:

            return {
                "average_flow_ml_s":
                    None,

                "minimum_flow_ml_s":
                    None,

                "maximum_flow_ml_s":
                    None,

                "standard_deviation_ml_s":
                    None,

                "coefficient_of_variation_percent":
                    None,

                "samples":
                    0
            }


        flows = [

            measurement.flow_ml_s

            for measurement
            in self.measurements
        ]


        average = (
            statistics.mean(
                flows
            )
        )


        minimum = (
            min(
                flows
            )
        )


        maximum = (
            max(
                flows
            )
        )


        if len(flows) > 1:

            standard_deviation = (
                statistics.stdev(
                    flows
                )
            )

        else:

            standard_deviation = (
                0.0
            )


        if average > 0:

            coefficient_of_variation = (
                standard_deviation
                /
                average
                *
                100
            )

        else:

            coefficient_of_variation = (
                None
            )


        return {

            "average_flow_ml_s":
                round(
                    average,
                    4
                ),

            "minimum_flow_ml_s":
                round(
                    minimum,
                    4
                ),

            "maximum_flow_ml_s":
                round(
                    maximum,
                    4
                ),

            "standard_deviation_ml_s":
                round(
                    standard_deviation,
                    4
                ),

            "coefficient_of_variation_percent":
                (
                    None
                    if coefficient_of_variation is None
                    else
                    round(
                        coefficient_of_variation,
                        2
                    )
                ),

            "samples":
                len(
                    flows
                )
        }


    # ==================================================
    # VALIDAZIONE
    # ==================================================

    def validate_calibration(
        self
    ) -> dict:

        statistics_data = (
            self.calculate_statistics()
        )


        samples = (
            statistics_data[
                "samples"
            ]
        )


        coefficient = (
            statistics_data[
                "coefficient_of_variation_percent"
            ]
        )


        if (
            samples
            <
            self.MINIMUM_VALID_MEASUREMENTS
        ):

            return {

                "valid":
                    False,

                "status":
                    "INCOMPLETA",

                "message":
                    (
                        "Servono almeno "
                        f"{self.MINIMUM_VALID_MEASUREMENTS} "
                        "misure per validare "
                        "la calibrazione."
                    )
            }


        if (
            coefficient is None
            or
            coefficient
            >
            self.MAX_COEFFICIENT_OF_VARIATION_PERCENT
        ):

            return {

                "valid":
                    False,

                "status":
                    "DA VERIFICARE",

                "message":
                    (
                        "Le misure presentano "
                        "una dispersione elevata. "
                        "Ripetere le prove."
                    )
            }


        return {

            "valid":
                True,

            "status":
                "VALIDA",

            "message":
                (
                    "Calibrazione della pompa "
                    "completa e sufficientemente stabile."
                )
        }


    # ==================================================
    # STATO COMPLETO
    # ==================================================

    def get_status(
        self
    ) -> dict:

        return {

            "measurements":
                self.get_measurements(),

            "statistics":
                self.calculate_statistics(),

            "validation":
                self.validate_calibration()
        }