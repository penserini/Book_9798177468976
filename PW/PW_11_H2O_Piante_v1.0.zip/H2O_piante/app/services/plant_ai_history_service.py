import json
import uuid

from datetime import datetime
from pathlib import Path

from app.models.plant_ai_history import PlantAIHistoryEntry
from app.models.plant_ai_result import PlantAIResult


class PlantAIHistoryService:
    """
    Persistenza dello storico delle analisi AI.

    I dati vengono salvati in:
        data/plant_ai_history.json

    Ogni nuova analisi genera una voce indipendente, così le analisi
    precedenti non vengono sovrascritte.
    """

    def __init__(self):
        project_root = Path(__file__).resolve().parents[2]

        self.data_file = (
            project_root
            / "data"
            / "plant_ai_history.json"
        )

        self.entries: list[PlantAIHistoryEntry] = []

        self.load()

    def load(self) -> None:
        if not self.data_file.exists():
            self.entries = []
            return

        try:
            with open(
                self.data_file,
                "r",
                encoding="utf-8"
            ) as file:
                raw = json.load(file)

        except (
            OSError,
            json.JSONDecodeError
        ):
            self.entries = []
            return

        raw_entries = raw.get(
            "entries",
            []
        )

        loaded_entries: list[PlantAIHistoryEntry] = []

        for item in raw_entries:
            try:
                loaded_entries.append(
                    PlantAIHistoryEntry.model_validate(
                        item
                    )
                )
            except Exception:
                # Una eventuale voce corrotta non deve impedire
                # l'avvio dell'intero sistema.
                continue

        self.entries = loaded_entries

    def save(self) -> None:
        self.data_file.parent.mkdir(
            parents=True,
            exist_ok=True
        )

        payload = {
            "entries": [
                entry.model_dump()
                for entry in self.entries
            ]
        }

        with open(
            self.data_file,
            "w",
            encoding="utf-8"
        ) as file:
            json.dump(
                payload,
                file,
                ensure_ascii=False,
                indent=4
            )

    def add_analysis(
        self,
        profile_id: str,
        image_index: int,
        image_url: str,
        provider: str,
        model: str,
        result: PlantAIResult
    ) -> PlantAIHistoryEntry:

        entry = PlantAIHistoryEntry(
            analysis_id=uuid.uuid4().hex,
            profile_id=profile_id,
            image_index=image_index,
            image_url=image_url,
            timestamp=(
                datetime.now()
                .astimezone()
                .isoformat(
                    timespec="seconds"
                )
            ),
            provider=provider,
            model=model,
            analysis=result.analysis,
            usage=result.usage,
            cost=result.cost
        )

        self.entries.append(
            entry
        )

        self.save()

        return entry

    def get_entries_for_profile(
        self,
        profile_id: str
    ) -> list[PlantAIHistoryEntry]:

        profile_entries = [
            entry
            for entry in self.entries
            if entry.profile_id == profile_id
        ]

        return sorted(
            profile_entries,
            key=lambda item: item.timestamp,
            reverse=True
        )

    def get_entry(
        self,
        profile_id: str,
        analysis_id: str
    ) -> PlantAIHistoryEntry | None:

        for entry in self.entries:
            if (
                entry.profile_id == profile_id
                and
                entry.analysis_id == analysis_id
            ):
                return entry

        return None

    def delete_entry(
        self,
        profile_id: str,
        analysis_id: str
    ) -> bool:

        entry = self.get_entry(
            profile_id=profile_id,
            analysis_id=analysis_id
        )

        if entry is None:
            return False

        self.entries = [
            item
            for item in self.entries
            if item.analysis_id != analysis_id
        ]

        self.save()

        return True
