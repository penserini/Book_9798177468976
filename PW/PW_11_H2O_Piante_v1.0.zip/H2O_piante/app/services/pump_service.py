from app.hardware.connection import DeviceConnection
from app.services.pump_calibration_service import PumpCalibrationService


class PumpService:
    """
    Servizio applicativo per il comando della pompa.

    Non dipende dalla modalità di trasporto:
    può utilizzare SerialConnection oppure HttpConnection.

    Supporta due modalità di comando:
    - a tempo;
    - per volume, quando la calibrazione della pompa è valida.
    """

    MAX_DURATION_SECONDS = 60.0

    def __init__(
        self,
        connection: DeviceConnection,
        calibration_service: PumpCalibrationService
    ):
        self.connection = connection
        self.calibration_service = calibration_service

    def run_for_seconds(
        self,
        duration_s: float
    ) -> dict:
        if duration_s <= 0:
            raise ValueError(
                "La durata deve essere maggiore di zero."
            )

        if duration_s > self.MAX_DURATION_SECONDS:
            raise ValueError(
                (
                    "Durata superiore al limite "
                    f"di {self.MAX_DURATION_SECONDS} secondi."
                )
            )

        if not self.connection.is_connected():
            raise RuntimeError(
                "ESP32 non connessa."
            )

        duration_ms = int(
            round(duration_s * 1000)
        )

        result = self.connection.run_pump(
            duration_ms
        )

        return {
            "running": result["running"],
            "duration_s": duration_s,
            "duration_ms": result["duration_ms"]
        }

    def run_for_volume_ml(
        self,
        volume_ml: float
    ) -> dict:
        if volume_ml <= 0:
            raise ValueError(
                "Il volume deve essere maggiore di zero."
            )

        validation = (
            self.calibration_service
            .validate_calibration()
        )

        if not validation["valid"]:
            raise RuntimeError(
                (
                    "Comando in millilitri non disponibile: "
                    f"{validation['message']}"
                )
            )

        statistics_data = (
            self.calibration_service
            .calculate_statistics()
        )

        average_flow_ml_s = (
            statistics_data[
                "average_flow_ml_s"
            ]
        )

        if (
            average_flow_ml_s is None
            or
            average_flow_ml_s <= 0
        ):
            raise RuntimeError(
                "Portata calibrata non disponibile."
            )

        calculated_duration_s = (
            volume_ml
            /
            average_flow_ml_s
        )

        if (
            calculated_duration_s
            >
            self.MAX_DURATION_SECONDS
        ):
            maximum_volume_ml = (
                average_flow_ml_s
                *
                self.MAX_DURATION_SECONDS
            )

            raise ValueError(
                (
                    "Il volume richiesto richiede un tempo "
                    "superiore al limite di sicurezza di "
                    f"{self.MAX_DURATION_SECONDS:.0f} secondi. "
                    "Con la calibrazione corrente il volume "
                    "massimo erogabile in un singolo comando è "
                    f"circa {maximum_volume_ml:.1f} ml."
                )
            )

        pump_result = self.run_for_seconds(
            calculated_duration_s
        )

        return {
            **pump_result,
            "volume_ml": volume_ml,
            "flow_ml_s": average_flow_ml_s,
            "calibration_samples": statistics_data["samples"],
            "calibration_status": validation["status"]
        }

    def stop(self) -> dict:
        if not self.connection.is_connected():
            raise RuntimeError(
                "ESP32 non connessa."
            )

        return self.connection.stop_pump()

    def get_status(self) -> dict:
        if not self.connection.is_connected():
            return {
                "connected": False,
                "running": False,
                "remaining_ms": 0
            }

        result = self.connection.get_pump_status()

        return {
            "connected": True,
            "running": result["running"],
            "remaining_ms": result["remaining_ms"]
        }
