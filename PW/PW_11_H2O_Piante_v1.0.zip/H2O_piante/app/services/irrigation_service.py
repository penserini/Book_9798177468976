from app.models.plant_profile import PlantProfile


class IrrigationService:

    # --------------------------------------------------
    # COSTRUTTORE
    # --------------------------------------------------

    def __init__(
        self,
        profile: PlantProfile
    ):

        self.profile = profile


    # --------------------------------------------------
    # DECISIONE DI IRRIGAZIONE
    # --------------------------------------------------

    def get_advice(
        self,
        humidity_percent: float | None,
        state: str | None
    ) -> dict:

        """
        Produce una decisione di irrigazione.

        In questa prima versione:

        1. se esiste una soglia percentuale configurata,
           viene utilizzata;

        2. altrimenti viene utilizzata la classificazione
           qualitativa proveniente dal CalibrationService.

        Il servizio NON comanda ancora la pompa.
        """


        if state is None:

            return {
                "irrigation_required":
                    False,

                "decision_available":
                    False,

                "recommended_water_ml":
                    None,

                "reason":
                    "Stato del terreno non disponibile."
            }


        # --------------------------------------------------
        # CONTROLLO DI SICUREZZA
        # --------------------------------------------------

        if state == "SATURO":

            return {
                "irrigation_required":
                    False,

                "decision_available":
                    True,

                "recommended_water_ml":
                    0,

                "reason":
                    "Terreno saturo. Irrigazione non necessaria."
            }


        if state == "BAGNATO":

            return {
                "irrigation_required":
                    False,

                "decision_available":
                    True,

                "recommended_water_ml":
                    0,

                "reason":
                    "Terreno già molto bagnato."
            }


        # --------------------------------------------------
        # SE ESISTE UNA SOGLIA PERCENTUALE SPECIFICA
        # --------------------------------------------------

        if (
            self.profile.minimum_humidity_percent
            is not None
            and
            humidity_percent
            is not None
        ):

            if (
                humidity_percent
                <
                self.profile.minimum_humidity_percent
            ):

                return {
                    "irrigation_required":
                        True,

                    "decision_available":
                        True,

                    "recommended_water_ml":
                        self.profile.water_dose_ml,

                    "reason": (
                        "Umidità relativa inferiore "
                        "alla soglia minima configurata."
                    )
                }


            return {
                "irrigation_required":
                    False,

                "decision_available":
                    True,

                "recommended_water_ml":
                    0,

                "reason":
                    "Umidità relativa superiore alla soglia minima."
            }


        # --------------------------------------------------
        # LOGICA QUALITATIVA DI FALLBACK
        # --------------------------------------------------
        #
        # Finché il profilo della pianta non contiene
        # soglie specifiche utilizziamo esclusivamente
        # le classi sperimentali della calibrazione.
        # --------------------------------------------------

        if state == "ASCIUTTO":

            return {
                "irrigation_required":
                    True,

                "decision_available":
                    True,

                "recommended_water_ml":
                    self.profile.water_dose_ml,

                "reason": (
                    "Terreno classificato ASCIUTTO. "
                    "Irrigazione consigliata."
                )
            }


        if state == "UMIDO":

            return {
                "irrigation_required":
                    False,

                "decision_available":
                    True,

                "recommended_water_ml":
                    0,

                "reason":
                    "Terreno classificato UMIDO."
            }


        return {
            "irrigation_required":
                False,

            "decision_available":
                False,

            "recommended_water_ml":
                None,

            "reason": (
                f"Stato del terreno non riconosciuto: {state}."
            )
        }