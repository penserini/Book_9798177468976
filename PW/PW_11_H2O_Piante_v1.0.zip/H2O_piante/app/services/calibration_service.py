from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
import json
import statistics

from app.hardware.connection import DeviceConnection


# --------------------------------------------------
# ORDINE LOGICO DEI PUNTI DI CALIBRAZIONE
# --------------------------------------------------

CALIBRATION_ORDER = {
    "ARIA": 0,
    "ASCIUTTO": 1,
    "UMIDO": 2,
    "BAGNATO": 3,
    "SATURO": 4
}


# --------------------------------------------------
# PUNTI NECESSARI PER UNA CALIBRAZIONE COMPLETA
# --------------------------------------------------

REQUIRED_CALIBRATION_POINTS = [
    "ARIA",
    "ASCIUTTO",
    "UMIDO",
    "BAGNATO",
    "SATURO"
]


# --------------------------------------------------
# SOGLIE DI VALIDAZIONE DEL SENSORE
# --------------------------------------------------

MAX_STANDARD_DEVIATION = 100.0

MAX_MEASUREMENT_RANGE = 300


# --------------------------------------------------
# MODELLO DATI
# --------------------------------------------------

@dataclass
class CalibrationPoint:

    name: str
    average: float
    minimum: int
    maximum: int
    standard_deviation: float
    samples: int
    timestamp: str


# --------------------------------------------------
# SERVIZIO DI CALIBRAZIONE
# --------------------------------------------------

class CalibrationService:

    def __init__(self):

        project_root = (
            Path(__file__)
            .resolve()
            .parents[2]
        )

        self.data_file = (
            project_root
            / "data"
            / "calibration.json"
        )

        self.points = {}

        self.load()


    # --------------------------------------------------
    # STATISTICHE
    # --------------------------------------------------

    def calculate_statistics(
        self,
        values
    ):

        if not values:

            raise ValueError(
                "La lista delle letture è vuota."
            )


        average = statistics.mean(
            values
        )

        minimum = min(
            values
        )

        maximum = max(
            values
        )


        if len(values) > 1:

            std_dev = statistics.stdev(
                values
            )

        else:

            std_dev = 0.0


        return {
            "average":
                average,

            "minimum":
                minimum,

            "maximum":
                maximum,

            "standard_deviation":
                std_dev,

            "samples":
                len(values)
        }


    # --------------------------------------------------
    # VALIDAZIONE DELLE MISURE
    # --------------------------------------------------

    def validate_measurements(
        self,
        values
    ) -> dict:

        if not values:

            return {
                "valid": False,

                "status":
                    "NON RILEVATO",

                "reason":
                    "Nessuna misura disponibile.",

                "standard_deviation":
                    None,

                "measurement_range":
                    None
            }


        stats = (
            self.calculate_statistics(
                values
            )
        )


        std_dev = (
            stats[
                "standard_deviation"
            ]
        )


        measurement_range = (
            stats["maximum"]
            -
            stats["minimum"]
        )


        if (
            std_dev
            > MAX_STANDARD_DEVIATION
        ):

            return {
                "valid": False,

                "status":
                    "MISURA INSTABILE",

                "reason": (
                    "Deviazione standard troppo elevata. "
                    "Il sensore potrebbe essere scollegato "
                    "o avere un contatto instabile."
                ),

                "standard_deviation":
                    round(
                        std_dev,
                        2
                    ),

                "measurement_range":
                    measurement_range
            }


        if (
            measurement_range
            > MAX_MEASUREMENT_RANGE
        ):

            return {
                "valid": False,

                "status":
                    "MISURA INSTABILE",

                "reason": (
                    "Escursione delle misure troppo elevata. "
                    "Controllare il collegamento del sensore."
                ),

                "standard_deviation":
                    round(
                        std_dev,
                        2
                    ),

                "measurement_range":
                    measurement_range
            }


        return {
            "valid": True,

            "status":
                "RILEVATO",

            "reason":
                "Sensore rilevato correttamente.",

            "standard_deviation":
                round(
                    std_dev,
                    2
                ),

            "measurement_range":
                measurement_range
        }


    # --------------------------------------------------
    # CREAZIONE PUNTO
    # --------------------------------------------------

    def create_point(
        self,
        name,
        values
    ):

        validation = (
            self.validate_measurements(
                values
            )
        )


        if not validation["valid"]:

            raise RuntimeError(
                validation["reason"]
            )


        stats = (
            self.calculate_statistics(
                values
            )
        )


        point = CalibrationPoint(

            name=
                name.upper(),

            average=
                round(
                    stats["average"],
                    2
                ),

            minimum=
                stats["minimum"],

            maximum=
                stats["maximum"],

            standard_deviation=
                round(
                    stats[
                        "standard_deviation"
                    ],
                    2
                ),

            samples=
                stats["samples"],

            timestamp=
                datetime.now().isoformat(
                    timespec="seconds"
                )
        )


        self.points[
            point.name
        ] = point


        return point


    # --------------------------------------------------
    # VERIFICA ESISTENZA PUNTO
    # --------------------------------------------------

    def has_point(
        self,
        name
    ) -> bool:

        self.load()

        return (
            name.upper()
            in self.points
        )


    # --------------------------------------------------
    # ELENCO PUNTI
    # --------------------------------------------------

    def get_points(self):

        self.load()


        ordered_items = sorted(

            self.points.items(),

            key=lambda item:
                CALIBRATION_ORDER.get(
                    item[0],
                    999
                )
        )


        return dict(
            ordered_items
        )


    # --------------------------------------------------
    # ELIMINAZIONE PUNTO
    # --------------------------------------------------

    def delete_point(
        self,
        name
    ) -> bool:

        self.load()


        point_name = (
            name.upper()
        )


        if (
            point_name
            not in self.points
        ):

            return False


        del self.points[
            point_name
        ]


        self.save()


        return True


    # --------------------------------------------------
    # SALVATAGGIO JSON
    # --------------------------------------------------

    def save(self):

        self.data_file.parent.mkdir(
            parents=True,
            exist_ok=True
        )


        ordered_items = sorted(

            self.points.items(),

            key=lambda item:
                CALIBRATION_ORDER.get(
                    item[0],
                    999
                )
        )


        data = {

            name:
                asdict(point)

            for name, point
            in ordered_items
        }


        with open(
            self.data_file,
            "w",
            encoding="utf-8"
        ) as file:

            json.dump(
                data,
                file,
                indent=4,
                ensure_ascii=False
            )


    # --------------------------------------------------
    # CARICAMENTO JSON
    # --------------------------------------------------

    def load(self):

        self.points.clear()


        if not self.data_file.exists():

            return


        try:

            with open(
                self.data_file,
                "r",
                encoding="utf-8"
            ) as file:

                data = json.load(
                    file
                )


        except (
            json.JSONDecodeError,
            OSError
        ):

            return


        for name, values in data.items():

            self.points[
                name
            ] = CalibrationPoint(
                **values
            )


    # --------------------------------------------------
    # ACQUISIZIONE MISURE
    # --------------------------------------------------

    def acquire_measurements(
        self,
        connection: DeviceConnection,
        channel: int = 0,
        samples: int = 10
    ) -> list[int]:

        if samples <= 0:

            raise ValueError(
                "Il numero di campioni deve "
                "essere maggiore di zero."
            )


        if not connection.is_connected():

            raise RuntimeError(
                "Il dispositivo non è connesso."
            )


        values = []


        for _ in range(
            samples
        ):

            value = (
                connection.read_sensor(
                    channel
                )
            )

            values.append(
                value
            )


        return values


    # --------------------------------------------------
    # ACQUISIZIONE + SALVATAGGIO
    # --------------------------------------------------

    def acquire_calibration(
        self,
        connection: DeviceConnection,
        name: str,
        channel: int = 0,
        samples: int = 10
    ):

        values = (
            self.acquire_measurements(
                connection=connection,
                channel=channel,
                samples=samples
            )
        )


        point = (
            self.create_point(
                name=name,
                values=values
            )
        )


        self.save()


        return point


    # --------------------------------------------------
    # VALIDAZIONE COMPLETA DELLA CALIBRAZIONE
    # --------------------------------------------------

    def validate_calibration(
        self
    ) -> dict:

        """
        Controlla:

        1. presenza dei cinque punti richiesti;
        2. ordine fisico coerente:

           ARIA >
           ASCIUTTO >
           UMIDO >
           BAGNATO >
           SATURO

        TEST_REALE ed eventuali altri punti
        non vengono considerati.
        """

        self.load()


        missing = [

            name

            for name
            in REQUIRED_CALIBRATION_POINTS

            if name not in self.points

        ]


        # --------------------------------------------------
        # CALIBRAZIONE INCOMPLETA
        # --------------------------------------------------

        if missing:

            return {
                "complete":
                    False,

                "valid":
                    False,

                "status":
                    "INCOMPLETA",

                "missing":
                    missing,

                "message": (
                    "Mancano i punti di calibrazione: "
                    + ", ".join(
                        missing
                    )
                    + "."
                )
            }


        # --------------------------------------------------
        # VALORI MEDI DEI CINQUE PUNTI
        # --------------------------------------------------

        values = {

            name:
                self.points[
                    name
                ].average

            for name
            in REQUIRED_CALIBRATION_POINTS
        }


        # --------------------------------------------------
        # CONTROLLO ORDINE
        # --------------------------------------------------

        inconsistencies = []


        for index in range(
            len(
                REQUIRED_CALIBRATION_POINTS
            )
            - 1
        ):

            current_name = (
                REQUIRED_CALIBRATION_POINTS[
                    index
                ]
            )

            next_name = (
                REQUIRED_CALIBRATION_POINTS[
                    index + 1
                ]
            )


            current_value = (
                values[
                    current_name
                ]
            )

            next_value = (
                values[
                    next_name
                ]
            )


            if (
                current_value
                <= next_value
            ):

                inconsistencies.append(
                    (
                        f"{current_name} "
                        f"({current_value}) "
                        f"deve essere maggiore di "
                        f"{next_name} "
                        f"({next_value})."
                    )
                )


        # --------------------------------------------------
        # CALIBRAZIONE NON COERENTE
        # --------------------------------------------------

        if inconsistencies:

            return {
                "complete":
                    True,

                "valid":
                    False,

                "status":
                    "NON COERENTE",

                "missing":
                    [],

                "values":
                    values,

                "errors":
                    inconsistencies,

                "message":
                    "La calibrazione è completa "
                    "ma presenta valori non coerenti."
            }


        # --------------------------------------------------
        # CALIBRAZIONE COMPLETA E VALIDA
        # --------------------------------------------------

        return {
            "complete":
                True,

            "valid":
                True,

            "status":
                "COMPLETA E VALIDA",

            "missing":
                [],

            "values":
                values,

            "errors":
                [],

            "message":
                "Tutti i punti di calibrazione "
                "sono presenti e coerenti."
        }


    # --------------------------------------------------
    # INDICE RELATIVO DI UMIDITÀ
    # --------------------------------------------------

    def calculate_moisture_percentage(
        self,
        raw_value: float
    ) -> float:

        self.load()


        if (
            "ASCIUTTO"
            not in self.points
        ):

            raise RuntimeError(
                "Punto ASCIUTTO non disponibile."
            )


        if (
            "SATURO"
            not in self.points
        ):

            raise RuntimeError(
                "Punto SATURO non disponibile."
            )


        dry_value = (
            self.points[
                "ASCIUTTO"
            ].average
        )


        saturated_value = (
            self.points[
                "SATURO"
            ].average
        )


        if (
            dry_value
            == saturated_value
        ):

            raise RuntimeError(
                "Calibrazione non valida: "
                "ASCIUTTO e SATURO hanno "
                "lo stesso valore."
            )


        percentage = (

            (
                dry_value
                -
                raw_value
            )

            /

            (
                dry_value
                -
                saturated_value
            )

        ) * 100


        percentage = max(
            0.0,
            min(
                100.0,
                percentage
            )
        )


        return round(
            percentage,
            1
        )


    # --------------------------------------------------
    # CLASSIFICAZIONE QUALITATIVA
    # --------------------------------------------------

    def classify_moisture(
        self,
        raw_value: float
    ) -> str:

        self.load()


        available = {

            name:
                point.average

            for name, point
            in self.points.items()

            if name in {
                "ASCIUTTO",
                "UMIDO",
                "BAGNATO",
                "SATURO"
            }
        }


        if (
            "ASCIUTTO"
            not in available
        ):

            raise RuntimeError(
                "Punto ASCIUTTO non disponibile."
            )


        ordered_names = [

            name

            for name in [
                "ASCIUTTO",
                "UMIDO",
                "BAGNATO",
                "SATURO"
            ]

            if name in available
        ]


        if (
            len(ordered_names)
            == 1
        ):

            return ordered_names[0]


        for index in range(
            len(
                ordered_names
            )
            - 1
        ):

            current_name = (
                ordered_names[
                    index
                ]
            )

            next_name = (
                ordered_names[
                    index + 1
                ]
            )


            current_value = (
                available[
                    current_name
                ]
            )

            next_value = (
                available[
                    next_name
                ]
            )


            threshold = (

                current_value
                +
                next_value

            ) / 2


            if (
                raw_value
                > threshold
            ):

                return current_name


        return (
            ordered_names[-1]
        )