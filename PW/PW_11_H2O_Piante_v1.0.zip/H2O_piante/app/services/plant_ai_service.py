from pathlib import Path

from app.ai.plant_ai_provider import PlantAIProvider
from app.models.plant_ai_result import PlantAIResult
from app.models.plant_profile import PlantProfile


class PlantAIService:
    """
    Servizio applicativo per l'analisi AI delle piante.

    Non dipende da OpenAI, Ollama o altri LLM specifici.
    Conosce solamente l'interfaccia PlantAIProvider.
    """


    def __init__(
        self,
        provider: PlantAIProvider
    ):

        self.provider = provider


    def get_provider_name(
        self
    ) -> str:

        return self.provider.get_name()


    def get_model_name(
        self
    ) -> str:

        return self.provider.get_model_name()


    def is_configured(
        self
    ) -> bool:

        return self.provider.is_configured()


    def analyze_image(
        self,
        image_path: Path,
        profile: PlantProfile,
        environment_data: dict | None = None,
        soil_data: dict | None = None
    ) -> PlantAIResult:

        return self.provider.analyze(
            image_path=image_path,
            profile=profile,
            environment_data=environment_data,
            soil_data=soil_data
        )