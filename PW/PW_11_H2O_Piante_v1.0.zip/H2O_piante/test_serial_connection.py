from app.hardware.serial_connection import SerialConnection


connection = SerialConnection(
    port="COM3",
    baudrate=115200
)

try:

    print("Connessione alla ESP32...")

    connection.connect()

    print(
        "Connessione attiva:",
        connection.is_connected()
    )

    print(
        "Test PING:",
        connection.ping()
    )

    print("\nLettura di 10 valori:")

    for i in range(10):

        value = connection.read_sensor(0)

        print(
            f"{i + 1}: {value}"
        )

finally:

    connection.disconnect()

    print("\nConnessione chiusa.")