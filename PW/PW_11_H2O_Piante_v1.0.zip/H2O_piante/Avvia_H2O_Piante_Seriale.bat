@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" goto missing
set "H2O_CONNECTION_MODE=serial"
if not defined H2O_SERIAL_PORT set "H2O_SERIAL_PORT=COM3"
if not defined H2O_SERVER_HOST set "H2O_SERVER_HOST=127.0.0.1"
echo Dashboard: http://127.0.0.1:8000/
echo Collegare ESP32 e premere CONNETTI ESP32 nella dashboard.
echo Per arrestare premere CTRL+C.
".venv\Scripts\python.exe" -m uvicorn app.main:app --host "%H2O_SERVER_HOST%" --port 8000 --no-proxy-headers
pause
exit /b
:missing
echo Eseguire prima Installa.bat. Consultare README.md.
pause
exit /b 1
