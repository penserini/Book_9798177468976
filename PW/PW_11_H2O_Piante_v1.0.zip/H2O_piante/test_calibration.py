from app.services.calibration_service import CalibrationService


service = CalibrationService()

values = [
    9913,
    9915,
    9914,
    9917,
    9916,
    9915,
    9913,
    9916,
    9914,
    9917
]

point = service.create_point(
    "ASCIUTTO",
    values
)

print("Punto creato:")
print(point)

service.save()

print("\nPunti memorizzati:")
print(service.get_points())