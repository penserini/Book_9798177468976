#include <Wire.h>

void setup() {

    Serial.begin(115200);

    Wire.begin(21, 22);

    delay(1000);

    Serial.println();
    Serial.println("Scansione bus I2C...");
}

void loop() {

    byte error;
    byte address;

    int devicesFound = 0;

    for (address = 1; address < 127; address++) {

        Wire.beginTransmission(address);

        error = Wire.endTransmission();

        if (error == 0) {

            Serial.print("Dispositivo I2C trovato all'indirizzo 0x");

            if (address < 16) {
                Serial.print("0");
            }

            Serial.println(address, HEX);

            devicesFound++;
        }
    }

    if (devicesFound == 0) {

        Serial.println("Nessun dispositivo I2C trovato.");

    } else {

        Serial.print("Totale dispositivi trovati: ");
        Serial.println(devicesFound);
    }

    Serial.println();
    Serial.println("Nuova scansione tra 5 secondi...");
    Serial.println();

    delay(5000);
}