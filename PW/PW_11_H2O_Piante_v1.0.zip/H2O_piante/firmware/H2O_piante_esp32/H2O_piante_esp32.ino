#include <Wire.h>
#include <WiFi.h>
#include <WebServer.h>
#include <ESPmDNS.h>
#include <Adafruit_ADS1X15.h>
#include <Adafruit_SHT31.h>

#include "wifi_secrets.h"


// ==================================================
// ADS1115
// ==================================================

Adafruit_ADS1115 ads;


// ==================================================
// SHT31
// ==================================================

Adafruit_SHT31 sht31 = Adafruit_SHT31();

const uint8_t SHT31_ADDRESS = 0x44;

bool sht31Available = false;


// ==================================================
// POMPA
// ==================================================

const int PUMP_PIN = 25;

const int PUMP_ON_LEVEL = HIGH;
const int PUMP_OFF_LEVEL = LOW;

const unsigned long PUMP_MAX_DURATION_MS = 60000UL;

bool pumpRunning = false;
unsigned long pumpStopAtMs = 0;


// ==================================================
// SERIALE
// ==================================================

String commandBuffer = "";


// ==================================================
// WIFI / HTTP
// ==================================================

WebServer server(80);

unsigned long lastWifiReconnectAttemptMs = 0;

const unsigned long WIFI_RECONNECT_INTERVAL_MS = 10000UL;

bool mdnsStarted = false;
String mdnsHostname = "";


// ==================================================
// SETUP
// ==================================================

void setup() {

    Serial.begin(115200);

    pinMode(PUMP_PIN, OUTPUT);
    digitalWrite(PUMP_PIN, PUMP_OFF_LEVEL);
    pumpRunning = false;

    Wire.begin(21, 22);

    if (!ads.begin()) {
        Serial.println("ERROR ADS1115_INIT");
    }

    sht31Available = sht31.begin(SHT31_ADDRESS);

    if (!sht31Available) {
        Serial.println("ERROR SHT31_INIT");
    }

    configureHttpRoutes();
    startWifi();
    server.begin();
}


// ==================================================
// LOOP
// ==================================================

void loop() {

    updatePumpTimer();
    maintainWifi();

    if (WiFi.status() == WL_CONNECTED) {
        server.handleClient();
    }

    processSerialInput();
}


// ==================================================
// WIFI
// ==================================================

void startWifi() {

    WiFi.mode(WIFI_STA);
    WiFi.setHostname(DEVICE_NAME);

    Serial.print("WIFI_CONNECTING ");
    Serial.println(WIFI_SSID);

    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

    unsigned long startMs = millis();

    while (
        WiFi.status() != WL_CONNECTED
        &&
        millis() - startMs < 12000UL
    ) {
        delay(250);
    }

    if (WiFi.status() == WL_CONNECTED) {
        printWifiStatus();
        startMdns();
    }
    else {
        Serial.println("WIFI_NOT_CONNECTED");
        Serial.println("SERIAL_MODE_AVAILABLE");
    }
}


void maintainWifi() {

    if (WiFi.status() == WL_CONNECTED) {

        if (!mdnsStarted) {
            startMdns();
        }

        return;
    }

    if (mdnsStarted) {
        MDNS.end();
        mdnsStarted = false;
    }

    unsigned long now = millis();

    if (
        now - lastWifiReconnectAttemptMs
        <
        WIFI_RECONNECT_INTERVAL_MS
    ) {
        return;
    }

    lastWifiReconnectAttemptMs = now;

    WiFi.disconnect();
    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
}


void printWifiStatus() {

    Serial.println("WIFI_CONNECTED");

    Serial.print("WIFI_IP ");
    Serial.println(WiFi.localIP());

    Serial.print("WIFI_RSSI ");
    Serial.println(WiFi.RSSI());
}


void startMdns() {

    if (WiFi.status() != WL_CONNECTED) {
        return;
    }

    if (mdnsStarted) {
        return;
    }

    mdnsHostname = String(DEVICE_NAME);
    mdnsHostname.toLowerCase();

    if (!MDNS.begin(mdnsHostname.c_str())) {
        Serial.println("ERROR MDNS_INIT");
        mdnsStarted = false;
        return;
    }

    MDNS.addService("http", "tcp", 80);

    mdnsStarted = true;

    Serial.print("MDNS_HOST ");
    Serial.print("http://");
    Serial.print(mdnsHostname);
    Serial.println(".local");
}


// ==================================================
// HTTP ROUTES
// ==================================================

void configureHttpRoutes() {

    server.on(
        "/ping",
        HTTP_GET,
        handleHttpPing
    );

    server.on(
        "/info",
        HTTP_GET,
        handleHttpInfo
    );

    server.on(
        "/sensor",
        HTTP_GET,
        handleHttpSensor
    );

    server.on(
        "/environment",
        HTTP_GET,
        handleHttpEnvironment
    );

    server.on(
        "/pump/status",
        HTTP_GET,
        handleHttpPumpStatus
    );

    server.on(
        "/pump/run",
        HTTP_POST,
        handleHttpPumpRun
    );

    server.on(
        "/pump/stop",
        HTTP_POST,
        handleHttpPumpStop
    );

    server.onNotFound(
        []() {
            sendJson(
                404,
                "{\"success\":false,\"message\":\"Endpoint ESP32 non trovato.\"}"
            );
        }
    );
}


void handleHttpPing() {

    sendJson(
        200,
        "{\"success\":true,\"message\":\"PONG\"}"
    );
}


void handleHttpInfo() {

    String body = "{";
    body += "\"success\":true,";
    body += "\"device_name\":\"" + String(DEVICE_NAME) + "\",";
    body += "\"ip\":\"" + WiFi.localIP().toString() + "\",";
    body += "\"mdns\":\"http://" + mdnsHostname + ".local\",";
    body += "\"rssi\":" + String(WiFi.RSSI()) + ",";
    body += "\"sht31_available\":" + boolJson(sht31Available) + ",";
    body += "\"pump_running\":" + boolJson(pumpRunning);
    body += "}";

    sendJson(200, body);
}


void handleHttpSensor() {

    if (!server.hasArg("channel")) {
        sendJson(
            400,
            "{\"success\":false,\"message\":\"Parametro channel mancante.\"}"
        );
        return;
    }

    int channel = server.arg("channel").toInt();

    if (channel < 0 || channel > 3) {
        sendJson(
            400,
            "{\"success\":false,\"message\":\"Canale ADS1115 non valido.\"}"
        );
        return;
    }

    int16_t value = ads.readADC_SingleEnded(channel);

    String body = "{";
    body += "\"success\":true,";
    body += "\"channel\":" + String(channel) + ",";
    body += "\"value\":" + String(value);
    body += "}";

    sendJson(200, body);
}


void handleHttpEnvironment() {

    if (!sht31Available) {
        sendJson(
            503,
            "{\"success\":false,\"message\":\"SHT31 non disponibile.\"}"
        );
        return;
    }

    float temperature = sht31.readTemperature();
    float humidity = sht31.readHumidity();

    if (isnan(temperature) || isnan(humidity)) {
        sendJson(
            503,
            "{\"success\":false,\"message\":\"Errore lettura SHT31.\"}"
        );
        return;
    }

    String body = "{";
    body += "\"success\":true,";
    body += "\"temperature_c\":" + String(temperature, 2) + ",";
    body += "\"humidity_percent\":" + String(humidity, 2);
    body += "}";

    sendJson(200, body);
}


void handleHttpPumpStatus() {

    updatePumpTimer();

    String body = "{";
    body += "\"success\":true,";
    body += "\"running\":" + boolJson(pumpRunning) + ",";
    body += "\"remaining_ms\":" + String(getPumpRemainingMs());
    body += "}";

    sendJson(200, body);
}


void handleHttpPumpRun() {

    if (!server.hasArg("duration_ms")) {
        sendJson(
            400,
            "{\"success\":false,\"message\":\"Parametro duration_ms mancante.\"}"
        );
        return;
    }

    unsigned long durationMs = (
        unsigned long
    ) server.arg("duration_ms").toInt();

    if (durationMs == 0) {
        sendJson(
            400,
            "{\"success\":false,\"message\":\"Durata pompa non valida.\"}"
        );
        return;
    }

    if (durationMs > PUMP_MAX_DURATION_MS) {
        sendJson(
            400,
            "{\"success\":false,\"message\":\"Durata pompa superiore al limite.\"}"
        );
        return;
    }

    startPump(durationMs);

    String body = "{";
    body += "\"success\":true,";
    body += "\"running\":true,";
    body += "\"duration_ms\":" + String(durationMs);
    body += "}";

    sendJson(200, body);
}


void handleHttpPumpStop() {

    stopPump();

    sendJson(
        200,
        "{\"success\":true,\"running\":false,\"remaining_ms\":0}"
    );
}


void sendJson(
    int statusCode,
    const String& body
) {

    server.send(
        statusCode,
        "application/json",
        body
    );
}


String boolJson(bool value) {
    return value ? "true" : "false";
}


// ==================================================
// TIMER POMPA
// ==================================================

void updatePumpTimer() {

    if (!pumpRunning) {
        return;
    }

    if (
        (long)(millis() - pumpStopAtMs)
        >=
        0
    ) {
        stopPump();
    }
}


void startPump(
    unsigned long durationMs
) {

    digitalWrite(PUMP_PIN, PUMP_ON_LEVEL);
    pumpRunning = true;
    pumpStopAtMs = millis() + durationMs;
}


void stopPump() {

    digitalWrite(PUMP_PIN, PUMP_OFF_LEVEL);
    pumpRunning = false;
    pumpStopAtMs = 0;
}


unsigned long getPumpRemainingMs() {

    if (!pumpRunning) {
        return 0;
    }

    long remaining = (
        long
    )(
        pumpStopAtMs - millis()
    );

    if (remaining <= 0) {
        return 0;
    }

    return (unsigned long) remaining;
}


// ==================================================
// INPUT SERIALE
// ==================================================

void processSerialInput() {

    while (Serial.available() > 0) {

        char incoming = Serial.read();

        if (incoming == '\n') {

            commandBuffer.trim();

            if (commandBuffer.length() > 0) {
                processCommand(commandBuffer);
            }

            commandBuffer = "";
        }
        else if (incoming != '\r') {
            commandBuffer += incoming;
        }
    }
}


// ==================================================
// COMANDI SERIALI ESISTENTI
// ==================================================

void processCommand(String command) {

    if (command == "PING") {
        Serial.println("PONG");
        return;
    }

    if (command == "ENV") {
        processEnvironmentCommand();
        return;
    }

    if (command.startsWith("READ ")) {
        processReadCommand(command);
        return;
    }

    if (command == "PUMP_STOP") {
        stopPump();
        Serial.println("PUMP_STOPPED");
        return;
    }

    if (command == "PUMP_STATUS") {

        updatePumpTimer();

        if (pumpRunning) {
            Serial.print("PUMP_RUNNING ");
            Serial.println(getPumpRemainingMs());
        }
        else {
            Serial.println("PUMP_STOPPED");
        }

        return;
    }

    if (command.startsWith("PUMP ")) {
        processPumpCommand(command);
        return;
    }

    if (command == "WIFI_STATUS") {

        if (WiFi.status() == WL_CONNECTED) {
            printWifiStatus();
        }
        else {
            Serial.println("WIFI_NOT_CONNECTED");
        }

        return;
    }

    Serial.println("ERROR UNKNOWN_COMMAND");
}


void processEnvironmentCommand() {

    if (!sht31Available) {
        Serial.println("ERROR SHT31_NOT_AVAILABLE");
        return;
    }

    float temperature = sht31.readTemperature();
    float humidity = sht31.readHumidity();

    if (isnan(temperature) || isnan(humidity)) {
        Serial.println("ERROR SHT31_READ");
        return;
    }

    Serial.print("ENV ");
    Serial.print(temperature, 2);
    Serial.print(" ");
    Serial.println(humidity, 2);
}


void processReadCommand(String command) {

    int separatorIndex = command.indexOf(' ');

    if (separatorIndex < 0) {
        Serial.println("ERROR INVALID_READ");
        return;
    }

    String channelText = command.substring(
        separatorIndex + 1
    );

    channelText.trim();

    int channel = channelText.toInt();

    if (channel < 0 || channel > 3) {
        Serial.println("ERROR INVALID_CHANNEL");
        return;
    }

    int16_t value = ads.readADC_SingleEnded(channel);

    Serial.print("VALUE ");
    Serial.print(channel);
    Serial.print(" ");
    Serial.println(value);
}


void processPumpCommand(String command) {

    int separatorIndex = command.indexOf(' ');

    if (separatorIndex < 0) {
        Serial.println("ERROR INVALID_PUMP_COMMAND");
        return;
    }

    String durationText = command.substring(
        separatorIndex + 1
    );

    durationText.trim();

    unsigned long durationMs = durationText.toInt();

    if (durationMs == 0) {
        Serial.println("ERROR INVALID_PUMP_DURATION");
        return;
    }

    if (durationMs > PUMP_MAX_DURATION_MS) {
        Serial.println("ERROR PUMP_DURATION_TOO_LONG");
        return;
    }

    startPump(durationMs);

    Serial.print("PUMP_OK ");
    Serial.println(durationMs);
}
