#ifndef WIFI_SECRETS_H
#define WIFI_SECRETS_H
const char* WIFI_SSID = "INSERISCI_SSID";
const char* WIFI_PASSWORD = "INSERISCI_PASSWORD_WIFI";
const char* DEVICE_NAME = "h2o-pianta-01";
#endif
